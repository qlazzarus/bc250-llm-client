"""Read-only building blocks for a local root service.

The only accepted operations are read-only. Switching is deliberately unavailable
until lock, admission and crash recovery are enforced inside the privileged service.
"""

import json
import os
import re
import secrets
import socket
import stat
import struct
from pathlib import Path

from app.core.studio_files import FileLock, protected_xattrs

MODEL_NAME = re.compile(r"[A-Za-z0-9_-]{1,128}\Z")
MAX_REQUEST = 4096


class ModelRegistry:
    def __init__(self, base=Path("/opt/ai/config")):
        self.base = Path(base)

    @staticmethod
    def _check_file(info):
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0
                or info.st_nlink != 1 or info.st_mode & 0o022):
            raise RuntimeError("Untrusted model configuration")

    def _open_base(self):
        if not self.base.is_absolute() or ".." in self.base.parts:
            raise RuntimeError("Invalid registry path")
        fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
        try:
            FileLock._check_trusted_directory(os.fstat(fd))
            for part in self.base.parts[1:]:
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                dir_fd=fd)
                os.close(fd)
                fd = child
                FileLock._check_trusted_directory(os.fstat(fd))
            return fd
        except BaseException:
            os.close(fd)
            raise

    def list_models(self):
        base = self._open_base()
        try:
            directory = os.open("models", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW |
                                os.O_CLOEXEC, dir_fd=base)
            try:
                FileLock._check_trusted_directory(os.fstat(directory))
                models = []
                for filename in os.listdir(directory):
                    if not filename.endswith(".conf"):
                        continue
                    name = filename[:-5]
                    if not MODEL_NAME.fullmatch(name):
                        raise RuntimeError("Invalid model configuration name")
                    fd = os.open(filename, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                 dir_fd=directory)
                    try:
                        self._check_file(os.fstat(fd))
                    finally:
                        os.close(fd)
                    models.append(name)
                return sorted(models)
            finally:
                os.close(directory)
        finally:
            os.close(base)

    def current_model(self):
        base = self._open_base()
        try:
            fd = os.open("active-model.conf", os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC,
                         dir_fd=base)
            try:
                self._check_file(os.fstat(fd))
                value = os.read(fd, 4097)
            finally:
                os.close(fd)
        finally:
            os.close(base)
        match = re.fullmatch(rb"ACTIVE_MODEL=([A-Za-z0-9_-]{1,128})\n?", value)
        if not match:
            raise RuntimeError("Invalid active model configuration")
        name = match.group(1).decode("ascii")
        if name not in self.list_models():
            raise RuntimeError("Active model is not installed")
        return name

    def model_id(self, name):
        """Return the GGUF path from a trusted, strictly literal model config.

        This is the expected llama ID, not a claim that llama has loaded it.
        Unsupported shell syntax fails closed instead of being executed here.
        """
        if not isinstance(name, str) or not MODEL_NAME.fullmatch(name):
            raise ValueError("Invalid model name")
        base = self._open_base()
        try:
            directory = os.open("models", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW |
                                os.O_CLOEXEC, dir_fd=base)
            try:
                FileLock._check_trusted_directory(os.fstat(directory))
                fd = os.open(name + ".conf", os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC,
                             dir_fd=directory)
                try:
                    self._check_file(os.fstat(fd))
                    raw = os.read(fd, 16385)
                finally:
                    os.close(fd)
            finally:
                os.close(directory)
        finally:
            os.close(base)
        if len(raw) > 16384:
            raise RuntimeError("Model configuration exceeds size limit")
        values = {}
        try:
            lines = raw.decode("utf-8").splitlines()
        except UnicodeDecodeError as error:
            raise RuntimeError("Invalid model configuration") from error
        for line in lines:
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            match = re.fullmatch(r"([A-Z][A-Z0-9_]*)=([A-Za-z0-9_+./:-]*)", line)
            if not match or match[1] in values:
                raise RuntimeError("Unsupported model configuration syntax")
            values[match[1]] = match[2]
        path = values.get("MODEL_PATH", "")
        if (not path.startswith("/") or os.path.normpath(path) != path
                or not path.endswith(".gguf") or values.get("MODEL_NAME", name) != name):
            raise RuntimeError("Invalid model configuration mapping")
        return path


class ActiveModelWriter:
    """Candidate root-owned config writer; caller must hold the shared GPU lock."""

    def __init__(self, registry):
        self.registry = registry

    def validate_replacement(self):
        """Check replacement metadata before admission is paused or a journal is written."""
        base = self.registry._open_base()
        temporary = ".active-model-" + secrets.token_hex(16)
        try:
            current = os.open("active-model.conf", os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC,
                              dir_fd=base)
            try:
                metadata = os.fstat(current)
                self.registry._check_file(metadata)
                attributes = protected_xattrs(current)
            finally:
                os.close(current)
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW |
                         os.O_CLOEXEC, 0o600, dir_fd=base)
            try:
                os.fchown(fd, metadata.st_uid, metadata.st_gid)
                os.fchmod(fd, stat.S_IMODE(metadata.st_mode))
                if protected_xattrs(fd) != attributes:
                    raise RuntimeError("Model configuration ACL or SELinux label would change")
            finally:
                os.close(fd)
                os.unlink(temporary, dir_fd=base)
        finally:
            os.close(base)

    def set_active(self, name):
        if not isinstance(name, str) or not MODEL_NAME.fullmatch(name):
            raise ValueError("Invalid model name")
        if name not in self.registry.list_models():
            raise ValueError("Unknown model")
        model_path = self.registry.model_id(name)
        info = os.stat(model_path)
        if not stat.S_ISREG(info.st_mode) or info.st_size == 0:
            raise RuntimeError("Model file missing or empty")
        base = self.registry._open_base()
        temporary = ".active-model-" + secrets.token_hex(16)
        try:
            current = os.open("active-model.conf", os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC,
                              dir_fd=base)
            try:
                metadata = os.fstat(current)
                self.registry._check_file(metadata)
                attributes = protected_xattrs(current)
            finally:
                os.close(current)
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW |
                         os.O_CLOEXEC, 0o600, dir_fd=base)
            try:
                os.fchown(fd, metadata.st_uid, metadata.st_gid)
                os.fchmod(fd, stat.S_IMODE(metadata.st_mode))
                if protected_xattrs(fd) != attributes:
                    raise RuntimeError("Model configuration ACL or SELinux label would change")
                with os.fdopen(fd, "w") as file:
                    fd = -1
                    file.write(f"ACTIVE_MODEL={name}\n")
                    file.flush()
                    os.fsync(file.fileno())
                os.replace(temporary, "active-model.conf", src_dir_fd=base, dst_dir_fd=base)
                os.fsync(base)
            finally:
                if fd != -1:
                    os.close(fd)
                try:
                    os.unlink(temporary, dir_fd=base)
                except FileNotFoundError:
                    pass
        finally:
            os.close(base)


def handle_request(connection, allowed_uid, registry):
    """Serve one bounded request on an already accepted Unix socket."""
    credentials = connection.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12)
    _, uid, _ = struct.unpack("3i", credentials)
    if uid != allowed_uid:
        return {"error": "forbidden"}
    connection.settimeout(2)
    buffer = b""
    while b"\n" not in buffer and len(buffer) <= MAX_REQUEST:
        part = connection.recv(min(1024, MAX_REQUEST + 1 - len(buffer)))
        if not part:
            break
        buffer += part
    if len(buffer) > MAX_REQUEST or not buffer.endswith(b"\n") or buffer.count(b"\n") != 1:
        return {"error": "invalid_request"}
    try:
        request = json.loads(buffer)
    except (ValueError, UnicodeDecodeError):
        return {"error": "invalid_request"}
    if not isinstance(request, dict) or set(request) != {"operation"}:
        return {"error": "invalid_request"}
    if request["operation"] == "list":
        return {"models": registry.list_models()}
    if request["operation"] == "status":
        return {"current": registry.current_model()}
    return {"error": "unsupported_operation"}


def serve_connection(connection, allowed_uid, registry):
    """Send one response without exposing local paths or exception details."""
    try:
        response = handle_request(connection, allowed_uid, registry)
    except (OSError, RuntimeError, TimeoutError):
        response = {"error": "unavailable"}
    connection.sendall(json.dumps(response, separators=(",", ":")).encode() + b"\n")
