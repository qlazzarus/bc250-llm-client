#!/usr/bin/env python3
"""Read-only gate credential snapshot; it does not establish an access fence."""

import grp
import os
import pwd
import re
import subprocess
from pathlib import Path

PROC = Path('/proc')


def process_credentials(text, uid, gid):
    if not isinstance(text, str):
        raise ValueError('프로세스 상태 형식 오류')
    fields = {}
    for line in text.splitlines():
        name, separator, value = line.partition(':')
        if separator and name in {'Uid', 'Gid', 'Groups', 'CapInh', 'CapPrm', 'CapEff', 'CapAmb', 'NoNewPrivs'}:
            if name in fields:
                raise ValueError('중복 프로세스 상태')
            fields[name] = value.strip()
    if set(fields) != {'Uid', 'Gid', 'Groups', 'CapInh', 'CapPrm', 'CapEff', 'CapAmb', 'NoNewPrivs'}:
        raise ValueError('프로세스 권한 정보를 확인하지 못했습니다.')
    for name, expected in (('Uid', uid), ('Gid', gid)):
        values = fields[name].split()
        if len(values) != 4 or any(not value.isdecimal() or int(value) != expected for value in values):
            raise ValueError('프로세스 계정이 예상과 다릅니다.')
    groups = fields['Groups'].split()
    if any(not value.isdecimal() or int(value) != gid for value in groups):
        raise ValueError('예상하지 않은 보조 그룹이 있습니다.')
    for name in ('CapInh', 'CapPrm', 'CapEff', 'CapAmb'):
        if not re.fullmatch(r'[0-9A-Fa-f]+', fields[name]) or int(fields[name], 16) != 0:
            raise ValueError('프로세스 capability가 비어 있지 않습니다.')
    if fields['NoNewPrivs'] != '1':
        raise ValueError('프로세스의 NoNewPrivileges가 적용되지 않았습니다.')


def unit_identity(unit, expected_user, expected_group):
    if not re.fullmatch(r'[a-zA-Z0-9_.@-]+\.service', unit):
        raise ValueError('서비스 이름 오류')
    output = subprocess.run(
        ['/usr/bin/systemctl', 'show', '--all', unit, '-p', 'LoadState', '-p', 'ActiveState',
         '-p', 'SubState', '-p', 'MainPID', '-p', 'Job', '-p', 'User', '-p', 'Group'],
        check=True, capture_output=True, text=True, timeout=10,
    ).stdout
    fields = {}
    for line in output.splitlines():
        key, separator, value = line.partition('=')
        if not separator or key in fields:
            raise ValueError('서비스 속성 형식 오류')
        fields[key] = value
    pid = fields.get('MainPID', '')
    if (fields.get('LoadState') != 'loaded' or fields.get('ActiveState') != 'active'
            or fields.get('SubState') != 'running' or fields.get('Job') != ''
            or fields.get('User') != expected_user or fields.get('Group') != expected_group
            or not pid.isdecimal() or int(pid) <= 1):
        raise ValueError('gate 서비스 계정 또는 실행 상태 오류')
    return int(pid)


def starttime(pid):
    text = (PROC / str(pid) / 'stat').read_text(encoding='ascii')
    close = text.rfind(')')
    fields = text[close + 1:].split() if close >= 0 else []
    if len(fields) <= 19 or not fields[19].isdecimal():
        raise ValueError('프로세스 시작 시각 오류')
    return fields[19]


def observe(unit='bc250-llm-gate.service', client_user='yeppyshiba'):
    if os.geteuid() != 0 or not re.fullmatch(r'[a-z_][a-z0-9_-]{0,31}', client_user):
        raise ValueError('root와 유효한 Client 계정이 필요합니다.')
    gate = pwd.getpwnam('ai-gate')
    studio = pwd.getpwnam('ai-studio')
    client = pwd.getpwnam(client_user)
    gid = grp.getgrnam('ai-gate').gr_gid
    if 0 in (gate.pw_uid, studio.pw_uid, client.pw_uid, gid) or len({gate.pw_uid, studio.pw_uid, client.pw_uid}) != 3:
        raise ValueError('gate·Studio·Client 계정 UID가 분리되지 않았습니다.')
    pid = unit_identity(unit, 'ai-gate', 'ai-gate')
    initial = starttime(pid)
    process_credentials((PROC / str(pid) / 'status').read_text(encoding='ascii'), gate.pw_uid, gid)
    if unit_identity(unit, 'ai-gate', 'ai-gate') != pid or starttime(pid) != initial:
        raise ValueError('검사 중 gate 서비스가 재시작됐습니다.')
    return (pid, initial, gate.pw_uid, gid)


def _uid_threads(uid, gid, gate_pid):
    """Inspect visible thread credentials; disappearing entries abort the scan."""
    found = []
    for process in PROC.iterdir():
        if not process.name.isdecimal():
            continue
        pid = int(process.name)
        for task in (process / 'task').iterdir():
            if not task.name.isdecimal():
                raise ValueError('스레드 식별자 형식 오류')
            tid = int(task.name)
            status = (task / 'status').read_text(encoding='utf-8', errors='surrogateescape')
            values = [line.split()[1:] for line in status.splitlines() if line.startswith('Uid:')]
            if (len(values) != 1 or len(values[0]) != 4
                    or any(not value.isdecimal() for value in values[0])):
                raise ValueError('스레드 UID를 확인하지 못했습니다.')
            if uid not in (int(value) for value in values[0]):
                continue
            if pid != gate_pid:
                raise ValueError('gate와 같은 UID를 사용하는 다른 프로세스가 있습니다.')
            process_credentials(status, uid, gid)
            found.append((pid, tid, starttime(tid)))
    if not found or not any(pid == gate_pid and tid == gate_pid for pid, tid, _ in found):
        raise ValueError('gate 주 스레드를 확인하지 못했습니다.')
    return tuple(sorted(found))


def observe_exclusive(unit='bc250-llm-gate.service', client_user='yeppyshiba'):
    """Momentarily reject other visible processes using the gate UID.

    This scan does not prevent later process creation, socket transfer, hidden
    tasks, or provide a continuous isolation guarantee.
    """
    for _ in range(5):
        try:
            identity = observe(unit=unit, client_user=client_user)
            pid, _, uid, gid = identity
            before = _uid_threads(uid, gid, pid)
            after = _uid_threads(uid, gid, pid)
            if before != after or observe(unit=unit, client_user=client_user) != identity:
                raise ValueError('gate 스레드 또는 세대가 관찰 중 변경됐습니다.')
            return identity
        except (FileNotFoundError, ProcessLookupError):
            continue
    raise ValueError('프로세스 종료 경합으로 gate UID를 확인하지 못했습니다.')


if __name__ == '__main__':
    try:
        observe()
    except (OSError, ValueError, KeyError, subprocess.SubprocessError):
        raise SystemExit('gate 계정과 프로세스 권한 확인 실패') from None
    print('gate·Studio·Client 계정 분리와 gate 주 프로세스 권한 확인')
    print('순간 관찰이며 다른 프로세스·다른 접근 경로나 지속 차단은 확인하지 않습니다.')
