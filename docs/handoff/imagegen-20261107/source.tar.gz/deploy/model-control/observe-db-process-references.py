#!/usr/bin/env python3
"""Observe selected process references to a DB tree; this does not fence writers.

The caller must supply a PID and trusted paths. This does not enumerate other
processes, stop new opens, or establish safe deployment.
"""
import os
import re
import stat
from pathlib import Path

PROC = Path('/proc')


def watched_paths(data_root, database):
    root, db = Path(data_root), Path(database)
    if not root.is_absolute() or not db.is_absolute() or '..' in root.parts or '..' in db.parts:
        raise ValueError('절대 경로가 필요합니다.')
    relative = db.relative_to(root)
    if not relative.parts or db.name in {'.', '..'}:
        raise ValueError('데이터베이스 경로가 올바르지 않습니다.')
    directories = [root]
    for part in relative.parts[:-1]:
        directories.append(directories[-1] / part)
    targets = []
    for path in directories:
        info = path.lstat()
        if not stat.S_ISDIR(info.st_mode):
            raise ValueError('데이터 경로의 디렉터리가 올바르지 않습니다.')
        targets.append((str(path), info.st_dev, info.st_ino))
    for path in (db, *(Path(str(db) + suffix) for suffix in ('-wal', '-shm', '-journal'))):
        try:
            info = path.lstat()
        except FileNotFoundError:
            targets.append((str(path), None, None))
            continue
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ValueError('데이터베이스 파일이 단일 링크의 일반 파일이 아닙니다.')
        targets.append((str(path), info.st_dev, info.st_ino))
    if targets[len(directories)][1] is None:
        raise ValueError('데이터베이스가 없습니다.')
    return tuple(targets)


def process_starttime(pid):
    text = (PROC / str(pid) / 'stat').read_text(encoding='ascii')
    end = text.rfind(')')
    values = text[end + 1:].split() if end >= 0 else []
    if len(values) <= 19 or not values[19].isdecimal():
        raise ValueError('프로세스 시작 시각 오류')
    return values[19]


def mapped_entries(text):
    if not isinstance(text, str) or not text.strip():
        raise ValueError('프로세스 메모리 매핑이 비어 있습니다.')
    result = []
    for line in text.splitlines():
        fields = line.split(maxsplit=5)
        if (len(fields) < 5 or not re.fullmatch(r'[0-9a-fA-F]+-[0-9a-fA-F]+', fields[0])
                or not re.fullmatch(r'[r-][w-][x-][ps]', fields[1])
                or not re.fullmatch(r'[0-9a-fA-F]+', fields[2])
                or not re.fullmatch(r'[0-9a-fA-F]+:[0-9a-fA-F]+', fields[3])
                or not fields[4].isdecimal()):
            raise ValueError('프로세스 메모리 매핑 형식 오류')
        major, minor = (int(value, 16) for value in fields[3].split(':'))
        inode = int(fields[4])
        if inode:
            result.append((fields[0], os.makedev(major, minor), inode))
    return result


def mapped_inodes(text):
    return {(device, inode) for _, device, inode in mapped_entries(text)}


def classify_mappings(pid, entries, watched):
    watched_inodes = {inode for _, inode in watched}
    uncertain = False
    for address, device, inode in entries:
        if (device, inode) in watched:
            return 'mapping'
        if inode not in watched_inodes:
            continue
        # Some filesystems report different device IDs in stat and maps.
        # Resolve the actual mapped object; failure is uncertainty, not absence.
        try:
            info = (PROC / str(pid) / 'map_files' / address).stat()
        except OSError:
            uncertain = True
            continue
        if (info.st_dev, info.st_ino) in watched:
            return 'mapping'
        uncertain = True
    return 'mapping-ambiguous' if uncertain else None


def observe_process(pid, data_root, database):
    if os.geteuid() != 0 or type(pid) is not int or pid <= 1:
        raise ValueError('root와 유효한 PID가 필요합니다.')
    watched = watched_paths(data_root, database)
    inodes = {(device, inode) for _, device, inode in watched if device is not None}
    started = process_starttime(pid)
    process = PROC / str(pid)
    found = set()
    for path in (process / 'cwd', process / 'root'):
        info = path.stat()
        if (info.st_dev, info.st_ino) in inodes:
            found.add(path.name)
    for entry in (process / 'fd').iterdir():
        if not entry.name.isdecimal():
            raise ValueError('파일 디스크립터 형식 오류')
        info = entry.stat()
        if (info.st_dev, info.st_ino) in inodes:
            found.add('fd')
    mapped = mapped_entries((process / 'maps').read_text(encoding='utf-8', errors='surrogateescape'))
    classification = classify_mappings(pid, mapped, inodes)
    if classification:
        found.add(classification)
    watched_inodes = {inode for _, inode in inodes}
    after = mapped_entries((process / 'maps').read_text(encoding='utf-8', errors='surrogateescape'))
    if ({entry for entry in mapped if entry[2] in watched_inodes}
            != {entry for entry in after if entry[2] in watched_inodes}):
        raise ValueError('검사 중 데이터베이스 매핑이 변경됐습니다.')
    if process_starttime(pid) != started or watched_paths(data_root, database) != watched:
        raise ValueError('검사 중 프로세스 또는 데이터 경로가 변경됐습니다.')
    return frozenset(found)


def observe_known_processes(pids, data_root, database):
    """Observe only the explicitly supplied PIDs; incomplete lists are not safe."""
    if (not isinstance(pids, (tuple, list)) or not pids or
            any(type(pid) is not int or pid <= 1 for pid in pids) or len(set(pids)) != len(pids)):
        raise ValueError('중복 없는 시험 PID 목록이 필요합니다.')
    watched = watched_paths(data_root, database)
    starts = {pid: process_starttime(pid) for pid in pids}
    results = {pid: observe_process(pid, data_root, database) for pid in pids}
    if watched_paths(data_root, database) != watched:
        raise ValueError('여러 프로세스 검사 중 데이터 경로가 변경됐습니다.')
    if any(process_starttime(pid) != starts[pid] for pid in pids):
        raise ValueError('여러 프로세스 검사 중 프로세스가 변경됐습니다.')
    return results


def observe_known_thread(pid, tid, data_root, database):
    """Observe one explicitly identified thread; this does not enumerate threads."""
    if type(pid) is not int or type(tid) is not int or pid <= 1 or tid <= 1:
        raise ValueError('유효한 프로세스와 스레드 ID가 필요합니다.')
    task = PROC / str(pid) / 'task' / str(tid)
    task.stat()
    process_started = process_starttime(pid)
    thread_started = process_starttime(tid)
    result = observe_process(tid, data_root, database)
    task.stat()
    if process_starttime(pid) != process_started or process_starttime(tid) != thread_started:
        raise ValueError('검사 중 프로세스 또는 스레드가 변경됐습니다.')
    return result


def process_threads(pid):
    entries = (PROC / str(pid) / 'task').iterdir()
    tids = [int(entry.name) for entry in entries if entry.name.isdecimal()]
    if not tids or pid not in tids:
        raise ValueError('프로세스 스레드 목록이 올바르지 않습니다.')
    return {tid: process_starttime(tid) for tid in tids}


def observe_process_threads(pid, data_root, database):
    """Observe a process's listed threads twice; this is not a writer fence."""
    if os.geteuid() != 0 or type(pid) is not int or pid <= 1:
        raise ValueError('root와 유효한 PID가 필요합니다.')
    watched = watched_paths(data_root, database)
    before = process_threads(pid)
    result = {tid: observe_known_thread(pid, tid, data_root, database) for tid in before}
    if process_threads(pid) != before or watched_paths(data_root, database) != watched:
        raise ValueError('검사 중 스레드 목록 또는 데이터 경로가 변경됐습니다.')
    return result


def process_uids(pid):
    text = (PROC / str(pid) / 'status').read_text(encoding='utf-8', errors='surrogateescape')
    values = [line.partition(':')[2].split() for line in text.splitlines() if line.startswith('Uid:')]
    if len(values) != 1 or len(values[0]) != 4 or any(not item.isdecimal() for item in values[0]):
        raise ValueError('프로세스 UID 정보를 확인하지 못했습니다.')
    return tuple(int(item) for item in values[0])


def selected_uid_pids(uid):
    """Retry vanished processes; other unreadable or unstable state is an error."""
    if os.geteuid() != 0 or type(uid) is not int or uid <= 0:
        raise ValueError('root와 비root UID가 필요합니다.')
    for _ in range(5):
        try:
            return _selected_uid_pids_once(uid)
        except FileNotFoundError:
            # A listed process may exit before /proc is read. Restart the whole
            # enumeration rather than treat that entry as a negative result.
            continue
    raise ValueError('프로세스 목록이 계속 변경되어 UID를 관찰하지 못했습니다.')


def _selected_uid_pids_once(uid):
    selected = {}
    for entry in PROC.iterdir():
        if not entry.name.isdecimal():
            continue
        pid = int(entry.name)
        uids = process_uids(pid)
        if uid not in uids:
            continue
        started = process_starttime(pid)
        if process_uids(pid) != uids:
            raise ValueError('UID 관찰 중 프로세스 자격이 변경됐습니다.')
        selected[pid] = (started, uids)
    return selected


def observe_uid_processes(uid, data_root, database):
    """Observe a single UID twice; this does not block or cover other identities."""
    watched = watched_paths(data_root, database)
    before = selected_uid_pids(uid)
    if not before:
        raise ValueError('관찰 대상 UID의 프로세스가 없습니다.')
    result = observe_known_processes(sorted(before), data_root, database)
    after = selected_uid_pids(uid)
    if before != after or watched_paths(data_root, database) != watched:
        raise ValueError('DB 관찰 중 UID 프로세스 목록이 변경됐습니다.')
    return result


def observe_uid_process_threads(uid, data_root, database):
    """Observe visible process leaders and their threads for one UID, momentarily."""
    watched = watched_paths(data_root, database)
    before = selected_uid_pids(uid)
    if not before:
        raise ValueError('관찰 대상 UID의 프로세스가 없습니다.')
    results = {pid: observe_process_threads(pid, data_root, database) for pid in before}
    if selected_uid_pids(uid) != before or watched_paths(data_root, database) != watched:
        raise ValueError('DB 관찰 중 UID 프로세스 목록이 변경됐습니다.')
    return results


def observe_known_uids(uids, data_root, database):
    """Observe explicitly listed UIDs only; the list may omit writers."""
    if (not isinstance(uids, (tuple, list)) or not uids
            or any(type(uid) is not int or uid <= 0 for uid in uids)
            or len(set(uids)) != len(uids)):
        raise ValueError('중복 없는 비root UID 목록이 필요합니다.')
    watched = watched_paths(data_root, database)
    before = {uid: selected_uid_pids(uid) for uid in uids}
    if any(not processes for processes in before.values()):
        raise ValueError('관찰 대상 UID의 프로세스가 없습니다.')
    results = {uid: observe_uid_process_threads(uid, data_root, database) for uid in uids}
    after = {uid: selected_uid_pids(uid) for uid in uids}
    if before != after or watched_paths(data_root, database) != watched:
        raise ValueError('여러 UID 관찰 중 프로세스 또는 데이터 경로가 변경됐습니다.')
    return results
