#!/usr/bin/env bash
# Shared archive operation. The production caller must first verify quiescence.
bc250_require_stopped() {
  local unit properties guard_dir
  guard_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || return 1
  for unit in "$@"; do
    properties="$(systemctl show --all "$unit" -p LoadState -p ActiveState -p MainPID -p Job -p KillMode -p ControlGroup -p Slice)" || return 1
    properties+=$'\n'
    [[ $properties == *$'LoadState=loaded\n'* && $properties == *$'ActiveState=inactive\n'* \
      && $properties == *$'MainPID=0\n'* && $properties == *$'Job=\n'* \
      && $properties == *$'KillMode=control-group\n'* ]] || {
      echo "서비스의 완전한 정지를 확인하지 못했습니다: $unit" >&2; return 1;
    }
    python3 "$guard_dir/check-service-cgroup.py" "$unit" "$properties" || return 1
  done
}

bc250_backup_archive() {
  local source_root=$1 backup=$2 caddy_original=$3
  # Experimental only: the caller must maintain and verify a real fence.
  local staged_root=${4:-} db_path=opt/ai-studio-data/database/studio.sqlite3
  local -a paths=(opt/bc250-ai-studio opt/ai-studio-data
    etc/bc250-ai-studio.env etc/bc250-llm-gate.env etc/bc250-llm-client.env
    etc/systemd/system/bc250-ai-studio.service etc/systemd/system/bc250-llm-gate.service
    etc/systemd/system/bc250-llm-client.service opt/ai/config/active-model.conf
    var/lib/bc250-model-control/legacy-pause.json)
  local -a optional_dirs=(etc/systemd/system/bc250-ai-studio.service.d
    etc/systemd/system/bc250-llm-gate.service.d
    etc/systemd/system/bc250-llm-client.service.d)
  local path links
  for path in "${paths[@]}"; do
    [[ -e $source_root/$path && ! -L $source_root/$path ]] || {
      echo "백업 대상 확인 실패: $path" >&2; return 1;
    }
  done
  for path in "${optional_dirs[@]}"; do
    if [[ -e $source_root/$path || -L $source_root/$path ]]; then
      [[ -d $source_root/$path && ! -L $source_root/$path ]] || {
        echo "백업 대상 디렉터리 확인 실패: $path" >&2; return 1;
      }
      links=$(find "$source_root/$path" -type l -print -quit) || return 1
      [[ -z $links ]] || {
        echo "drop-in에 심볼릭 링크가 있어 복구 범위를 확인할 수 없습니다: $path" >&2; return 1;
      }
      paths+=("$path")
    fi
  done
  if [[ -n $staged_root ]]; then
    [[ $(type -t bc250_check_db_fence) == function ]] || {
      echo '검증된 DB 차단 검사기가 필요합니다.' >&2; return 1;
    }
    bc250_check_db_fence || return 1
    python3 - "$staged_root" "$db_path" <<'PY' || return 1
import os
import stat
import sys
from pathlib import Path

root, relative = Path(sys.argv[1]), Path(sys.argv[2])
if os.geteuid() != 0 or not root.is_absolute() or '..' in root.parts:
    raise SystemExit('복사본 경로를 신뢰할 수 없습니다.')
target = root / relative
for path in (target.parent, *target.parent.parents):
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
        raise SystemExit('복사본 디렉터리를 신뢰할 수 없습니다.')
if stat.S_IMODE(root.stat().st_mode) != 0o700:
    raise SystemExit('복사본 루트는 root 전용이어야 합니다.')
info = target.lstat()
if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
    raise SystemExit('복사본 DB가 단일 링크의 일반 파일이 아닙니다.')
PY
    for path in "$source_root/$db_path"{,-wal,-shm,-journal}; do
      if [[ $path == "$source_root/$db_path" ]]; then
        [[ -f $path && ! -L $path ]] || { echo '원본 DB가 없습니다.' >&2; return 1; }
      else
        [[ ! -e $path && ! -L $path ]] || { echo 'SQLite 부수 파일이 남아 있습니다.' >&2; return 1; }
      fi
    done
    bc250_check_db_fence || return 1
  fi
  cp -a -- "$caddy_original" "$backup/Caddyfile.original" || return 1
  python3 - "$caddy_original" "$backup/Caddyfile.original" <<'PY' || return 1
import os
import stat
import sys

source, saved = sys.argv[1:]
a = os.stat(source, follow_symlinks=False)
b = os.stat(saved, follow_symlinks=False)
if (not stat.S_ISREG(a.st_mode) or not stat.S_ISREG(b.st_mode)
        or (a.st_uid, a.st_gid, a.st_mode) != (b.st_uid, b.st_gid, b.st_mode)):
    raise SystemExit('Caddyfile 소유권 또는 권한이 백업과 다릅니다.')
attrs = set(os.listxattr(source, follow_symlinks=False))
if attrs != set(os.listxattr(saved, follow_symlinks=False)):
    raise SystemExit('Caddyfile 확장 속성 목록이 백업과 다릅니다.')
for attr in attrs:
    if (os.getxattr(source, attr, follow_symlinks=False)
            != os.getxattr(saved, attr, follow_symlinks=False)):
        raise SystemExit('Caddyfile 확장 속성이 백업과 다릅니다.')
PY
  if [[ -n $staged_root ]]; then
    tar --create --file="$backup/legacy.tar" --acls --xattrs --xattrs-include='*' \
      --selinux --numeric-owner --exclude="$db_path" --directory="$source_root" -- "${paths[@]}" || return 1
    bc250_check_db_fence || return 1
    tar --append --file="$backup/legacy.tar" --acls --xattrs --xattrs-include='*' \
      --selinux --numeric-owner --directory="$staged_root" -- "$db_path" || return 1
    bc250_check_db_fence || return 1
    python3 - "$backup/legacy.tar" "$db_path" <<'PY' || return 1
import sys
import tarfile

with tarfile.open(sys.argv[1], 'r') as archive:
    entries = [member for member in archive if member.name == sys.argv[2]]
    if len(entries) != 1 or not entries[0].isreg():
        raise SystemExit('아카이브의 DB 복사본이 정확히 하나가 아닙니다.')
PY
    for path in "$source_root/$db_path"{-wal,-shm,-journal}; do
      [[ ! -e $path && ! -L $path ]] || { echo 'SQLite 부수 파일이 생겼습니다.' >&2; return 1; }
    done
  else
    tar --create --file="$backup/legacy.tar" --acls --xattrs --xattrs-include='*' \
      --selinux --numeric-owner --directory="$source_root" -- "${paths[@]}" || return 1
  fi
  tar --list --file="$backup/legacy.tar" >/dev/null || return 1
  (
    cd "$backup" || exit 1
    sha256sum legacy.tar Caddyfile.original > SHA256SUMS || exit 1
    sha256sum -c SHA256SUMS >/dev/null || exit 1
  ) || return 1
  sync -f "$backup/legacy.tar" || return 1
  sync -f "$backup/Caddyfile.original" || return 1
  sync -f "$backup/SHA256SUMS" || return 1
  sync -f "$backup" || return 1
  if [[ -n $staged_root ]]; then bc250_check_db_fence || return 1; fi
}
