#!/usr/bin/env python3
"""Candidate connecting startup and cooperative GPU handoff; not an entry point.

The caller must construct both objects using independently verified, maintained
GPU, gate hold, direct-caller and service-generation controls. The startup
sequence releases the lock before confirmation, which must reacquire it itself.
This wrapper supplies no such controls and has no crash recovery.
"""


class LockedServiceStartError(RuntimeError):
    pass


class LockedServiceStart:
    def __init__(self, startup, lock_sequence):
        if (not all(callable(getattr(startup, name, None)) for name in
                    ('start', 'prepare_confirmation', 'confirm_startup'))
                or not all(callable(getattr(lock_sequence, name, None)) for name in
                           ('begin', 'confirm_after_client_restart', 'check_deployment_hold'))
                or not callable(getattr(getattr(lock_sequence, 'handoff', None), 'check', None))
                or getattr(lock_sequence, 'confirm', None) != startup.confirm_startup):
            raise ValueError('동일한 시작 확인과 검증된 잠금 인계가 필요합니다.')
        self.startup, self.lock = startup, lock_sequence
        self.phase = 'new'

    def start(self):
        if self.phase != 'new':
            raise LockedServiceStartError('서비스 시작 단계를 다시 실행할 수 없습니다.')
        self.phase = 'failed'
        try:
            self.startup.start()
            if self.lock.begin() is not True:
                raise LockedServiceStartError('수동 대기 전 잠금 인계 준비 실패')
            self.phase = 'await_client'
        except Exception as error:
            raise LockedServiceStartError('서비스 시작 또는 잠금 준비가 중단됐습니다.') from error

    def finish(self):
        if self.phase != 'await_client':
            raise LockedServiceStartError('Client 수동 재시작 대기 상태가 아닙니다.')
        self.phase = 'failed'
        try:
            if self.lock.check_deployment_hold() is not True or self.lock.handoff.check() is not True:
                raise LockedServiceStartError('검증 전 보류 또는 GPU 잠금 확인 실패')
            self.startup.prepare_confirmation()
            if self.lock.confirm_after_client_restart() is not True:
                raise LockedServiceStartError('시작 확인과 잠금 인계 실패')
            self.phase = 'complete'
        except Exception as error:
            raise LockedServiceStartError('Client 검증 또는 잠금 인계가 중단됐습니다.') from error
