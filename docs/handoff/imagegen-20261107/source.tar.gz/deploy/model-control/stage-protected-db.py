#!/usr/bin/env python3
"""Experimental DB staging from a held FD; caller must supply a real fence.

This copies one regular file only. It does not acquire a lease, fence writers,
handle WAL/SHM, copy the rest of Studio data, or authorize deployment.
"""
import hashlib
import os
import stat
from pathlib import Path

MAX_SIZE = 4 * 1024 * 1024 * 1024


def attributes(fd):
    return {name: os.getxattr(fd, name) for name in os.listxattr(fd)}


def identity(info):
    return (info.st_dev, info.st_ino, info.st_nlink, info.st_uid, info.st_gid,
            stat.S_IMODE(info.st_mode), info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def trusted_directory(path):
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts:
        raise ValueError('정규화된 절대 경로가 필요합니다.')
    for item in (path, *path.parents):
        info = item.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise ValueError('신뢰할 수 없는 복사본 디렉터리입니다.')
    if stat.S_IMODE(path.stat().st_mode) != 0o700:
        raise ValueError('복사본 디렉터리는 root 전용이어야 합니다.')
    return path


def stage_file(source_fd, directory, name, *, check_fence):
    if (os.geteuid() != 0 or type(source_fd) is not int or source_fd < 0
            or not isinstance(name, str) or not name or name in ('.', '..')
            or '/' in name or not callable(check_fence)):
        raise ValueError('root와 검증된 파일·차단 검사기가 필요합니다.')
    directory = trusted_directory(directory)
    if check_fence() is not True:
        raise ValueError('복사 전 차단을 확인하지 못했습니다.')
    before = os.fstat(source_fd)
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > MAX_SIZE:
        raise ValueError('단일 링크 일반 DB 파일이 필요합니다.')
    xattrs = attributes(source_fd)
    parent_fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    target_fd = None
    try:
        target_fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                            0o600, dir_fd=parent_fd)
        digest = hashlib.sha256()
        position = 0
        while position < before.st_size:
            block = os.pread(source_fd, min(1024 * 1024, before.st_size - position), position)
            if not block:
                raise ValueError('DB 복사 중 파일이 짧아졌습니다.')
            digest.update(block)
            remaining = memoryview(block)
            while remaining:
                written = os.write(target_fd, remaining)
                if written <= 0:
                    raise OSError('DB 복사본 쓰기 실패')
                remaining = remaining[written:]
            position += len(block)
        if check_fence() is not True or identity(os.fstat(source_fd)) != identity(before):
            raise ValueError('DB 복사 중 차단 또는 파일이 변경됐습니다.')
        if attributes(source_fd) != xattrs:
            raise ValueError('DB 복사 중 확장 속성이 변경됐습니다.')
        os.fchown(target_fd, before.st_uid, before.st_gid)
        os.fchmod(target_fd, stat.S_IMODE(before.st_mode))
        for attr, value in xattrs.items():
            os.setxattr(target_fd, attr, value)
        os.utime(target_fd, ns=(before.st_atime_ns, before.st_mtime_ns))
        os.fsync(target_fd)
        target = os.fstat(target_fd)
        if ((target.st_uid, target.st_gid, stat.S_IMODE(target.st_mode), target.st_size, target.st_mtime_ns)
                != (before.st_uid, before.st_gid, stat.S_IMODE(before.st_mode), before.st_size, before.st_mtime_ns)
                or attributes(target_fd) != xattrs or check_fence() is not True
                or identity(os.fstat(source_fd)) != identity(before) or attributes(source_fd) != xattrs):
            raise ValueError('복사본의 메타데이터 또는 차단 확인 실패')
        os.fsync(parent_fd)
        return digest.hexdigest()
    finally:
        if target_fd is not None:
            os.close(target_fd)
        os.close(parent_fd)
