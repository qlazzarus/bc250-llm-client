#!/usr/bin/env python3
"""Experimental nft direct-caller fence, not an operational entry point.

Only IPv4 loopback traffic to one port in the current network namespace is
filtered. The caller must establish all other barriers, identify the real gate,
cover existing connections and other namespaces, and handle crash recovery.
A failed check is latched and never automatically removes or reapproves rules.
"""
import json
import os
import re
import secrets
import stat
import subprocess
from pathlib import Path

NFT = '/usr/sbin/nft'
SYSTEMCTL = '/usr/bin/systemctl'
CGROUP = Path('/sys/fs/cgroup')
PROC = Path('/proc')


def unit_snapshot(unit):
    if not isinstance(unit, str) or re.fullmatch(r'[A-Za-z0-9_.@-]+\.service', unit) is None:
        raise ValueError('gate unit 이름 오류')
    result = subprocess.run([SYSTEMCTL, 'show', '--all', unit, '-p', 'LoadState', '-p', 'ActiveState',
                             '-p', 'SubState', '-p', 'MainPID', '-p', 'Job', '-p', 'ControlGroup'],
                            check=True, capture_output=True, text=True, timeout=10)
    fields = {}
    for line in result.stdout.splitlines():
        key, sep, value = line.partition('=')
        if not sep or key in fields:
            raise ValueError('gate systemd 응답 오류')
        fields[key] = value
    pid = fields.get('MainPID', '')
    group = fields.get('ControlGroup', '')
    if (fields.get('LoadState') != 'loaded' or fields.get('ActiveState') != 'active'
            or fields.get('SubState') != 'running' or fields.get('Job') != ''
            or not pid.isdecimal() or int(pid) <= 1 or group != '/system.slice/' + unit):
        raise ValueError('gate 실행 상태 또는 cgroup 오류')
    pid = int(pid)
    entry = (CGROUP / group.lstrip('/')).lstat()
    if not stat.S_ISDIR(entry.st_mode):
        raise ValueError('gate cgroup 확인 실패')
    cgroups = (PROC / str(pid) / 'cgroup').read_text(encoding='ascii').splitlines()
    if cgroups != ['0::' + group]:
        raise ValueError('gate 프로세스의 cgroup 불일치')
    text = (PROC / str(pid) / 'stat').read_text(encoding='ascii')
    end = text.rfind(')')
    values = text[end + 1:].split() if end >= 0 else []
    if len(values) <= 19 or not values[19].isdecimal():
        raise ValueError('gate 프로세스 시작 시각 오류')
    return pid, values[19], group, entry.st_dev, entry.st_ino


def canonical_nft(document):
    """Ignore nft output metadata/handles; retain rules, chain and table content."""
    if not isinstance(document, dict) or set(document) != {'nftables'} or not isinstance(document['nftables'], list):
        raise ValueError('nft 응답 형식 오류')

    def strip(value):
        if isinstance(value, dict):
            return {key: strip(item) for key, item in value.items() if key != 'handle'}
        if isinstance(value, list):
            return [strip(item) for item in value]
        return value

    entries = [strip(item) for item in document['nftables'] if not (isinstance(item, dict) and 'metainfo' in item)]
    if not entries or any(not isinstance(item, dict) or len(item) != 1 for item in entries):
        raise ValueError('nft 테이블 내용 오류')
    return entries


class DirectLLMNftFence:
    def __init__(self, unit, *, port, verify_gate, check_scope, check_barriers,
                 coordinator_unit=None, verify_coordinator=None):
        if (os.geteuid() != 0 or not isinstance(unit, str)
                or re.fullmatch(r'[A-Za-z0-9_.@-]+\.service', unit) is None
                or type(port) is not int or not 1 <= port <= 65535
                or not all(callable(value) for value in (verify_gate, check_scope, check_barriers))
                or ((coordinator_unit is None) != (verify_coordinator is None))
                or (coordinator_unit is not None and (not isinstance(coordinator_unit, str)
                    or re.fullmatch(r'[A-Za-z0-9_.@-]+\.service', coordinator_unit) is None
                    or coordinator_unit == unit or not callable(verify_coordinator)))):
            raise ValueError('root와 gate·네임스페이스·기타 차단 검사가 필요합니다.')
        self.unit, self.port = unit, port
        self.verify_gate, self.check_scope, self.check_barriers = verify_gate, check_scope, check_barriers
        self.coordinator_unit, self.verify_coordinator = coordinator_unit, verify_coordinator
        self.table = 'bc250_direct_' + secrets.token_hex(8)
        self.phase = 'new'
        self.expected = None
        self.gate = None
        self.coordinator = None
        self.gate_stopped = None
        self.namespace = None

    def _nft(self, args, *, data=None):
        return subprocess.run([NFT, *args], input=data, text=True, capture_output=True, check=True, timeout=15).stdout

    def _namespace(self):
        info = (PROC / 'self/ns/net').stat()
        return info.st_dev, info.st_ino

    def _table(self):
        return canonical_nft(json.loads(self._nft(['-j', 'list', 'table', 'inet', self.table])))

    def _common_conditions(self):
        if (self._namespace() != self.namespace or self.check_scope() is not True
                or self.check_barriers() is not True):
            raise ValueError('네임스페이스 또는 다른 차단 조건이 변경됐습니다.')
        if self.coordinator_unit is not None:
            coordinator = unit_snapshot(self.coordinator_unit)
            if coordinator != self.coordinator or self.verify_coordinator(coordinator) is not True:
                raise ValueError('배포 조율기 세대 또는 권한이 변경됐습니다.')

    def _conditions(self):
        if self.phase == 'retired':
            gate_valid = self.gate_stopped is not None and self.gate_stopped() is True
        else:
            gate = unit_snapshot(self.unit)
            gate_valid = gate == self.gate and self.verify_gate(gate) is True
        if not gate_valid:
            raise ValueError('gate 세대 또는 정지 조건이 변경됐습니다.')
        self._common_conditions()

    def _rules(self, *, include_gate):
        group = self.gate[2].lstrip('/')
        gate_rule = (f'  ip daddr 127.0.0.1 tcp dport {self.port} '
                     f'socket cgroupv2 level 2 "{group}" accept\n') if include_gate else ''
        coordinator_rule = ''
        if self.coordinator is not None:
            coordinator_group = self.coordinator[2].lstrip('/')
            coordinator_rule = (f'  ip daddr 127.0.0.1 tcp dport {self.port} '
                                f'socket cgroupv2 level 2 "{coordinator_group}" accept\n')
        return (f'table inet {self.table} {{\n chain output {{\n'
                '  type filter hook output priority 0; policy accept;\n'
                f'{gate_rule}{coordinator_rule}'
                f'  ip daddr 127.0.0.1 tcp dport {self.port} reject\n'
                ' }\n}\n')

    def acquire(self):
        if self.phase != 'new':
            raise ValueError('직접 호출 차단은 자동 재시도할 수 없습니다.')
        self.phase = 'failed'
        self.namespace = self._namespace()
        self.gate = unit_snapshot(self.unit)
        if self.coordinator_unit is not None:
            self.coordinator = unit_snapshot(self.coordinator_unit)
        self._conditions()
        tables = json.loads(self._nft(['-j', 'list', 'tables']))
        if not isinstance(tables, dict) or not isinstance(tables.get('nftables'), list):
            raise ValueError('nft 테이블 목록 오류')
        if any(isinstance(item, dict) and item.get('table', {}).get('family') == 'inet'
               and item['table'].get('name') == self.table for item in tables['nftables']):
            raise ValueError('차단 테이블 이름이 이미 존재합니다.')
        rules = self._rules(include_gate=True)
        self._nft(['--check', '--file', '-'], data=rules)
        self._conditions()
        self._nft(['--file', '-'], data=rules)
        self.expected = self._table()
        self._conditions()
        if self._table() != self.expected:
            raise ValueError('직접 호출 차단 설치 중 규칙이 변경됐습니다.')
        self.phase = 'active'
        return True

    def check(self):
        if self.phase not in ('active', 'retired'):
            return False
        try:
            self._conditions()
            if self._table() != self.expected:
                raise ValueError('직접 호출 차단 규칙이 변경됐습니다.')
            self._conditions()
            return True
        except Exception:
            self.phase = 'lost'
            return False

    def retire_gate(self, *, check_drained, stop_gate, check_stopped):
        """Block gate first, stop it, then keep only the coordinator allow rule.

        Callbacks must independently prove gate drain and complete persistent
        stop, including restart prevention. A failure preserves the table and
        is not automatically resumable.
        """
        if (self.phase != 'active' or self.coordinator is None
                or not all(callable(value) for value in (check_drained, stop_gate, check_stopped))):
            raise ValueError('조율기와 검증된 gate 정지 조건이 필요합니다.')
        try:
            if not self.check() or check_drained() is not True or not self.check():
                raise ValueError('gate drain 또는 차단 조건을 확인하지 못했습니다.')
            self.phase = 'transition'
            rules = f'delete table inet {self.table}\n' + self._rules(include_gate=False)
            self._nft(['--check', '--file', '-'], data=rules)
            self._conditions()
            if check_drained() is not True:
                raise ValueError('규칙 교체 전 gate drain이 변경됐습니다.')
            self._nft(['--file', '-'], data=rules)
            self.expected = self._table()
            self._conditions()
            if stop_gate() is not True or check_stopped() is not True:
                raise ValueError('gate 정지를 확인하지 못했습니다.')
            self.gate_stopped = check_stopped
            self.phase = 'retired'
            if not self.check():
                raise ValueError('gate 정지 후 차단 조건 확인 실패')
            return True
        except Exception:
            self.phase = 'failed'
            raise

    def restore_gate(self, *, start_gate, check_held):
        """Start an isolated gate, verify its hold, then atomically allow it.

        The caller must keep ingress blocked and verify an authenticated gate
        hold and drain. A failed transition preserves rules and is not resumed.
        """
        if self.phase != 'retired' or not callable(start_gate) or not callable(check_held):
            raise ValueError('정지된 gate와 검증된 시작·보류 검사가 필요합니다.')
        try:
            if not self.check():
                raise ValueError('gate 복원 전 차단 상태를 확인하지 못했습니다.')
            self.phase = 'transition'
            self._common_conditions()
            if start_gate() is not True:
                raise ValueError('gate 시작을 확인하지 못했습니다.')
            gate = unit_snapshot(self.unit)
            if self.verify_gate(gate) is not True or check_held() is not True:
                raise ValueError('신규 gate 신원 또는 보류를 확인하지 못했습니다.')
            self._common_conditions()
            self.gate = gate
            rules = f'delete table inet {self.table}\n' + self._rules(include_gate=True)
            self._nft(['--check', '--file', '-'], data=rules)
            if unit_snapshot(self.unit) != gate or check_held() is not True:
                raise ValueError('gate 규칙 복원 전 상태가 변경됐습니다.')
            self._common_conditions()
            self._nft(['--file', '-'], data=rules)
            self.expected = self._table()
            self.phase = 'active'
            if not self.check() or check_held() is not True:
                raise ValueError('gate 규칙 복원 후 상태 확인 실패')
            return True
        except Exception:
            self.phase = 'failed'
            raise

    def release(self, *, can_release):
        try:
            if not callable(can_release) or not self.check() or can_release() is not True or not self.check():
                raise ValueError('차단 또는 해제 조건을 확인하지 못했습니다.')
        except Exception:
            self.phase = 'lost'
            raise
        self.phase = 'failed'
        self._nft(['delete', 'table', 'inet', self.table])
        self.phase = 'released'
        return True
