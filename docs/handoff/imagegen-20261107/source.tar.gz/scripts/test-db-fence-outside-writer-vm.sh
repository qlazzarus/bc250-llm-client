#!/usr/bin/env bash
# Disposable VM services and DB only; known-PID observation is not a real fence.
set -Eeuo pipefail
umask 077
[[ $(id -u) == 0 && $(hostname) == bc250-fedora43-test \
  && $(systemd-detect-virt) == qemu && $(getenforce) == Enforcing \
  && ( $# == 1 || ( $# == 2 && ( $2 == race || $2 == post-inspect || $2 == during-backup || $2 == during-verify ) ) ) ]] || exit 1
source_dir=$1
mode=${2:-ordinary}
records=$(mktemp -d /var/backups/bc250-db-fence-outside.XXXXXXXX)
data=$(mktemp -d /var/lib/bc250-db-fence-outside.XXXXXXXX)
control=$(mktemp -d /var/lib/bc250-db-fence-control.XXXXXXXX)
code=$(mktemp -d /opt/bc250-db-fence-outside.XXXXXXXX)
suffix=${records##*.}
[[ $suffix =~ ^[A-Za-z0-9]{8}$ ]] || exit 1
studio="bc250-db-studio-$suffix.service"
gate="bc250-db-gate-$suffix.service"
other="bc250-db-outside-$suffix.service"
marker=$records/blocked
for unit in "$studio" "$gate" "$other"; do
  [[ $(systemctl show "$unit" -p LoadState --value) == not-found \
    && ! -e /run/systemd/system/$unit && ! -e /etc/systemd/system/$unit ]] || exit 1
done
failure() {
  local bind="$records/backup-fixture/opt/ai-studio-data"
  if [[ -d $bind ]] && mountpoint -q "$bind"; then
    umount "$bind" || echo "시험 bind 마운트를 해제하지 못했습니다: $bind" >&2
  fi
  echo "시험 중단. 시험 unit·차단 표시·기록 보존: $studio $gate $other $records $data $control $code" >&2
}
trap failure ERR
chmod 0755 "$code"
chown ai-studio:ai-studio "$data" "$control"
chmod 0700 "$data" "$control"
cat > "$code/studio.py" <<'PY'
import sqlite3
import sys
import time
from pathlib import Path

data, control = map(Path, sys.argv[1:])
directory = data / 'database'
directory.mkdir(mode=0o700, exist_ok=True)
connection = sqlite3.connect(directory / 'studio.sqlite3')
connection.execute('PRAGMA journal_mode=WAL')
connection.execute('CREATE TABLE IF NOT EXISTS jobs (status TEXT)')
connection.execute('CREATE TABLE IF NOT EXISTS system_state (key TEXT, value TEXT)')
connection.commit()
(control / 'studio-ready').write_text('ready\n')
while True:
    time.sleep(1)
PY
cat > "$code/outsider.py" <<'PY'
import os
import sys
import time
from pathlib import Path

data, control = map(Path, sys.argv[1:])
fd = os.open(data / 'database', os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
(control / 'outside-ready').write_text('ready\n')
deadline = time.monotonic() + 300
first_closed = False
reopened = False
while not (control / 'stop').exists():
    if fd is not None and not first_closed and (control / 'close').exists():
        os.close(fd)
        fd = None
        first_closed = True
        (control / 'closed').write_text('closed\n')
    if fd is None and first_closed and not reopened and (control / 'reopen').exists():
        fd = os.open(data / 'database', os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
        reopened = True
        (control / 'reopened').write_text('reopened\n')
    if fd is not None and reopened and (control / 'close-again').exists():
        os.close(fd)
        fd = None
        (control / 'closed-again').write_text('closed\n')
    if time.monotonic() >= deadline: raise SystemExit('시험 대기 시간 초과')
    time.sleep(.1)
if fd is not None: os.close(fd)
PY
chmod 0644 "$code/studio.py" "$code/outsider.py"
for unit in "$studio" "$gate"; do
  if [[ $unit == "$studio" ]]; then
    command="/usr/bin/python3 -u $code/studio.py $data $control"
  else
    command='/usr/bin/sleep infinity'
  fi
  cat > "/run/systemd/system/$unit" <<EOF
[Unit]
ConditionPathExists=!$marker
[Service]
User=ai-studio
Group=ai-studio
ExecStart=$command
Restart=on-failure
RestartSec=1
KillMode=control-group
EOF
  chmod 0644 "/run/systemd/system/$unit"
done
restorecon -RF "$records" "$data" "$control" "$code"
restorecon -F "/run/systemd/system/$studio" "/run/systemd/system/$gate"
systemctl daemon-reload
systemctl start "$studio" "$gate"
ready=no
for _ in {1..90}; do
  if [[ -f $control/studio-ready ]]; then ready=yes; break; fi
  systemctl is-active --quiet "$studio" || { echo '시험 Studio 서비스가 종료됐습니다.' >&2; false; }
  sleep .5
done
[[ $ready == yes ]] || { echo '시험 Studio 준비 시간 초과' >&2; false; }
systemd-run --quiet --unit="$other" --property=Type=exec --property=User=ai-studio \
  --property=Group=ai-studio --property=KillMode=control-group \
  /usr/bin/python3 -u "$code/outsider.py" "$data" "$control"
ready=no
for _ in {1..90}; do
  if [[ -f $control/outside-ready ]]; then ready=yes; break; fi
  systemctl is-active --quiet "$other" || { echo '서비스 밖 시험 프로세스가 종료됐습니다.' >&2; false; }
  sleep .5
done
[[ $ready == yes ]] || { echo '서비스 밖 시험 프로세스 준비 시간 초과' >&2; false; }
python3 - "$source_dir/deploy/model-control" "$records" "$data" "$control" "$studio" "$gate" "$other" "$mode" <<'PY'
import importlib.util
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

source, records, data, control = map(Path, sys.argv[1:5])
studio, gate, other = sys.argv[5:8]
mode = sys.argv[8]
sys.dont_write_bytecode = True
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
sequence = load('fixture_service_fence', source / 'service-stop-fence-sequence.py')
journal_module = load('fixture_journal', source / 'migration-journal.py')
watch_module = load('fixture_watch', source / 'old-studio-process-watch.py')
backup_module = load('fixture_backup', source / 'legacy-backup-adapter.py')
backup_sequence = load('fixture_backup_sequence', source / 'legacy-backup-sequence.py')
db_module = load('fixture_db', source / 'inspect-stopped-studio-db.py')
references = load('fixture_references', source / 'observe-db-process-references.py')
units = (studio, gate)
marker = records / 'blocked'
database = data / 'database/studio.sqlite3'
backup_module.STUDIO_DATABASE = database
def show(unit, field):
    return subprocess.check_output(['/usr/bin/systemctl', 'show', unit, '-p', field, '--value'], text=True).strip()
pids = {unit: int(show(unit, 'MainPID')) for unit in units}
outside_pid = int(show(other, 'MainPID'))
assert outside_pid > 1 and outside_pid not in pids.values()
watches = {unit: watch_module.OldStudioProcessWatch(pid, watch_module.process_starttime(pid))
           for unit, pid in pids.items()}
def generation():
    return all(not watches[unit].exited() and show(unit, 'MainPID') == str(pids[unit]) for unit in units)
def disable_restart():
    for unit in units:
        directory = Path('/run/systemd/system') / (unit + '.d')
        directory.mkdir(mode=0o755)
        (directory / '90-bc250-test.conf').write_text('[Service]\nRestart=no\n')
        (directory / '90-bc250-test.conf').chmod(0o644)
        subprocess.run(['/usr/sbin/restorecon', '-RF', str(directory)], check=True)
    subprocess.run(['/usr/bin/systemctl', 'daemon-reload'], check=True)
    return all(show(unit, 'Restart') == 'no' for unit in units)
def install_block():
    marker.touch(exist_ok=False)
    subprocess.run(['/usr/sbin/restorecon', '-F', str(marker)], check=True)
    return True
def policy():
    return marker.is_file() and all(show(unit, 'Restart') == 'no' for unit in units)
def stop():
    subprocess.run(['/usr/bin/systemctl', 'stop', *units], check=True, timeout=120)
    return True
def stopped():
    subprocess.run(['/usr/bin/bash', '-c', 'source "$1"; shift; bc250_require_stopped "$@"',
                    'fixture', str(source / 'backup-archive.sh'), *units], check=True, timeout=60)
    return True
journal_dir = records / 'sequence'
journal_dir.mkdir(mode=0o700)
journal = journal_module.MigrationJournal(journal_dir)
runner = sequence.ServiceStopFence(record=journal, generation_current=generation,
    disable_restart=disable_restart, install_start_block=install_block,
    check_policy=policy, stop_services=stop, check_stopped=stopped)
try:
    assert runner.prepare() is True and runner.check() is True
    subprocess.run(['/usr/bin/systemctl', 'start', studio], check=False, timeout=60)
    assert runner.check() is True
    print('시험 두 서비스 세대 확인·정지와 명시적 재시작 차단 확인', flush=True)
    adapter = backup_module.LegacyBackupAdapter.__new__(backup_module.LegacyBackupAdapter)
    adapter.check_local_idle = lambda: True
    adapter.llama_connections = SimpleNamespace(check_host_llama=lambda: True)
    def require_stopped():
        if runner.check() is not True:
            raise RuntimeError('시험 서비스 차단 상실')
    adapter.require_stopped = require_stopped
    adapter.check_database_fence = lambda: runner.check() is True and not any(
        references.observe_known_processes([outside_pid], data, database).values())
    inspections = []
    def inspect(path, *, check_stopped):
        inspections.append('started')
        return db_module.inspect(path, check_stopped=check_stopped)
    adapter.studio_db = SimpleNamespace(inspect=inspect)
    try:
        adapter.require_stopped_with_clear_database()
    except RuntimeError as error:
        if 'DB 검사 전' not in str(error): raise
    else:
        raise RuntimeError('서비스 밖 시험 DB 참조가 허용됐습니다.')
    assert not inspections and runner.check() is True
    print('서비스 밖 시험 프로세스의 DB 참조가 있으면 DB 검사 전 중단 확인', flush=True)
    (control / 'close').touch()
    for _ in range(120):
        if (control / 'closed').exists(): break
        time.sleep(.5)
    else:
        raise RuntimeError('시험 외부 FD 해제 시간 초과')
    adapter.require_stopped_with_clear_database()
    assert inspections == ['started'] and runner.check() is True
    print('지정 시험 프로세스의 참조 해제 후 실제 시험 DB 검사 확인', flush=True)
    if mode == 'race':
        def inspect_with_reopen(path, *, check_stopped):
            if check_stopped() is not True:
                raise RuntimeError('시험 차단 상태 확인 실패')
            (control / 'reopen').touch()
            for _ in range(120):
                if (control / 'reopened').exists(): break
                time.sleep(.5)
            else:
                raise RuntimeError('시험 DB 참조 재오픈 시간 초과')
            inspections.append('race-started')
            return db_module.inspect(path, check_stopped=check_stopped)
        adapter.studio_db = SimpleNamespace(inspect=inspect_with_reopen)
        original_tempdir = db_module.tempfile.TemporaryDirectory
        def unexpected_copy(*_args, **_kwargs):
            raise AssertionError('차단 재확인 전에 DB 복사 디렉터리가 생성됐습니다.')
        db_module.tempfile.TemporaryDirectory = unexpected_copy
        try:
            try:
                adapter.require_stopped_with_clear_database()
            except RuntimeError as error:
                if 'DB 검사 중 지속 쓰기 차단' not in str(error): raise
            else:
                raise RuntimeError('DB 검사 시작 직후 재오픈된 시험 참조가 허용됐습니다.')
        finally:
            db_module.tempfile.TemporaryDirectory = original_tempdir
        assert inspections == ['started', 'race-started'] and runner.check() is True
        print('DB 복사 전 시험 외부 참조 재오픈 시 검사 중단 확인', flush=True)
        (control / 'close-again').touch()
        for _ in range(120):
            if (control / 'closed-again').exists(): break
            time.sleep(.5)
        else:
            raise RuntimeError('시험 DB 참조 재해제 시간 초과')
    if mode == 'post-inspect':
        def inspect_then_reopen(path, *, check_stopped):
            result = db_module.inspect(path, check_stopped=check_stopped)
            inspections.append('post-inspect')
            (control / 'reopen').touch()
            for _ in range(120):
                if (control / 'reopened').exists(): break
                time.sleep(.5)
            else:
                raise RuntimeError('시험 DB 참조 재오픈 시간 초과')
            return result
        adapter.studio_db = SimpleNamespace(inspect=inspect_then_reopen)
        backup_calls = []
        def unexpected_backup():
            backup_calls.append('created')
            raise AssertionError('시험 차단 상실 후 백업을 생성했습니다.')
        drained = {'paused': True, 'active_requests': 0, 'waiting_requests': 0}
        try:
            backup_sequence.backup_legacy(
                check_maintenance=lambda: True, capture_pause=lambda: drained,
                gate_status=lambda: drained, stop_services=lambda: None,
                require_stopped=adapter.require_stopped_with_clear_database,
                create_backup=unexpected_backup, verify_backup=lambda _: None)
        except backup_sequence.SequenceError as error:
            if not isinstance(error.__cause__, RuntimeError) or 'DB 검사 중 지속 쓰기 차단' not in str(error.__cause__):
                raise
        else:
            raise RuntimeError('시험 DB 검사 후 새 외부 참조가 허용됐습니다.')
        assert inspections == ['started', 'post-inspect'] and not backup_calls and runner.check() is True
        print('시험 DB 검사 후 외부 참조 재오픈 시 백업 생성 전 중단 확인', flush=True)
        (control / 'close-again').touch()
        for _ in range(120):
            if (control / 'closed-again').exists(): break
            time.sleep(.5)
        else:
            raise RuntimeError('시험 DB 참조 재해제 시간 초과')
    if mode in ('during-backup', 'during-verify'):
        root = records / 'backup-fixture'
        root.mkdir(mode=0o700)
        for relative in ('opt/bc250-ai-studio', 'opt/ai-studio-data', 'opt/ai/config',
                         'etc/systemd/system', 'var/lib/bc250-model-control'):
            (root / relative).mkdir(parents=True, exist_ok=True)
        for name in ('bc250-ai-studio', 'bc250-llm-gate', 'bc250-llm-client'):
            (root / 'etc' / (name + '.env')).write_text('fixture\n')
            (root / 'etc/systemd/system' / (name + '.service')).write_text('fixture\n')
        (root / 'opt/ai/config/active-model.conf').write_text('fixture\n')
        (root / 'var/lib/bc250-model-control/legacy-pause.json').write_text('{}\n')
        caddy = records / 'Caddyfile.original'
        caddy.write_text('fixture\n')
        caddy.chmod(0o600)
        adapter.source, adapter.snapshot = source, records
        backup_paths, verification_calls = [], []
        original_run = subprocess.run
        bind = root / 'opt/ai-studio-data'
        original_run(['/usr/bin/mount', '--bind', str(data), str(bind)], check=True)
        def reopen_outside():
            (control / 'reopen').touch()
            for _ in range(120):
                if (control / 'reopened').exists(): return
                time.sleep(.5)
            raise RuntimeError('시험 백업 중 외부 참조 생성 시간 초과')
        def simulate_backup_process(command, *args, **kwargs):
            if (mode == 'during-verify' and len(command) >= 2
                    and command[0] == '/usr/bin/python3' and command[1] == str(source / 'verify-backup.py')):
                reopen_outside()
                return original_run(command, *args, **kwargs)
            if (len(command) < 2 or command[0] != '/usr/bin/bash'
                    or command[1] != str(source / 'backup-stopped.sh')):
                return original_run(command, *args, **kwargs)
            if mode == 'during-backup':
                reopen_outside()
            created = original_run(['/usr/bin/mktemp', '-d', '/var/backups/bc250-model-migration.XXXXXXXX'],
                                   check=True, capture_output=True, text=True)
            backup = Path(created.stdout.strip())
            backup_paths.append(backup)
            original_run(['/usr/bin/bash', '-c', 'source "$1"; bc250_backup_archive "$2" "$3" "$4"',
                          'fixture', str(source / 'backup-archive.sh'), str(root), str(backup), str(caddy)],
                         check=True, capture_output=True, text=True, timeout=120)
            return subprocess.CompletedProcess(command, 0, stdout='백업 경로: ' + str(backup) + '\n', stderr='')
        adapter.studio_db = SimpleNamespace(inspect=inspect)
        drained = {'paused': True, 'active_requests': 0, 'waiting_requests': 0}
        def verify_backup(value):
            verification_calls.append('entered')
            adapter.verify_backup(value)
        subprocess.run = simulate_backup_process
        try:
            try:
                backup_sequence.backup_legacy(
                    check_maintenance=lambda: True, capture_pause=lambda: drained,
                    gate_status=lambda: drained, stop_services=lambda: None,
                    require_stopped=adapter.require_stopped_with_clear_database,
                    create_backup=adapter.create_backup,
                    verify_backup=verify_backup)
            except backup_sequence.SequenceError as error:
                expected_error = ('백업 생성 중 DB 쓰기 차단' if mode == 'during-backup'
                                  else '백업 검증 중 DB 쓰기 차단')
                if not isinstance(error.__cause__, RuntimeError) or expected_error not in str(error.__cause__):
                    raise
            else:
                raise RuntimeError('시험 백업 중 새 외부 참조가 허용됐습니다.')
        finally:
            subprocess.run = original_run
            original_run(['/usr/bin/umount', str(bind)], check=True)
        expected_verification = [] if mode == 'during-backup' else ['entered']
        assert len(backup_paths) == 1 and verification_calls == expected_verification and inspections == ['started', 'started']
        backup = backup_paths[0]
        assert (backup / 'legacy.tar').is_file() and (backup / 'SHA256SUMS').is_file()
        original_run(['/usr/bin/sha256sum', '-c', 'SHA256SUMS'], cwd=backup,
                     check=True, stdout=subprocess.DEVNULL)
        phase = '생성' if mode == 'during-backup' else '검증'
        print(f'실제 시험 아카이브 {phase} 중 외부 참조 재오픈 시 완료 거절과 아카이브 보존 확인:', backup, flush=True)
        (control / 'close-again').touch()
        for _ in range(120):
            if (control / 'closed-again').exists(): break
            time.sleep(.5)
        else:
            raise RuntimeError('시험 DB 참조 재해제 시간 초과')
    marker.unlink()
    assert runner.check() is False
    marker.touch()
    assert runner.check() is False
    try:
        adapter.require_stopped_with_clear_database()
    except RuntimeError:
        pass
    else:
        raise RuntimeError('복원된 시험 차단을 자동 재승인했습니다.')
    expected_inspections = {'ordinary': ['started'], 'race': ['started', 'race-started'],
                            'post-inspect': ['started', 'post-inspect'],
                            'during-backup': ['started', 'started'], 'during-verify': ['started', 'started']}
    assert inspections == expected_inspections[mode]
    print('시험 차단 상실 후 표시 복원만으로 DB 검사 재승인 거절 확인', flush=True)
finally:
    journal.close()
    for watch in watches.values(): watch.close()
(control / 'stop').touch()
PY
if ! systemctl stop "$other" 2>"$records/outside-stop.err"; then
  if [[ $(systemctl show "$other" -p LoadState --value) != not-found ]]; then
    cat "$records/outside-stop.err" >&2
    false
  fi
  echo '시험 외부 프로세스가 이미 종료된 상태 확인'
fi
rm -- "$marker"
for unit in "$studio" "$gate"; do
  rm -- "/run/systemd/system/$unit.d/90-bc250-test.conf"
  rmdir -- "/run/systemd/system/$unit.d"
done
systemctl daemon-reload
systemctl start "$studio" "$gate"
for unit in "$studio" "$gate"; do
  [[ $(systemctl show "$unit" -p ActiveState --value) == active \
    && $(systemctl show "$unit" -p Restart --value) == on-failure ]] || exit 1
done
systemctl stop "$studio" "$gate"
rm -- "/run/systemd/system/$studio" "/run/systemd/system/$gate"
systemctl daemon-reload
trap - ERR
echo "시험 서비스 정리 완료; 시험 DB·기록 보관: $records $data $control $code"
echo '지정된 한 시험 PID만 관찰했으며 gate drain·직접 호출 차단·GPU·실제 백업은 모의입니다. 운영 서비스는 변경하지 않았습니다.'
