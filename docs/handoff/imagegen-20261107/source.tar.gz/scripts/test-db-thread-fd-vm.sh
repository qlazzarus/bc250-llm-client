#!/usr/bin/env bash
# Disposable VM: demonstrate a private thread FD table and leader-only observation.
set -Eeuo pipefail
umask 077
[[ $(id -u) == 0 && $(hostname) == bc250-fedora43-test && $(systemd-detect-virt) == qemu && $(getenforce) == Enforcing && ( $# == 1 || ( $# == 2 && ( $2 == observe || $2 == enumerate || $2 == uid ) ) ) ]] || exit 1
mode=${2:-ordinary}
module=$1/deploy/model-control/observe-db-process-references.py
[[ -f $module ]] || exit 1
uid=61037
gid=61037
! getent passwd "$uid" >/dev/null
! getent group "$gid" >/dev/null
if [[ $mode == uid ]]; then
  python3 - "$module" "$uid" <<'PYUID'
import importlib.util
import sys
spec = importlib.util.spec_from_file_location('references', sys.argv[1])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
if module.selected_uid_pids(int(sys.argv[2])):
    raise SystemExit('시험 UID를 사용하는 프로세스가 이미 있습니다.')
PYUID
fi
records=$(mktemp -d /var/backups/bc250-db-thread.XXXXXXXX)
data=$(mktemp -d /var/lib/bc250-db-thread.XXXXXXXX)
control=$(mktemp -d /var/lib/bc250-db-thread-control.XXXXXXXX)
code=$(mktemp -d /opt/bc250-db-thread.XXXXXXXX)
suffix=${records##*.}
[[ $suffix =~ ^[A-Za-z0-9]{8}$ ]] || exit 1
unit=bc250-db-thread-$suffix.service
[[ $(systemctl show "$unit" -p LoadState --value) == not-found ]] || exit 1
failure() {
  systemctl stop "$unit" >/dev/null 2>&1 || true
  echo "시험 중단. 시험 자료 보관: $records $data $control $code" >&2
}
trap failure ERR
chmod 0755 "$code"
chown "$uid:$gid" "$data" "$control"
chmod 0700 "$data" "$control"
python3 - "$data/fixture.sqlite3" <<'PY'
import sqlite3
import sys
with sqlite3.connect(sys.argv[1]) as connection:
    connection.execute('CREATE TABLE fixture (value TEXT)')
PY
chown "$uid:$gid" "$data/fixture.sqlite3"
chmod 0600 "$data/fixture.sqlite3"
cat > "$code/worker.py" <<'PY'
import ctypes
import json
import os
import sys
import threading
import time
from pathlib import Path

data, control, uid, gid = Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
os.setgroups([])
os.setgid(gid)
os.setuid(uid)
def worker():
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.unshare(0x400) != 0:  # CLONE_FILES
        (control / 'error').write_text(str(ctypes.get_errno()))
        return
    fd = os.open(data, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    (control / 'ready').write_text(json.dumps({'tid': threading.get_native_id(), 'fd': fd}))
    deadline = time.monotonic() + 240
    while not (control / 'close').exists() and time.monotonic() < deadline:
        time.sleep(.1)
    os.close(fd)
    (control / 'closed').write_text('closed')
    while not (control / 'stop').exists() and time.monotonic() < deadline:
        time.sleep(.1)
thread = threading.Thread(target=worker)
thread.start()
thread.join()
PY
chmod 0644 "$code/worker.py"
restorecon -RF "$data" "$control" "$code" "$records"
systemd-run --quiet --unit="$unit" --property=Type=exec --property=KillMode=control-group \
  /usr/bin/python3 -u "$code/worker.py" "$data" "$control" "$uid" "$gid"
python3 - "$module" "$data" "$control" "$unit" "$mode" <<'PY'
import importlib.util
import json
import subprocess
import sys
import time
from pathlib import Path

module_path, data, control = map(Path, sys.argv[1:4])
unit, mode = sys.argv[4:6]
def wait(name):
    for _ in range(120):
        if (control / 'error').exists():
            raise SystemExit('시험 스레드의 FD 테이블 분리 실패: errno=' + (control / 'error').read_text())
        if (control / name).exists(): return
        time.sleep(.5)
    raise SystemExit('시험 신호 대기 시간 초과: ' + name)
wait('ready')
pid = int(subprocess.check_output(['systemctl', 'show', unit, '-p', 'MainPID', '--value'], text=True).strip())
info = json.loads((control / 'ready').read_text())
tid, fd = info['tid'], info['fd']
if pid <= 1 or tid == pid: raise SystemExit('시험 스레드 식별 실패')
thread_fd = Path(f'/proc/{pid}/task/{tid}/fd/{fd}')
a, b = thread_fd.stat(), data.stat()
if (a.st_dev, a.st_ino) != (b.st_dev, b.st_ino): raise SystemExit('스레드 FD 대상 불일치')
spec = importlib.util.spec_from_file_location('references', module_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
observed = module.observe_process(pid, data, data / 'fixture.sqlite3')
if observed: raise SystemExit('대표 프로세스에서 예상하지 못한 참조 관찰: ' + repr(observed))
print('대표 프로세스 검사에서 발견하지 못한 별도 스레드 FD 확인', flush=True)
if mode == 'observe':
    thread_result = module.observe_known_thread(pid, tid, data, data / 'fixture.sqlite3')
    if 'fd' not in thread_result:
        raise SystemExit('지정된 시험 스레드 FD 감지 실패: ' + repr(thread_result))
    print('지정된 시험 스레드의 별도 FD 감지 확인', flush=True)
if mode == 'enumerate':
    snapshot = module.observe_process_threads(pid, data, data / 'fixture.sqlite3')
    if set(snapshot) != {pid, tid} or 'fd' not in snapshot[tid] or snapshot[pid]:
        raise SystemExit('시험 스레드 열거 또는 FD 관찰 실패: ' + repr(snapshot))
    print('시험 프로세스의 스레드 열거와 별도 FD 감지 확인', flush=True)
if mode == 'uid':
    snapshot = module.observe_uid_process_threads(61037, data, data / 'fixture.sqlite3')
    if set(snapshot) != {pid} or set(snapshot[pid]) != {pid, tid} or 'fd' not in snapshot[pid][tid] or snapshot[pid][pid]:
        raise SystemExit('시험 UID 프로세스·스레드 열거 또는 FD 관찰 실패: ' + repr(snapshot))
    print('시험 UID 프로세스와 스레드 열거 및 별도 FD 감지 확인', flush=True)
(control / 'close').touch()
wait('closed')
if thread_fd.exists(): raise SystemExit('스레드 FD가 닫히지 않았습니다.')
print('시험 스레드의 DB 디렉터리 FD 종료 확인', flush=True)
if mode == 'observe':
    thread_result = module.observe_known_thread(pid, tid, data, data / 'fixture.sqlite3')
    if thread_result:
        raise SystemExit('시험 스레드 FD 종료 후 참조가 남았습니다: ' + repr(thread_result))
    print('지정된 시험 스레드의 FD 종료 후 참조 없음 확인', flush=True)
if mode == 'enumerate':
    snapshot = module.observe_process_threads(pid, data, data / 'fixture.sqlite3')
    if set(snapshot) != {pid, tid} or any(snapshot.values()):
        raise SystemExit('시험 스레드 FD 종료 후 참조 확인 실패: ' + repr(snapshot))
    print('시험 스레드들의 FD 종료 후 참조 없음 확인', flush=True)
if mode == 'uid':
    snapshot = module.observe_uid_process_threads(61037, data, data / 'fixture.sqlite3')
    if set(snapshot) != {pid} or set(snapshot[pid]) != {pid, tid} or any(snapshot[pid].values()):
        raise SystemExit('시험 UID 스레드의 FD 종료 후 참조 확인 실패: ' + repr(snapshot))
    print('시험 UID 스레드의 FD 종료 후 참조 없음 확인', flush=True)
(control / 'stop').touch()
PY
if ! systemctl stop "$unit" 2>/dev/null; then
  [[ $(systemctl show "$unit" -p LoadState --value) == not-found ]] || exit 1
fi
trap - ERR
echo "시험 서비스 정리 완료; 시험 자료 보관: $records $data $control $code"
echo '운영 DB·서비스는 변경하지 않았습니다. 지정된 시험 구성의 순간 관찰이며 다른 UID·새 참조 생성·지속 차단은 확인하지 않습니다.'
