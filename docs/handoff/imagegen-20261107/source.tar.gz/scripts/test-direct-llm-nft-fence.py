#!/usr/bin/env python3
"""Tests lifecycle and failure latching; they do not prove network exclusion."""
import importlib.util
import json
from pathlib import Path

import pytest

path = Path(__file__).resolve().parents[1] / 'deploy/model-control/direct-llm-nft-fence.py'
spec = importlib.util.spec_from_file_location('direct_llm_nft_fence', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def fixture(monkeypatch):
    monkeypatch.setattr(module.os, 'geteuid', lambda: 0)
    gate = (123, '42', '/system.slice/fixture.service', 1, 2)
    monkeypatch.setattr(module, 'unit_snapshot', lambda _: gate)
    state = {'table': None, 'scope': True, 'barrier': True}
    document = {'nftables': [{'metainfo': {'version': 'fixture'}},
                            {'table': {'family': 'inet', 'name': 'fixture', 'handle': 4}},
                            {'chain': {'family': 'inet', 'name': 'output', 'handle': 5}},
                            {'rule': {'expr': [{'accept': None}], 'handle': 6}}]}
    runner = module.DirectLLMNftFence('fixture.service', port=8080, verify_gate=lambda _: True,
        check_scope=lambda: state['scope'], check_barriers=lambda: state['barrier'])
    monkeypatch.setattr(runner, '_namespace', lambda: (1, 7))

    def nft(args, *, data=None):
        if args == ['-j', 'list', 'tables']:
            return json.dumps({'nftables': []})
        if args == ['--check', '--file', '-']:
            assert '127.0.0.1' in data
            state['rules'] = data
            return ''
        if args == ['--file', '-']:
            state['table'] = document
            return ''
        if args[:4] == ['-j', 'list', 'table', 'inet']:
            return json.dumps(state['table'])
        if args[:3] == ['delete', 'table', 'inet']:
            state['table'] = None
            return ''
        raise AssertionError(args)

    monkeypatch.setattr(runner, '_nft', nft)
    return runner, state


def test_rule_change_is_latched_and_not_removed(monkeypatch):
    runner, state = fixture(monkeypatch)
    assert runner.acquire() and runner.check()
    state['table']['nftables'][-1]['rule']['expr'] = [{'drop': None}]
    assert not runner.check()
    state['table']['nftables'][-1]['rule']['expr'] = [{'accept': None}]
    assert not runner.check()
    with pytest.raises(ValueError):
        runner.release(can_release=lambda: True)
    assert state['table'] is not None


def test_release_requires_barriers_and_preserves_table_on_failure(monkeypatch):
    runner, state = fixture(monkeypatch)
    assert runner.acquire()
    state['barrier'] = False
    with pytest.raises(ValueError):
        runner.release(can_release=lambda: True)
    assert runner.phase == 'lost' and state['table'] is not None


def test_release_removes_only_owned_table(monkeypatch):
    runner, state = fixture(monkeypatch)
    assert runner.acquire()
    assert runner.release(can_release=lambda: True)
    assert runner.phase == 'released' and state['table'] is None


def test_callback_exception_latches_loss(monkeypatch):
    runner, state = fixture(monkeypatch)
    assert runner.acquire()
    def failed():
        raise RuntimeError('fixture')
    runner.check_scope = failed
    assert not runner.check() and runner.phase == 'lost'
    assert state['table'] is not None


def test_coordinator_is_explicit_and_generation_change_latches_loss(monkeypatch):
    runner, state = fixture(monkeypatch)
    gate = (123, '42', '/system.slice/fixture.service', 1, 2)
    coordinator = [124, '43', '/system.slice/coordinator.service', 1, 3]
    monkeypatch.setattr(module, 'unit_snapshot',
                        lambda unit: gate if unit == 'fixture.service' else tuple(coordinator))
    runner.coordinator_unit = 'coordinator.service'
    runner.verify_coordinator = lambda _: True
    assert runner.acquire()
    assert 'system.slice/coordinator.service' in state['rules']
    coordinator[1] = '44'
    assert not runner.check() and runner.phase == 'lost'
    assert state['table'] is not None


def test_coordinator_requires_separate_verifier(monkeypatch):
    monkeypatch.setattr(module.os, 'geteuid', lambda: 0)
    with pytest.raises(ValueError):
        module.DirectLLMNftFence('fixture.service', port=8080, verify_gate=lambda _: True,
            check_scope=lambda: True, check_barriers=lambda: True, coordinator_unit='coordinator.service')


def test_gate_retirement_blocks_gate_then_stops_and_preserves_coordinator(monkeypatch):
    runner, state = fixture(monkeypatch)
    gate = (123, '42', '/system.slice/fixture.service', 1, 2)
    coordinator = (124, '43', '/system.slice/coordinator.service', 1, 3)
    running = {'gate': True}

    def snapshot(unit):
        if unit == 'coordinator.service':
            return coordinator
        if not running['gate']:
            raise ValueError('gate is stopped')
        return gate

    monkeypatch.setattr(module, 'unit_snapshot', snapshot)
    runner.coordinator_unit = 'coordinator.service'
    runner.verify_coordinator = lambda _: True
    assert runner.acquire()

    def stop():
        assert 'system.slice/fixture.service' not in state['rules']
        assert 'system.slice/coordinator.service' in state['rules']
        running['gate'] = False
        return True

    assert runner.retire_gate(check_drained=lambda: True, stop_gate=stop,
                              check_stopped=lambda: not running['gate'])
    assert runner.phase == 'retired' and runner.check()
    running['gate'] = True
    assert not runner.check() and runner.phase == 'lost'
    assert state['table'] is not None


def test_gate_retirement_rejects_undrained_without_stopping(monkeypatch):
    runner, state = fixture(monkeypatch)
    gate = (123, '42', '/system.slice/fixture.service', 1, 2)
    coordinator = (124, '43', '/system.slice/coordinator.service', 1, 3)
    monkeypatch.setattr(module, 'unit_snapshot',
                        lambda unit: gate if unit == 'fixture.service' else coordinator)
    runner.coordinator_unit = 'coordinator.service'
    runner.verify_coordinator = lambda _: True
    assert runner.acquire()
    called = []
    with pytest.raises(ValueError):
        runner.retire_gate(check_drained=lambda: False, stop_gate=lambda: called.append('stop'),
                           check_stopped=lambda: True)
    assert not called and runner.phase == 'failed' and state['table'] is not None


@pytest.mark.parametrize('held', [True, False])
def test_gate_restore_requires_verified_hold_before_allowing_new_generation(monkeypatch, held):
    runner, state = fixture(monkeypatch)
    old_gate = (123, '42', '/system.slice/fixture.service', 1, 2)
    new_gate = (125, '44', '/system.slice/fixture.service', 1, 4)
    coordinator = (124, '43', '/system.slice/coordinator.service', 1, 3)
    current = {'gate': old_gate}

    def snapshot(unit):
        if unit == 'coordinator.service':
            return coordinator
        if current['gate'] is None:
            raise ValueError('gate is stopped')
        return current['gate']

    monkeypatch.setattr(module, 'unit_snapshot', snapshot)
    runner.coordinator_unit = 'coordinator.service'
    runner.verify_coordinator = lambda _: True
    assert runner.acquire()

    def stop():
        current['gate'] = None
        return True

    assert runner.retire_gate(check_drained=lambda: True, stop_gate=stop,
                              check_stopped=lambda: current['gate'] is None)

    def start():
        current['gate'] = new_gate
        return True

    if held:
        assert runner.restore_gate(start_gate=start, check_held=lambda: True)
        assert runner.phase == 'active' and runner.gate == new_gate and runner.check()
        assert 'system.slice/fixture.service' in state['rules']
    else:
        with pytest.raises(ValueError):
            runner.restore_gate(start_gate=start, check_held=lambda: False)
        assert runner.phase == 'failed'
        assert 'system.slice/fixture.service' not in state['rules']
        assert state['table'] is not None
