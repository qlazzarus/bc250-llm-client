#!/usr/bin/env bash
# Start only a freshly prepared, separate test VM; do not trust SSH host keys.
set -Eeuo pipefail
umask 077
[[ $(id -u) != 0 && $# == 1 ]] || { echo '일반 사용자로 시험 디렉터리 하나를 전달하세요.' >&2; exit 1; }
test_dir=$(realpath -e -- "$1")
case "$test_dir" in "$HOME"/bc250-maintenance-vm.*) ;; *) echo '시험 디렉터리 경로가 올바르지 않습니다.' >&2; exit 1 ;; esac
[[ -d "$test_dir" && -O "$test_dir" && ! -L "$1" ]] || { echo '시험 디렉터리 소유권 또는 형식 오류' >&2; exit 1; }
old_dir="$HOME/bc250-fedora43-test-vm"
base="$old_dir/Fedora-Cloud-Base-Generic-43-1.6.x86_64.qcow2"
expected=846574c8a97cd2d8dc1f231062d73107cc85cbbbda56335e264a46e3a6c8ab2f
for name in test-disk.qcow2 seed.iso vm-key vm-key.pub; do
  [[ -f "$test_dir/$name" && ! -L "$test_dir/$name" && -O "$test_dir/$name" ]] || { echo "시험 파일 오류: $name" >&2; exit 1; }
done
[[ ! -e "$test_dir/vm.pid" && ! -e "$test_dir/serial.log" ]] || { echo '기존 시험 실행 기록이 있습니다. 보존하고 중단합니다.' >&2; exit 1; }
if [[ -f "$old_dir/vm.pid" ]]; then
  old_pid=$(cat "$old_dir/vm.pid")
  [[ $old_pid =~ ^[0-9]+$ ]] || { echo '기존 VM PID 오류' >&2; exit 1; }
  if kill -0 "$old_pid" 2>/dev/null; then echo '기존 PID가 실행 중입니다. 확인 후 진행하세요.' >&2; exit 1; fi
fi
[[ -z $(ss -H -ltn 'sport = :22224') ]] || { echo '시험 포트 22224가 사용 중입니다.' >&2; exit 1; }
available=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)
[[ $available =~ ^[0-9]+$ && $available -ge 3000000 ]] || { echo '사용 가능한 메모리가 부족합니다.' >&2; exit 1; }
printf '%s  %s\n' "$expected" "$base" | sha256sum -c -
qemu-img info --output=json "$test_dir/test-disk.qcow2" | python3 -c 'import json,os,sys; d=json.load(sys.stdin); assert d.get("format")=="qcow2" and d.get("backing-filename-format")=="qcow2" and os.path.realpath(d.get("full-backing-filename", ""))==os.path.realpath(sys.argv[1]) and d.get("virtual-size")==12884901888, "시험 디스크 형식 오류"' "$base"
trap 'echo "시험 시작 중단. 시험 자료와 상태 보존: $test_dir" >&2' ERR
cd "$test_dir"
nice -n 15 qemu-system-x86_64 \
  -accel tcg,thread=multi -m 1536 -smp 2 \
  -drive file=test-disk.qcow2,if=virtio,format=qcow2 \
  -drive file=seed.iso,media=cdrom,readonly=on \
  -netdev user,id=net0,restrict=on,hostfwd=tcp:127.0.0.1:22224-:22 \
  -device virtio-net-pci,netdev=net0 -display none -monitor none \
  -serial file:serial.log -pidfile vm.pid -daemonize
pid=$(cat vm.pid)
[[ $pid =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null || { echo '시험 VM 시작 여부 미확인' >&2; exit 1; }
echo "별도 시험 VM 시작 요청 완료. PID: $pid"
echo "시험 자료: $test_dir"
echo 'SSH 호스트 키는 아직 확인하지 않았습니다. serial 로그 확인 후 접속합니다.'
