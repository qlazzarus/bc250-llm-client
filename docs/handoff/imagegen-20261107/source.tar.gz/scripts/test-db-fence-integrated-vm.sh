#!/usr/bin/env bash
# Disposable VM only. This is a single-file proof of concept, not a DB fence.
set -Eeuo pipefail
umask 077
[[ $(id -u) == 0 && $(hostname) == bc250-fedora43-test && $(systemd-detect-virt) == qemu && $(getenforce) == Enforcing && ( $# == 1 || ( $# == 2 && ( $2 == wal || $2 == wal-mapping || $2 == real-archive || $2 == staged-archive || $2 == metadata-archive || $2 == tree-archive ) ) ) ]] || exit 1
mode=${2:-ordinary}
! getent passwd 61038 >/dev/null
! getent group 61038 >/dev/null
for tool in systemctl python3 restorecon; do command -v "$tool" >/dev/null || exit 1; done
records=$(mktemp -d /var/backups/bc250-db-integrated.XXXXXXXX)
data=$(mktemp -d /var/lib/bc250-db-integrated.XXXXXXXX)
suffix=${records##*.}
[[ $suffix =~ ^[A-Za-z0-9]{8}$ ]] || exit 1
unit=bc250-db-integrated-$suffix.service
unit_file=/run/systemd/system/$unit
marker=$records/blocked
[[ ! -e $unit_file && ! -L $unit_file && ! -e /etc/systemd/system/$unit && $(systemctl show "$unit" -p LoadState --value) == not-found ]] || exit 1
failure() {
  echo "시험 중단. 시험 unit과 자료를 보존합니다: $unit $records $data" >&2
}
trap failure ERR
cat > "$unit_file" <<UNIT
[Unit]
ConditionPathExists=!$marker
[Service]
ExecStart=/usr/bin/sleep infinity
Restart=no
KillMode=control-group
UNIT
chmod 0644 "$unit_file"
chmod 0755 "$records" "$data"
restorecon -RF "$unit_file" "$records" "$data"
systemctl daemon-reload
systemctl start "$unit"
python3 - "$1/deploy/model-control/service-stop-fence-sequence.py" "$unit" "$marker" "$records" "$data" "$mode" <<'PY'
import errno
import fcntl
import hashlib
import importlib.util
import json
import os
import signal
import sqlite3
import stat
import subprocess
import sys
import tarfile
from pathlib import Path

source, unit, marker, records, data = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]), Path(sys.argv[4]), Path(sys.argv[5])
mode = sys.argv[6]
if mode == 'tree-archive':
    for relative in ('opt/bc250-ai-studio', 'opt/ai-studio-data/database', 'opt/ai/config',
                     'etc/systemd/system', 'var/lib/bc250-model-control'):
        (data / relative).mkdir(parents=True, exist_ok=True)
    for path in (data / 'opt', data / 'opt/ai-studio-data', data / 'opt/ai-studio-data/database'):
        path.chmod(0o755)
    (data / 'opt/bc250-ai-studio/fixture.txt').write_text('studio-code-fixture\n')
    (data / 'opt/ai-studio-data/other.txt').write_text('other-data-fixture\n')
    for name in ('bc250-ai-studio', 'bc250-llm-gate', 'bc250-llm-client'):
        (data / 'etc' / (name + '.env')).write_text('fixture\n')
        (data / 'etc/systemd/system' / (name + '.service')).write_text('fixture\n')
    (data / 'opt/ai/config/active-model.conf').write_text('fixture\n')
    (data / 'var/lib/bc250-model-control/legacy-pause.json').write_text('{}\n')
db = data / ('opt/ai-studio-data/database/studio.sqlite3' if mode == 'tree-archive' else 'fixture.sqlite3')
connection = sqlite3.connect(db)
if mode in ('wal', 'wal-mapping', 'real-archive', 'staged-archive', 'metadata-archive', 'tree-archive') and connection.execute('PRAGMA journal_mode=WAL').fetchone() != ('wal',):
    raise RuntimeError('시험 WAL 모드 준비 실패')
connection.execute('CREATE TABLE fixture (value TEXT)')
connection.execute("INSERT INTO fixture VALUES ('verified')")
connection.commit()
connection.close()
db.chmod(0o666)
subprocess.run(['/usr/sbin/restorecon', '-F', str(db)], check=True)
if mode in ('metadata-archive', 'tree-archive'):
    import ctypes
    try:
        acl = ctypes.CDLL('libacl.so.1', use_errno=True)
    except OSError as error:
        raise RuntimeError('시험 VM의 libacl.so.1을 찾지 못했습니다.') from error
    acl.acl_from_text.argtypes = [ctypes.c_char_p]
    acl.acl_from_text.restype = ctypes.c_void_p
    acl.acl_set_file.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_void_p]
    acl.acl_set_file.restype = ctypes.c_int
    acl.acl_free.argtypes = [ctypes.c_void_p]
    acl.acl_free.restype = ctypes.c_int
    entries = acl.acl_from_text(b'user::rw-,user:61039:r--,group::rw-,mask::rw-,other::rw-')
    if not entries:
        raise OSError(ctypes.get_errno(), '시험 ACL 생성 실패')
    try:
        if acl.acl_set_file(os.fsencode(db), 0x8000, entries) != 0:
            raise OSError(ctypes.get_errno(), '시험 ACL 설정 실패')
    finally:
        acl.acl_free(entries)
    if 'system.posix_acl_access' not in os.listxattr(db) or 'security.selinux' not in os.listxattr(db):
        raise RuntimeError('시험 DB의 ACL 또는 SELinux 레이블 확인 실패')
    print('시험 DB에 추가 ACL과 SELinux 레이블 확인', flush=True)
original = (stat.S_IMODE(data.stat().st_mode), stat.S_IMODE(db.stat().st_mode))
if mode in ('wal', 'wal-mapping', 'real-archive', 'staged-archive', 'metadata-archive', 'tree-archive'):
    data.chmod(0o777)
    if mode == 'tree-archive': db.parent.chmod(0o777)
def show(field):
    return subprocess.check_output(['/usr/bin/systemctl', 'show', unit, '-p', field, '--value'], text=True).strip()
initial_pid = show('MainPID')
if not initial_pid.isdecimal() or int(initial_pid) <= 1: raise RuntimeError('시험 서비스 세대 확인 실패')
events = []
def generation(): return show('ActiveState') == 'active' and show('MainPID') == initial_pid
def disable_restart(): return show('Restart') == 'no'
def block(): marker.touch(exist_ok=False); return True
def policy(): return marker.is_file() and show('Restart') == 'no'
def stop(): subprocess.run(['/usr/bin/systemctl', 'stop', unit], check=True, timeout=60); return True
def stopped(): return show('ActiveState') == 'inactive' and show('MainPID') == '0' and show('Job') == ''
spec = importlib.util.spec_from_file_location('fixture_service_fence', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
fence = module.ServiceStopFence(record=events.append, generation_current=generation,
    disable_restart=disable_restart, install_start_block=block, check_policy=policy,
    stop_services=stop, check_stopped=stopped)
child_code = r'''
import mmap, os, sqlite3, sys
os.setgroups([])
os.setgid(61038)
os.setuid(61038)
fd = os.open(sys.argv[1], os.O_RDWR)
mapping = mmap.mmap(fd, 0, access=mmap.ACCESS_WRITE) if sys.argv[2] == 'wal-mapping' else None
connection = None
if sys.argv[2] in ('wal', 'wal-mapping', 'real-archive', 'staged-archive', 'metadata-archive', 'tree-archive'):
    connection = sqlite3.connect(sys.argv[1], timeout=2)
    connection.execute('PRAGMA wal_autocheckpoint=0')
    connection.execute("INSERT INTO fixture VALUES ('before-stop')")
    connection.commit()
print('ready', flush=True)
for line in sys.stdin:
    command = line.strip()
    if command == 'walwrite':
        if connection is None: raise SystemExit(2)
        connection.execute("INSERT INTO fixture VALUES ('after-stop')")
        connection.commit()
        print('committed', flush=True)
    elif command == 'close':
        if connection is not None:
            connection.close()
            connection = None
        os.close(fd)
        print('closed', flush=True)
    elif command == 'unmap':
        if mapping is None: raise SystemExit(2)
        mapping.close()
        mapping = None
        print('unmapped', flush=True)
    elif command == 'open':
        try:
            new = os.open(sys.argv[1], os.O_RDWR | os.O_NONBLOCK)
        except OSError as error:
            print('errno=' + str(error.errno), flush=True)
        else:
            os.close(new)
            print('opened', flush=True)
    elif command == 'stop': break
    else: raise SystemExit(2)
'''
child = subprocess.Popen(['/usr/bin/python3', '-u', '-c', child_code, str(db), mode],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
old_handler = signal.signal(signal.SIGIO, lambda *_: None)
fd = None
backup = records / 'fixture-backup.tar'
lost_backup = records / 'must-not-exist.tar'
def request(value):
    child.stdin.write(value + '\n')
    child.stdin.flush()
    return child.stdout.readline().strip()
def held():
    current = db.stat()
    opened = os.fstat(fd)
    return (fence.check() is True and fcntl.fcntl(fd, fcntl.F_GETLEASE) == fcntl.F_WRLCK
            and (current.st_dev, current.st_ino) == (opened.st_dev, opened.st_ino))
class FixtureGuard:
    def __init__(self):
        self.lost = False

    def require(self):
        if self.lost:
            raise RuntimeError('이미 상실된 시험 보호')
        try:
            protected = held()
        except Exception:
            self.lost = True
            raise
        if not protected:
            self.lost = True
            raise RuntimeError('시험 보호 상실')

    def begin_backup(self, path):
        self.require()
        return tarfile.open(path, 'x')

try:
    if child.stdout.readline().strip() != 'ready': raise RuntimeError('시험 외부 FD 준비 실패')
    if mode in ('wal', 'wal-mapping', 'real-archive', 'staged-archive', 'metadata-archive', 'tree-archive'):
        if not Path(str(db) + '-wal').is_file() or not Path(str(db) + '-shm').is_file():
            raise RuntimeError('시험 WAL·SHM 준비 실패')
        data.chmod(0o755)
        if mode == 'tree-archive': db.parent.chmod(0o755)
        print('기존 시험 SQLite WAL 연결과 WAL·SHM 준비 확인', flush=True)
    if fence.prepare() is not True: raise RuntimeError('시험 서비스 차단 실패')
    subprocess.run(['/usr/bin/systemctl', 'start', unit], check=False, timeout=60)
    if not stopped() or show('ConditionResult') != 'no' or fence.check() is not True:
        raise RuntimeError('시험 서비스 재시작 차단 실패')
    print('시험 서비스 정지와 명시적 재시작 차단 확인', flush=True)
    if mode in ('wal', 'wal-mapping', 'real-archive', 'staged-archive', 'metadata-archive', 'tree-archive'):
        if request('walwrite') != 'committed': raise RuntimeError('기존 시험 WAL 연결 쓰기 확인 실패')
        print('시험 서비스 정지 후 외부 기존 WAL 연결의 커밋 가능 확인', flush=True)
    fd = os.open(db, os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC)
    try: fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
    except OSError as error:
        if error.errno not in (errno.EAGAIN, errno.EACCES): raise
    else:
        fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
        raise RuntimeError('기존 외부 FD가 있는데 시험 차단이 허용됐습니다.')
    if backup.exists(): raise RuntimeError('기존 참조 차단 전 백업이 생성됐습니다.')
    print('기존 시험 DB FD가 있으면 파일 보호 획득과 백업 시작 거절 확인', flush=True)
    if request('close') != 'closed': raise RuntimeError('시험 외부 FD 종료 실패')
    if mode == 'wal-mapping':
        try:
            fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
        except OSError as error:
            if error.errno not in (errno.EAGAIN, errno.EACCES): raise
        else:
            fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
            raise RuntimeError('기존 공유 매핑이 있는데 시험 보호 획득이 허용됐습니다.')
        print('SQLite 연결과 파일 FD 종료 후 남은 공유 매핑의 보호 획득 거절 확인', flush=True)
        if request('unmap') != 'unmapped': raise RuntimeError('시험 공유 매핑 해제 실패')
        print('시험 공유 매핑 해제 확인', flush=True)
    if mode in ('wal', 'wal-mapping', 'real-archive', 'staged-archive', 'metadata-archive', 'tree-archive'):
        os.close(fd)
        fd = None
        checkpoint = sqlite3.connect(db, timeout=5)
        try:
            result = checkpoint.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()
            if not result or result[0] != 0 or result[1] != result[2]:
                raise RuntimeError('시험 WAL 체크포인트 실패: ' + repr(result))
            values = {row[0] for row in checkpoint.execute('SELECT value FROM fixture')}
            if values != {'verified', 'before-stop', 'after-stop'}:
                raise RuntimeError('체크포인트 전후 시험 행 확인 실패')
        finally:
            checkpoint.close()
        if any(Path(str(db) + suffix).exists() for suffix in ('-wal', '-shm', '-journal')):
            raise RuntimeError('시험 부수 파일이 남아 단일 파일 백업을 중단합니다.')
        print('시험 외부 연결 종료 후 WAL 체크포인트와 SQLite 부수 파일 부재 확인', flush=True)
        fd = os.open(db, os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC)
    fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
    if not held(): raise RuntimeError('시험 보호 확인 실패')
    normal_guard = FixtureGuard()
    before = os.fstat(fd)
    with normal_guard.begin_backup(backup) as archive:
        info = tarfile.TarInfo('fixture.sqlite3')
        info.size = before.st_size
        os.lseek(fd, 0, os.SEEK_SET)
        with os.fdopen(os.dup(fd), 'rb') as file:
            archive.addfile(info, file)
    normal_guard.require()
    after = os.fstat(fd)
    if (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_size, after.st_mtime_ns, after.st_ctime_ns):
        raise RuntimeError('시험 DB가 백업 중 변경됐습니다.')
    fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
    with tarfile.open(backup, 'r') as archive:
        member = archive.extractfile('fixture.sqlite3')
        saved = member.read()
    os.lseek(fd, 0, os.SEEK_SET)
    if hashlib.sha256(saved).digest() != hashlib.sha256(os.read(fd, len(saved) + 1)).digest():
        raise RuntimeError('시험 아카이브 내용 불일치')
    copy = records / 'restored.sqlite3'
    copy.write_bytes(saved)
    check = sqlite3.connect(copy)
    try:
        if check.execute('PRAGMA integrity_check').fetchone() != ('ok',): raise RuntimeError('시험 DB 무결성 오류')
        values = {row[0] for row in check.execute('SELECT value FROM fixture')}
        expected = {'verified', 'before-stop', 'after-stop'} if mode in ('wal', 'wal-mapping', 'real-archive', 'staged-archive', 'metadata-archive', 'tree-archive') else {'verified'}
        if values != expected: raise RuntimeError('시험 DB 복원 내용 오류')
    finally: check.close()
    print('시험 보호 유지 중 단일 SQLite 파일 백업과 격리 복원·무결성 확인', flush=True)
    if mode == 'real-archive':
        fixture_root = records / 'real-archive-input'
        output = records / 'real-archive-output'
        for relative in ('opt/bc250-ai-studio', 'opt/ai-studio-data/database',
                         'opt/ai/config', 'etc/systemd/system', 'var/lib/bc250-model-control'):
            (fixture_root / relative).mkdir(parents=True, exist_ok=True)
        for name in ('bc250-ai-studio', 'bc250-llm-gate', 'bc250-llm-client'):
            (fixture_root / 'etc' / (name + '.env')).write_text('fixture\n')
            (fixture_root / 'etc/systemd/system' / (name + '.service')).write_text('fixture\n')
        (fixture_root / 'opt/ai/config/active-model.conf').write_text('fixture\n')
        (fixture_root / 'var/lib/bc250-model-control/legacy-pause.json').write_text('{}\n')
        os.link(db, fixture_root / 'opt/ai-studio-data/database/studio.sqlite3')
        caddy_file = records / 'fixture-caddy'
        caddy_file.write_text('fixture\n')
        output.mkdir(mode=0o700)
        fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
        archive_guard = FixtureGuard()
        archive_guard.require()
        import time
        archive_log = (records / 'real-archive.log').open('wb')
        process = subprocess.Popen(['/usr/bin/bash', '-c',
            'source "$1"; bc250_backup_archive "$2" "$3" "$4"', 'fixture',
            str(source.parent / 'backup-archive.sh'), str(fixture_root), str(output), str(caddy_file)],
            stdout=archive_log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            deadline = time.monotonic() + 20
            while time.monotonic() < deadline:
                if fcntl.fcntl(fd, fcntl.F_GETLEASE) != fcntl.F_WRLCK:
                    break
                if process.poll() is not None:
                    raise RuntimeError('실제 시험 아카이브가 lease 요청 전 종료됐습니다.')
                time.sleep(.1)
            else:
                raise RuntimeError('실제 시험 아카이브의 DB 열기 요청을 확인하지 못했습니다.')
            try:
                archive_guard.require()
            except RuntimeError:
                pass
            else:
                raise RuntimeError('아카이브의 DB 열기 요청 후 보호 상실을 감지하지 못했습니다.')
            print('실제 시험 아카이브의 DB 열기 요청 이후 lease 상태 변화 확인', flush=True)
        finally:
            if process.poll() is None:
                try: os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError: pass
                try: process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    try: os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError: pass
                    process.wait(timeout=10)
            archive_log.close()
        if (output / 'SHA256SUMS').exists():
            raise RuntimeError('보호가 상실된 시험 아카이브가 완료 상태로 표시됐습니다.')
        print('lease 상태 변화 시 시험 아카이브의 완료 체크섬 부재와 미완료 자료 보존 확인', flush=True)
        fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
    if mode in ('staged-archive', 'metadata-archive'):
        fixture_root = records / 'staged-archive-input'
        output = records / 'staged-archive-output'
        for relative in ('opt/bc250-ai-studio', 'opt/ai-studio-data/database',
                         'opt/ai/config', 'etc/systemd/system', 'var/lib/bc250-model-control'):
            (fixture_root / relative).mkdir(parents=True, exist_ok=True)
        for name in ('bc250-ai-studio', 'bc250-llm-gate', 'bc250-llm-client'):
            (fixture_root / 'etc' / (name + '.env')).write_text('fixture\n')
            (fixture_root / 'etc/systemd/system' / (name + '.service')).write_text('fixture\n')
        (fixture_root / 'opt/ai/config/active-model.conf').write_text('fixture\n')
        (fixture_root / 'var/lib/bc250-model-control/legacy-pause.json').write_text('{}\n')
        caddy_file = records / 'staged-fixture-caddy'
        caddy_file.write_text('fixture\n')
        output.mkdir(mode=0o700)
        fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
        staged_guard = FixtureGuard()
        staged_guard.require()
        before_copy = os.fstat(fd)
        staged_db = fixture_root / 'opt/ai-studio-data/database/studio.sqlite3'
        if mode == 'metadata-archive':
            stage_spec = importlib.util.spec_from_file_location('fixture_stage', source.parent / 'stage-protected-db.py')
            stage_module = importlib.util.module_from_spec(stage_spec)
            stage_spec.loader.exec_module(stage_module)
            stage_module.stage_file(fd, staged_db.parent, staged_db.name,
                                    check_fence=lambda: staged_guard.require() is None)
        else:
            os.lseek(fd, 0, os.SEEK_SET)
            with os.fdopen(os.dup(fd), 'rb') as source_file, staged_db.open('xb') as destination:
                import shutil
                shutil.copyfileobj(source_file, destination, length=1024 * 1024)
                destination.flush()
                os.fsync(destination.fileno())
        staged_guard.require()
        after_copy = os.fstat(fd)
        if (before_copy.st_size, before_copy.st_mtime_ns, before_copy.st_ctime_ns) != (
                after_copy.st_size, after_copy.st_mtime_ns, after_copy.st_ctime_ns):
            raise RuntimeError('시험 DB 복사 중 원본 변경')
        os.lseek(fd, 0, os.SEEK_SET)
        if hashlib.sha256(staged_db.read_bytes()).digest() != hashlib.sha256(os.read(fd, before_copy.st_size + 1)).digest():
            raise RuntimeError('시험 보호 복사본 내용 불일치')
        staged_guard.require()
        result = subprocess.run(['/usr/bin/bash', '-c',
            'source "$1"; bc250_backup_archive "$2" "$3" "$4"', 'fixture',
            str(source.parent / 'backup-archive.sh'), str(fixture_root), str(output), str(caddy_file)],
            capture_output=True, text=True, timeout=120, check=False)
        (records / 'staged-archive.log').write_text(result.stdout + result.stderr)
        if result.returncode != 0:
            raise RuntimeError('시험 보호 복사본 아카이브 실패: ' + str(result.returncode))
        staged_guard.require()
        subprocess.run(['/usr/bin/sha256sum', '-c', 'SHA256SUMS'], cwd=output,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True, timeout=30)
        with tarfile.open(output / 'legacy.tar', 'r') as archive:
            member = archive.extractfile('opt/ai-studio-data/database/studio.sqlite3')
            if member is None or member.read() != staged_db.read_bytes():
                raise RuntimeError('시험 아카이브의 DB 내용 불일치')
        staged_guard.require()
        if mode == 'metadata-archive':
            restored = records / 'metadata-restored'
            restored.mkdir(mode=0o700)
            subprocess.run(['/usr/bin/tar', '--extract', '--file=' + str(output / 'legacy.tar'),
                '--acls', '--xattrs', '--xattrs-include=*', '--selinux', '--numeric-owner',
                '--same-owner', '--same-permissions', '--directory=' + str(restored)], check=True, timeout=60)
            restored_db = restored / 'opt/ai-studio-data/database/studio.sqlite3'
            restored_info, source_info = restored_db.stat(), os.fstat(fd)
            if (restored_info.st_uid, restored_info.st_gid, stat.S_IMODE(restored_info.st_mode), restored_info.st_mtime_ns) != (
                    source_info.st_uid, source_info.st_gid, stat.S_IMODE(source_info.st_mode), source_info.st_mtime_ns):
                raise RuntimeError('격리 복원된 시험 DB 소유권·권한·수정 시각 불일치')
            source_attrs = {key: os.getxattr(fd, key) for key in os.listxattr(fd)}
            restored_attrs = {key: os.getxattr(restored_db, key) for key in os.listxattr(restored_db)}
            if source_attrs != restored_attrs or restored_db.read_bytes() != staged_db.read_bytes():
                raise RuntimeError('격리 복원된 시험 DB 내용 또는 확장 속성 불일치')
            staged_guard.require()
            print('시험 DB 격리 복원 후 소유권·권한·ACL·SELinux 레이블과 내용 일치 확인', flush=True)
        fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
        print('원본 lease 유지 중 시험 DB 복사본 생성과 실제 아카이브·체크섬·DB 내용 확인', flush=True)
    if mode == 'tree-archive':
        stage_root = records / 'tree-stage'
        stage_dir = stage_root / 'opt/ai-studio-data/database'
        stage_dir.mkdir(mode=0o700, parents=True)
        output = records / 'tree-archive-output'
        output.mkdir(mode=0o700)
        caddy_file = records / 'tree-fixture-caddy'
        caddy_file.write_text('fixture\n')
        fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
        tree_guard = FixtureGuard()
        tree_guard.require()
        stage_spec = importlib.util.spec_from_file_location('fixture_stage', source.parent / 'stage-protected-db.py')
        stage_module = importlib.util.module_from_spec(stage_spec)
        stage_spec.loader.exec_module(stage_module)
        stage_module.stage_file(fd, stage_dir, 'studio.sqlite3', check_fence=lambda: tree_guard.require() is None)
        tree_guard.require()
        command = r'''
fixture_fd=$5
fixture_db=$6
fixture_marker=$8
fixture_unit=$9
bc250_check_db_fence() {
  /usr/bin/python3 -c 'import fcntl,os,sys; fd=int(sys.argv[1]); a=os.fstat(fd); b=os.stat(sys.argv[2], follow_symlinks=False); sys.exit(0 if fcntl.fcntl(fd,fcntl.F_GETLEASE)==fcntl.F_WRLCK and (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino) else 1)' "$fixture_fd" "$fixture_db" || return 1
  [ -f "$fixture_marker" ] || return 1
  [ "$(/usr/bin/systemctl show "$fixture_unit" -p ActiveState --value)" = inactive ] || return 1
  [ "$(/usr/bin/systemctl show "$fixture_unit" -p MainPID --value)" = 0 ] || return 1
}
source "$1"
bc250_backup_archive "$2" "$3" "$4" "$7"
'''
        result = subprocess.run(['/usr/bin/bash', '-c', command, 'fixture',
            str(source.parent / 'backup-archive.sh'), str(data), str(output), str(caddy_file),
            str(fd), str(db), str(stage_root), str(marker), unit], pass_fds=(fd,),
            capture_output=True, text=True, timeout=120, check=False)
        (records / 'tree-archive.log').write_text(result.stdout + result.stderr)
        if result.returncode:
            raise RuntimeError('원본 트리·보호 DB 복사본 시험 아카이브 실패: ' + str(result.returncode))
        tree_guard.require()
        subprocess.run(['/usr/bin/sha256sum', '-c', 'SHA256SUMS'], cwd=output,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True, timeout=30)
        restored = records / 'tree-restored'
        restored.mkdir(mode=0o700)
        subprocess.run(['/usr/bin/tar', '--extract', '--file=' + str(output / 'legacy.tar'),
            '--acls', '--xattrs', '--xattrs-include=*', '--selinux', '--numeric-owner',
            '--same-owner', '--same-permissions', '--directory=' + str(restored)], check=True, timeout=60)
        restored_db = restored / 'opt/ai-studio-data/database/studio.sqlite3'
        a, b = os.fstat(fd), restored_db.stat()
        if (a.st_uid, a.st_gid, stat.S_IMODE(a.st_mode), a.st_mtime_ns) != (
                b.st_uid, b.st_gid, stat.S_IMODE(b.st_mode), b.st_mtime_ns):
            raise RuntimeError('실제 트리 시험 DB 복원 메타데이터 불일치')
        if {k: os.getxattr(fd, k) for k in os.listxattr(fd)} != {
                k: os.getxattr(restored_db, k) for k in os.listxattr(restored_db)}:
            raise RuntimeError('실제 트리 시험 DB ACL·SELinux 불일치')
        staged_db = stage_dir / 'studio.sqlite3'
        if restored_db.read_bytes() != staged_db.read_bytes():
            raise RuntimeError('실제 트리 시험 DB 복원 내용 불일치')
        if (restored / 'opt/bc250-ai-studio/fixture.txt').read_text() != 'studio-code-fixture\n':
            raise RuntimeError('시험 코드 복원 내용 오류')
        if (restored / 'opt/ai-studio-data/other.txt').read_text() != 'other-data-fixture\n':
            raise RuntimeError('시험 데이터 복원 내용 오류')
        tree_guard.require()
        fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
        print('시험 원본 트리와 보호 DB 복사본의 실제 아카이브·격리 복원 및 메타데이터 확인', flush=True)
    fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
    if not held(): raise RuntimeError('차단 상실 시험 준비 실패')
    loss_guard = FixtureGuard()
    loss_guard.require()
    result = request('open')
    if result != f'errno={errno.EAGAIN}': raise RuntimeError('시험 신규 접근 거절 실패: ' + result)
    print('시험 보호 중 다른 UID의 신규 파일 열기 거절 확인', flush=True)
    try:
        loss_guard.require()
    except RuntimeError:
        pass
    else:
        raise RuntimeError('lease 해제 요청 이후 보호 상실을 감지하지 못했습니다.')
    fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
    try:
        loss_guard.begin_backup(lost_backup)
    except RuntimeError:
        pass
    else:
        raise RuntimeError('차단 상실 후 백업이 시작됐습니다.')
    if lost_backup.exists(): raise RuntimeError('차단 상실 후 백업 파일이 생성됐습니다.')
    if request('open') != 'opened': raise RuntimeError('시험 파일 보호 해제 후 접근 복원 실패')
    print('시험 lease 상실 감지 후 새 백업 거절과 접근 복원 확인', flush=True)
    os.close(fd)
    fd = None
    marker.unlink()
    subprocess.run(['/usr/bin/systemctl', 'start', unit], check=True, timeout=60)
    if show('ActiveState') != 'active' or (stat.S_IMODE(data.stat().st_mode), stat.S_IMODE(db.stat().st_mode)) != original:
        raise RuntimeError('시험 서비스 또는 파일 권한 복원 확인 실패')
    print('시험 서비스 실행 상태와 파일 권한 복원 확인', flush=True)
    (records / 'events.json').write_text(json.dumps(events, ensure_ascii=False))
    child.stdin.write('stop\n')
    child.stdin.flush()
    if child.wait(timeout=15): raise RuntimeError('시험 외부 프로세스 종료 실패')
finally:
    if fd is not None:
        try: fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
        except OSError: pass
        os.close(fd)
    if child.poll() is None:
        child.kill()
        child.wait(timeout=15)
    signal.signal(signal.SIGIO, old_handler)
print('시험 DB·비특권 UID 하나·시험 서비스 하나에 대한 흐름입니다. 다른 UID·전체 데이터·직접 호출 차단·운영 백업은 검증하지 않았습니다. 기존 매핑은 해당 시험 모드에서만 확인했습니다.', flush=True)
PY
systemctl stop "$unit"
rm -- "$unit_file"
systemctl daemon-reload
trap - ERR
echo "시험 unit 정리 완료; 시험 DB·백업·기록 보관: $data $records"
