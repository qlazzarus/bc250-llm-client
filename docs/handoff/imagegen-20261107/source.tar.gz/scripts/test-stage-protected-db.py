#!/usr/bin/env python3
"""Unit tests for one-file staging; these do not establish a real fence."""
import importlib.util
from pathlib import Path

import pytest

path = Path(__file__).resolve().parents[1] / 'deploy/model-control/stage-protected-db.py'
spec = importlib.util.spec_from_file_location('stage_protected_db', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_copy_and_reject_fence_loss(tmp_path, monkeypatch):
    source = tmp_path / 'source'
    source.write_bytes(b'fixture-content')
    stage = tmp_path / 'stage'
    stage.mkdir(mode=0o700)
    monkeypatch.setattr(module.os, 'geteuid', lambda: 0)
    monkeypatch.setattr(module, 'trusted_directory', lambda value: Path(value))
    monkeypatch.setattr(module, 'attributes', lambda _: {})
    monkeypatch.setattr(module.os, 'fchown', lambda *_: None)
    with source.open('rb') as file:
        digest = module.stage_file(file.fileno(), stage, 'copy', check_fence=lambda: True)
        assert (stage / 'copy').read_bytes() == source.read_bytes()
        assert len(digest) == 64
        states = iter((True, False))
        with pytest.raises(ValueError, match='차단'):
            module.stage_file(file.fileno(), stage, 'failed', check_fence=lambda: next(states))


def test_rejects_preexisting_target_and_hardlinked_source(tmp_path, monkeypatch):
    source = tmp_path / 'source'
    source.write_bytes(b'fixture')
    stage = tmp_path / 'stage'
    stage.mkdir(mode=0o700)
    monkeypatch.setattr(module.os, 'geteuid', lambda: 0)
    monkeypatch.setattr(module, 'trusted_directory', lambda value: Path(value))
    monkeypatch.setattr(module, 'attributes', lambda _: {})
    (stage / 'copy').write_bytes(b'existing')
    with source.open('rb') as file:
        with pytest.raises(FileExistsError):
            module.stage_file(file.fileno(), stage, 'copy', check_fence=lambda: True)
        (tmp_path / 'hardlink').hardlink_to(source)
        with pytest.raises(ValueError, match='단일 링크'):
            module.stage_file(file.fileno(), stage, 'new', check_fence=lambda: True)
