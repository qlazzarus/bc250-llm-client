#!/usr/bin/env bash
# Isolated VM test: actual file lock and journal; services and safety checks simulated.
set -Eeuo pipefail
umask 077
[[ $(id -u) == 0 && $(hostname) == bc250-fedora43-test && $(systemd-detect-virt) == qemu && $(getenforce) == Enforcing && $# == 1 ]] || exit 1
fixture=$(mktemp -d /var/lib/bc250-locked-start.XXXXXXXX)
records=$(mktemp -d /var/backups/bc250-locked-start.XXXXXXXX)
trap 'echo "시험 중단. 시험 자료 보관: $fixture $records" >&2' ERR
restorecon -RF "$fixture" "$records"
python3 - "$1/deploy/model-control" "$fixture" "$records" <<'PY'
import importlib.util
import subprocess
import sys
from pathlib import Path

source, fixture, records = map(Path, sys.argv[1:])
sys.dont_write_bytecode = True
def load(name, file):
    spec = importlib.util.spec_from_file_location(name, source / file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
startup_module = load('fixture_start', 'start-new-services.py')
sequence_module = load('fixture_sequence', 'startup-lock-sequence.py')
handoff_module = load('fixture_handoff', 'gpu-lock-handoff.py')
fence_module = load('fixture_fence', 'advisory-gpu-fence.py')
wrapper_module = load('fixture_wrapper', 'locked-service-start.py')
journal_module = load('fixture_journal', 'migration-journal.py')
probe = '''import fcntl, os, sys
fd = os.open(sys.argv[1], os.O_RDWR | os.O_NOFOLLOW)
try: fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError: raise SystemExit(42)
os.close(fd)
'''
startup_module.trusted_file = lambda _: None
startup_module.socket_stopped = lambda: None
startup_module.api_ready = lambda: None
startup_module.worker_disabled = lambda: None
startup_module.wait_for_coordination = lambda _: None
startup_module.ENABLE_LINKS = ()
def scenario(name, lose_hold):
    lock = fixture / (name + '.lock')
    lock.touch(mode=0o600)
    folder = records / name
    folder.mkdir(mode=0o700)
    journal = journal_module.MigrationJournal(folder)
    held = fence_module.AdvisoryGPUFence(lock, group_id=0)
    state = {'hold': True, 'confirm': 0}
    def command(args, **_):
        if 'app.services.gate_admin' in args:
            result = subprocess.run(['/usr/bin/python3', '-c', probe, str(lock)], check=False)
            if result.returncode: raise RuntimeError('시험 확인에서 잠금 재획득 실패')
            state['confirm'] += 1
    startup_module.command = command
    startup = startup_module.NewServiceStart('/fixture/backup-archive.sh',
        check_maintenance=lambda: True, check_release=lambda: True,
        check_local_idle=lambda: True, check_running=lambda: True,
        check_configuration=lambda: True, expected_client_user='fixture')
    handoff = handoff_module.GPULockHandoff(fence=held, old_generation_gone=lambda: True,
        other_callers_blocked=lambda: True, gpu_safe=lambda: True, prepare_new_lock=lambda: True)
    sequence = sequence_module.StartupLockSequence(record=journal, check_pre_handoff=lambda: True,
        prepare_tmpfiles=lambda: True, handoff=handoff, check_before_confirm=lambda: True,
        check_deployment_hold=lambda: state['hold'], confirm_startup=startup.confirm_startup)
    runner = wrapper_module.LockedServiceStart(startup, sequence)
    try:
        runner.start()
        if subprocess.run(['/usr/bin/python3', '-c', probe, str(lock)], check=False).returncode != 42:
            raise RuntimeError('수동 Client 대기 중 시험 잠금 경합 실패')
        if lose_hold:
            state['hold'] = False
            try: runner.finish()
            except wrapper_module.LockedServiceStartError: pass
            else: raise RuntimeError('배포 보류 상실이 허용됐습니다.')
            if state['confirm'] or not held.check(): raise RuntimeError('실패 후 확인 또는 잠금 상태 오류')
            print('모의 배포 보류 상실 시 확인 전 중단과 시험 잠금 유지 확인', flush=True)
        else:
            runner.finish()
            if state['confirm'] != 1 or held.fd is not None or sequence.phase != 'complete':
                raise RuntimeError('시험 잠금 인계 또는 확인 상태 오류')
            print('수동 대기 중 시험 잠금 보유와 시작 확인 시 잠금 인계·재획득 확인', flush=True)
    finally:
        if held.fd is not None: held.release()
        journal.close()
scenario('success', False)
scenario('hold-loss', True)
print('실제 시험 flock과 기록을 사용했으며 서비스·gate·GPU 안전·직접 호출 차단·Client는 모의입니다.', flush=True)
PY
trap - ERR
echo "시험 자료 보관: $fixture $records"
