#!/usr/bin/env bash
# Boot verified installer rescue without disks or networking. Preserve all logs.
set -Eeuo pipefail
umask 077
[[ $(id -u) != 0 && $# == 1 ]] || { echo '일반 사용자로 ISO 경로 하나를 전달하세요.' >&2; exit 1; }
image=$(realpath -e -- "$1")
case "$image" in "$HOME"/bc250-maintenance-media.*/Fedora-Server-netinst-x86_64-43-1.6.iso) ;; *) echo '예상하지 않은 매체 경로입니다.' >&2; exit 1 ;; esac
[[ -f $image && -O $image && ! -L $1 ]] || { echo '매체 소유권 또는 형식 오류' >&2; exit 1; }
for dir in "$HOME/bc250-fedora43-test-vm" "$HOME/bc250-maintenance-vm.hn3AiGJe"; do
  if [[ -f $dir/vm.pid ]]; then
    pid=$(cat "$dir/vm.pid")
    [[ $pid =~ ^[0-9]+$ ]] || { echo '기존 PID 파일 오류' >&2; exit 1; }
    if kill -0 "$pid" 2>/dev/null; then echo "기존 PID가 실행 중입니다: $pid" >&2; exit 1; fi
  fi
done
available=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)
[[ $available =~ ^[0-9]+$ && $available -ge 3000000 ]] || { echo '사용 가능한 메모리가 부족합니다.' >&2; exit 1; }
printf '%s  %s\n' '16fd70ddae2c7de13e485637c3da1fb385dd8220389f988279ea3b3d561243cc' "$image" | sha256sum -c -
probe_dir=$(mktemp -d "$HOME/bc250-rescue-probe.XXXXXXXX")
trap 'echo "시험 중단. 시험 자료 보존: $probe_dir" >&2' ERR
isoinfo -R -i "$image" -x /images/pxeboot/vmlinuz > "$probe_dir/vmlinuz"
isoinfo -R -i "$image" -x /images/pxeboot/initrd.img > "$probe_dir/initrd.img"
[[ -s "$probe_dir/vmlinuz" && -s "$probe_dir/initrd.img" ]] || { echo '커널 또는 초기화 이미지 추출 실패' >&2; exit 1; }
cd "$probe_dir"
nice -n 15 qemu-system-x86_64 \
  -accel tcg,thread=multi -m 1536 -smp 2 \
  -kernel vmlinuz -initrd initrd.img \
  -append 'inst.stage2=hd:LABEL=Fedora-S-dvd-x86_64-43 inst.rescue console=ttyS0' \
  -drive "file=$image,media=cdrom,readonly=on" \
  -net none -display none -monitor none -serial file:serial.log \
  -pidfile vm.pid -daemonize
pid=$(cat vm.pid)
[[ $pid =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null || { echo '시험 VM 시작 여부 미확인' >&2; exit 1; }
echo "디스크·네트워크 없는 복구 부팅 시험 시작: PID $pid"
echo "시험 자료: $probe_dir"
echo '이 시험은 serial 출력 관찰이며 입력·SSH·DB 차단은 검증하지 않습니다.'
