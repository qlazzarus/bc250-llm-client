#!/usr/bin/env bash
# A private mount namespace can retain the previous writable mount view.
set -Eeuo pipefail
umask 077
[[ $(id -u) == 0 && $(hostname) == bc250-fedora43-test \
  && $(systemd-detect-virt) == qemu && $(getenforce) == Enforcing \
  && ( $# == 1 || ( $# == 2 && $2 == observe ) ) ]] || exit 1
mode=${2:-ordinary}
if [[ $mode == observe ]]; then
  [[ -f $1/deploy/model-control/observe-db-process-references.py ]] || exit 1
fi
for tool in systemd-run unshare setpriv runuser python3 mount umount mountpoint; do
  command -v "$tool" >/dev/null || exit 1
done
records=$(mktemp -d /var/backups/bc250-db-mountns.XXXXXXXX)
data=$(mktemp -d /var/lib/bc250-db-mountns.XXXXXXXX)
control=$(mktemp -d /var/lib/bc250-db-mount-control.XXXXXXXX)
code=$(mktemp -d /opt/bc250-db-mountns.XXXXXXXX)
suffix=${records##*.}
[[ $suffix =~ ^[A-Za-z0-9]{8}$ ]] || exit 1
unit="bc250-db-mountns-$suffix.service"
[[ $(systemctl show "$unit" -p LoadState --value) == not-found ]] || exit 1
failure() {
  systemctl stop "$unit" >/dev/null 2>&1 || true
  if mountpoint -q "$data"; then umount "$data" || echo "시험 마운트를 해제하지 못했습니다: $data" >&2; fi
  echo "시험 중단. 시험 자료 보관: $records $data $control $code" >&2
}
trap failure ERR
chmod 0755 "$code"
chown ai-studio:ai-studio "$data" "$control"
chmod 0700 "$data" "$control"
python3 - "$data/fixture.sqlite3" <<'PY'
import sqlite3
import sys
connection = sqlite3.connect(sys.argv[1])
connection.execute('CREATE TABLE fixture (value TEXT NOT NULL)')
connection.commit()
connection.close()
PY
chown ai-studio:ai-studio "$data/fixture.sqlite3"
chmod 0600 "$data/fixture.sqlite3"
cat > "$code/worker.py" <<'PY'
import json
import os
import sqlite3
import sys
import time
from pathlib import Path

data, control, uid, mode = Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
assert os.getuid() == uid and os.geteuid() == uid
# No DB or DB-directory descriptor is opened before the mount change.
(control / 'ready').write_text('ready\n')
deadline = time.monotonic() + 120
while not (control / 'continue').exists():
    if time.monotonic() >= deadline: raise SystemExit('시험 신호 대기 시간 초과')
    time.sleep(.1)
result = {}
connection = None
try:
    connection = sqlite3.connect(data / 'fixture.sqlite3', timeout=10)
    connection.execute("INSERT INTO fixture VALUES ('other-mount-namespace')")
    connection.commit()
    result['sqlite_write'] = '성공'
except sqlite3.Error as error:
    result['sqlite_write'] = '실패'
    result['sqlite_error'] = getattr(error, 'sqlite_errorname', '확인 불가')
temporary = control / 'result.tmp'
temporary.write_text(json.dumps(result, ensure_ascii=False) + '\n')
os.replace(temporary, control / 'result.json')
if mode == 'observe' and connection is not None:
    while not (control / 'close').exists():
        if time.monotonic() >= deadline: raise SystemExit('시험 연결 종료 대기 시간 초과')
        time.sleep(.1)
    connection.close()
    (control / 'closed').write_text('closed\n')
    while not (control / 'stop').exists():
        if time.monotonic() >= deadline: raise SystemExit('시험 프로세스 종료 대기 시간 초과')
        time.sleep(.1)
elif connection is not None:
    connection.close()
PY
chmod 0644 "$code/worker.py"
restorecon -RF "$data" "$control" "$code" "$records"
uid=$(id -u ai-studio)
gid=$(id -g ai-studio)
[[ $uid -gt 0 && $gid -gt 0 ]] || exit 1
systemd-run --quiet --unit="$unit" --property=Type=exec --property=KillMode=control-group \
  /usr/bin/unshare --mount --propagation private /usr/bin/setpriv \
  --reuid="$uid" --regid="$gid" --clear-groups /usr/bin/python3 -u "$code/worker.py" "$data" "$control" "$uid" "$mode"
ready=no
for _ in {1..90}; do
  if [[ -f $control/ready ]]; then ready=yes; break; fi
  systemctl is-active --quiet "$unit" || { echo '시험 프로세스가 종료됐습니다.' >&2; false; }
  sleep .5
done
[[ $ready == yes ]] || { echo '시험 프로세스 준비 시간 초과' >&2; false; }
pid=$(systemctl show "$unit" -p MainPID --value)
[[ $pid =~ ^[0-9]+$ && $pid -gt 1 ]] || exit 1
host_ns=$(stat -Lc '%d:%i' /proc/self/ns/mnt)
worker_ns=$(stat -Lc '%d:%i' "/proc/$pid/ns/mnt")
[[ $host_ns != "$worker_ns" ]] || { echo '별도 시험 마운트 네임스페이스 확인 실패' >&2; false; }
echo '비특권 시험 프로세스의 별도 마운트 네임스페이스 확인'
mount --bind "$data" "$data"
mount -o remount,bind,ro "$data"
runuser -u ai-studio -- python3 - "$data/fixture.sqlite3" <<'PY'
import errno
import os
import sys
try:
    fd = os.open(sys.argv[1], os.O_RDWR)
except OSError as error:
    if error.errno != errno.EROFS: raise
    print('시험 VM 기본 네임스페이스의 새 DB 쓰기 열기 거절 확인', flush=True)
else:
    os.close(fd)
    raise SystemExit('읽기 전용 시험 경로에서 새 쓰기 열기가 허용됐습니다.')
PY
touch "$control/continue"
done=no
for _ in {1..90}; do
  if [[ -f $control/result.json ]]; then done=yes; break; fi
  if ! systemctl is-active --quiet "$unit"; then
    [[ -f $control/result.json ]] && { done=yes; break; }
    echo '시험 결과 없이 프로세스가 종료됐습니다.' >&2
    false
  fi
  sleep .5
done
[[ $done == yes ]] || { echo '시험 결과 대기 시간 초과' >&2; false; }
python3 - "$control/result.json" <<'PY'
import json
import sys
from pathlib import Path
result = json.loads(Path(sys.argv[1]).read_text())
if result.get('sqlite_write') not in {'성공', '실패'}:
    raise SystemExit('시험 결과 형식 오류')
print('별도 마운트 네임스페이스에서 새 SQLite 연결과 쓰기:', result, flush=True)
PY
if [[ $mode == observe ]]; then
  python3 - "$1/deploy/model-control/observe-db-process-references.py" "$pid" "$data" "$control" <<'PY'
import importlib.util
import json
import sys
import time
from pathlib import Path

spec = importlib.util.spec_from_file_location('db_references', sys.argv[1])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
pid, data, control = int(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
result = json.loads((control / 'result.json').read_text())
if result.get('sqlite_write') != '성공':
    raise SystemExit('별도 네임스페이스의 시험 쓰기가 실패해 연결 참조 시험을 진행할 수 없습니다.')
observed = module.observe_process(pid, data, data / 'fixture.sqlite3')
if 'fd' not in observed:
    raise SystemExit('별도 네임스페이스의 시험 DB 파일 FD를 감지하지 못했습니다: ' + repr(observed))
print('별도 마운트 네임스페이스의 열린 시험 DB FD 감지 확인', flush=True)
(control / 'close').touch()
for _ in range(120):
    if (control / 'closed').exists(): break
    time.sleep(.5)
else:
    raise SystemExit('별도 네임스페이스의 시험 DB 연결 종료 시간 초과')
observed = module.observe_process(pid, data, data / 'fixture.sqlite3')
if observed:
    raise SystemExit('시험 연결 종료 후 DB 참조가 남았습니다: ' + repr(observed))
print('별도 네임스페이스의 시험 DB 연결 종료 후 참조 없음 확인', flush=True)
(control / 'stop').touch()
PY
fi
if ! systemctl stop "$unit" 2>/dev/null; then
  [[ $(systemctl show "$unit" -p LoadState --value) == not-found ]] || {
    echo '시험 서비스 정지 상태를 확인하지 못했습니다.' >&2; false;
  }
fi
umount "$data"
trap - ERR
echo "시험 서비스와 마운트 정리 완료; 시험 자료 보관: $records $data $control $code"
echo '운영 DB·서비스는 변경하지 않았습니다. 별도 시험 네임스페이스 하나의 결과이며 운영 접근 가능성을 단정하지 않습니다.'
