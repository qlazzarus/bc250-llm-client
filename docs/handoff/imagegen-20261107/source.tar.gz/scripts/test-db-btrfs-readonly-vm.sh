#!/usr/bin/env bash
# Disposable VM only: one isolated loop filesystem and a throwaway subvolume.
set -Eeuo pipefail
umask 077
[[ $(id -u) == 0 && $(hostname) == bc250-fedora43-test && $(systemd-detect-virt) == qemu && $(getenforce) == Enforcing && $# == 1 ]] || exit 1
for tool in btrfs mkfs.btrfs losetup mount umount unshare setpriv systemd-run python3; do command -v "$tool" >/dev/null || exit 1; done
if ! losetup -f >/dev/null 2>&1; then
  echo '시험 VM에서 사용 가능한 loop 장치를 찾지 못했습니다. 운영 파일 시스템은 변경하지 않았습니다.' >&2
  exit 1
fi
records=$(mktemp -d /var/backups/bc250-btrfs-fence.XXXXXXXX)
code=$(mktemp -d /opt/bc250-btrfs-fence.XXXXXXXX)
control=$(mktemp -d /var/lib/bc250-btrfs-control.XXXXXXXX)
suffix=${records##*.}
[[ $suffix =~ ^[A-Za-z0-9]{8}$ ]] || exit 1
unit=bc250-btrfs-fence-$suffix.service
[[ $(systemctl show "$unit" -p LoadState --value) == not-found ]] || exit 1
image=$records/test-filesystem.img
base=$records/base
view=$records/view
loopdev=
cleanup() {
  systemctl stop "$unit" >/dev/null 2>&1 || true
  if mountpoint -q "$view"; then umount "$view" || echo "시험 마운트 해제 실패: $view" >&2; fi
  if mountpoint -q "$base"; then umount "$base" || echo "시험 마운트 해제 실패: $base" >&2; fi
  if [[ -n $loopdev ]]; then losetup -d "$loopdev" || echo "시험 loop 장치 해제 실패: $loopdev" >&2; fi
}
failure() { cleanup; echo "시험 중단. 시험 자료 보관: $records $code $control" >&2; }
trap failure ERR
mkdir -m 755 "$base" "$view"
chmod 0755 "$records" "$code"
chown ai-studio:ai-studio "$control"
chmod 0700 "$control"
restorecon -RF "$records" "$code" "$control"
truncate -s 512M "$image"
loopdev=$(losetup --find --show "$image")
[[ $loopdev == /dev/loop* ]] || { echo '시험 loop 장치 확인 실패' >&2; false; }
mkfs.btrfs -q -f "$loopdev"
mount -t btrfs -o subvolid=5 "$loopdev" "$base"
btrfs subvolume create "$base/fixture" >/dev/null
mount -t btrfs -o subvol=fixture "$loopdev" "$view"
chmod 0777 "$view"
cat > "$code/worker.py" <<'PY'
import json
import mmap
import os
import sqlite3
import sys
import time
from pathlib import Path

view, control, uid = Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3])
assert os.geteuid() == uid
connection = sqlite3.connect(view / 'fixture.sqlite3', timeout=1)
assert connection.execute('PRAGMA journal_mode=WAL').fetchone()[0].lower() == 'wal'
connection.execute('CREATE TABLE fixture (value TEXT)')
connection.commit()
file_fd = os.open(view / 'file.bin', os.O_CREAT | os.O_RDWR, 0o600)
os.write(file_fd, b'0123456789abcdef')
shared = mmap.mmap(file_fd, 16, access=mmap.ACCESS_WRITE)
directory_fd = os.open(view, os.O_RDONLY | os.O_DIRECTORY)
(control / 'ready').write_text('ready')
deadline = time.monotonic() + 240
while not (control / 'go').exists():
    if time.monotonic() >= deadline: raise SystemExit('시험 신호 시간 초과')
    time.sleep(.1)
def attempt(name, action):
    try:
        action()
    except (OSError, sqlite3.Error, ValueError) as error:
        value = {'result': '거절', 'type': type(error).__name__, 'errno': getattr(error, 'errno', None),
                 'sqlite': getattr(error, 'sqlite_errorname', None)}
    else:
        value = {'result': '성공'}
    (control / (name + '.json')).write_text(json.dumps(value, ensure_ascii=False))
def file_write():
    os.pwrite(file_fd, b'X', 0)
    os.fsync(file_fd)
def directory_write():
    new = os.open('new-file', os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600, dir_fd=directory_fd)
    os.close(new)
def sqlite_write():
    connection.execute("INSERT INTO fixture VALUES ('after-readonly')")
    connection.commit()
def mapping_write():
    shared[1:2] = b'Y'
    shared.flush()
for name, action in [('file-fd', file_write), ('dir-fd', directory_write),
                     ('sqlite-wal', sqlite_write), ('mapping', mapping_write)]:
    attempt(name, action)
(control / 'done').write_text('done')
shared.close()
os.close(file_fd)
os.close(directory_fd)
connection.close()
PY
chmod 0644 "$code/worker.py"
restorecon -RF "$code"
uid=$(id -u ai-studio)
gid=$(id -g ai-studio)
systemd-run --quiet --unit="$unit" --property=Type=exec --property=KillMode=control-group \
  /usr/bin/unshare --mount --propagation private /usr/bin/setpriv --reuid="$uid" --regid="$gid" --clear-groups \
  /usr/bin/python3 -u "$code/worker.py" "$view" "$control" "$uid"
ready=no
for _ in {1..120}; do
  if [[ -f $control/ready ]]; then ready=yes; break; fi
  systemctl is-active --quiet "$unit" || { echo '시험 프로세스 준비 실패' >&2; journalctl -u "$unit" -n 20 --no-pager -o cat; false; }
  sleep .5
done
[[ $ready == yes ]] || { echo '시험 프로세스 준비 시간 초과' >&2; false; }
pid=$(systemctl show "$unit" -p MainPID --value)
[[ $pid =~ ^[0-9]+$ && $pid -gt 1 ]] || { echo '시험 PID 확인 실패' >&2; false; }
[[ $(stat -Lc '%d:%i' /proc/self/ns/mnt) != "$(stat -Lc '%d:%i' "/proc/$pid/ns/mnt")" ]] || { echo '별도 마운트 네임스페이스 확인 실패' >&2; false; }
echo '별도 네임스페이스의 기존 시험 파일 FD·디렉터리 FD·SQLite WAL 연결·공유 매핑 준비 확인'
if ! btrfs property set -ts "$base/fixture" ro true >"$records/readonly.log" 2>&1; then
  echo '기존 쓰기 참조가 열린 상태에서 시험 서브볼륨 읽기 전용 전환 실패:'
  cat "$records/readonly.log"
  echo '전환을 적용할 수 없어 쓰기 차단 여부는 확인하지 않았습니다.'
else
  btrfs property get -ts "$base/fixture" ro | tee "$records/readonly-property.txt"
  [[ $(cat "$records/readonly-property.txt") == 'ro=true' ]] || { echo '시험 서브볼륨 속성 확인 실패' >&2; false; }
  touch "$control/go"
  for _ in {1..120}; do
    [[ -f $control/done ]] && break
    systemctl is-active --quiet "$unit" || break
    sleep .5
  done
  for name in file-fd dir-fd sqlite-wal mapping; do
    if [[ -f $control/$name.json ]]; then printf '%s: ' "$name"; cat "$control/$name.json"; printf '\n'; else echo "$name: 결과 없음"; fi
  done
  if [[ ! -f $control/done ]]; then
    echo '시험 프로세스가 모든 결과를 남기지 못했습니다. 미확인 항목은 차단으로 판단하지 않습니다.'
    journalctl -u "$unit" -n 20 --no-pager -o cat
  fi
fi
cleanup
trap - ERR
echo "시험 정리 요청 완료; 시험 이미지와 기록 보관: $records $code $control"
echo '운영 파일 시스템·서비스는 변경하지 않았습니다. 결과는 이 시험 구성에 한정되며 지속 차단이나 백업 안전을증명하지 않습니다.'
