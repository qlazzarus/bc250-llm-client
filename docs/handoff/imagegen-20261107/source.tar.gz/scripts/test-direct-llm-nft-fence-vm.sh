#!/usr/bin/env bash
# Disposable VM: all network and nft changes stay in a new test namespace.
set -Eeuo pipefail
umask 077
[[ $(id -u) == 0 && $(hostname) == bc250-fedora43-test && $(systemd-detect-virt) == qemu && $(getenforce) == Enforcing && ( $# == 1 || ( $# == 2 && ( $2 == identity || $2 == existing || $2 == listener || $2 == coordinator || $2 == coordinator-allowed || $2 == coordinator-backup || $2 == coordinator-db-backup || $2 == coordinator-retire || $2 == real-gate || $2 == real-gate-db-backup || $2 == real-gate-exclusive-backup || $2 == real-gate-restore || $2 == exclusive ) ) ) ]] || exit 1
mode=${2:-ordinary}
for tool in ip nsenter nft systemd-run python3; do command -v "$tool" >/dev/null || exit 1; done
[[ -f $1/deploy/model-control/direct-llm-nft-fence.py ]] || exit 1
if [[ $mode == identity || $mode == existing || $mode == listener || $mode == coordinator || $mode == coordinator-allowed || $mode == coordinator-backup || $mode == coordinator-db-backup || $mode == coordinator-retire || $mode == real-gate || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup || $mode == real-gate-restore || $mode == exclusive ]]; then [[ -f $1/backend/app/services/gate_process_identity.py ]] || exit 1; fi
records=$(mktemp -d /var/backups/bc250-direct-fence.XXXXXXXX)
suffix=${records##*.}
[[ $suffix =~ ^[A-Za-z0-9]{8}$ ]] || exit 1
namespace=bc250-direct-$suffix
gate=bc250-direct-gate-$suffix.service
other=bc250-direct-other-$suffix.service
rogue=bc250-direct-rogue-$suffix.service
server_unit=bc250-direct-server-$suffix.service
coordinator_unit=bc250-direct-coordinator-$suffix.service
studio_unit=bc250-direct-studio-$suffix.service
studio_file=/run/systemd/system/$studio_unit
studio_marker=$records/studio-blocked
gate_file=/run/systemd/system/$gate
gate_marker=$records/gate-blocked
server_pid=
failure() {
  if [[ -n $server_pid ]]; then kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true; fi
  echo "시험 중단. 시험 네임스페이스·unit·기록 보존: $namespace $gate $other $rogue $server_unit $coordinator_unit $studio_unit $records" >&2
}
trap failure ERR
[[ ! -e /run/netns/$namespace && $(systemctl show "$gate" -p LoadState --value) == not-found && $(systemctl show "$other" -p LoadState --value) == not-found && $(systemctl show "$rogue" -p LoadState --value) == not-found && $(systemctl show "$server_unit" -p LoadState --value) == not-found && $(systemctl show "$coordinator_unit" -p LoadState --value) == not-found && $(systemctl show "$studio_unit" -p LoadState --value) == not-found && ! -e $studio_file && ! -L $studio_file && ! -e $gate_file && ! -L $gate_file ]] || exit 1
ip netns add "$namespace"
ip -n "$namespace" link set lo up
if [[ $mode == identity || $mode == existing || $mode == listener || $mode == coordinator || $mode == coordinator-allowed || $mode == coordinator-backup || $mode == coordinator-db-backup || $mode == coordinator-retire || $mode == real-gate || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup || $mode == real-gate-restore || $mode == exclusive ]]; then
  if [[ $mode == coordinator-retire || $mode == real-gate || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup || $mode == real-gate-restore ]]; then
    if [[ $mode == real-gate || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup || $mode == real-gate-restore ]]; then
      [[ -x /opt/bc250-model-control/.venv/bin/python && -z $(find "$1/backend" -type l -print -quit) ]] || exit 1
      gate_code=$(mktemp -d /opt/bc250-real-direct-gate.XXXXXXXX)
      chmod 0755 "$gate_code"
      cp -R --no-preserve=ownership "$1/backend" "$gate_code/backend"
      chmod -R go-w "$gate_code/backend"
      cat > "$gate_code/gate.env" <<ENV
GATE_API_KEY=vm-direct-gate-fixture-key-0123456789abcdef
GATE_UPSTREAM_URL=http://127.0.0.1:18889
ENV
      chmod 0600 "$gate_code/gate.env"
      restorecon -RF "$gate_code"
      gate_exec="/opt/bc250-model-control/.venv/bin/python -I -m uvicorn app.gate:create_gate_app --factory --app-dir $gate_code/backend --host 127.0.0.1 --port 18888 --workers 1 --no-access-log"
      gate_extra="EnvironmentFile=$gate_code/gate.env
NetworkNamespacePath=/run/netns/$namespace"
    else
      gate_exec='/usr/bin/sleep infinity'
      gate_extra=
    fi
    cat > "$gate_file" <<UNIT
[Unit]
ConditionPathExists=!$gate_marker
[Service]
User=ai-gate
Group=ai-gate
NoNewPrivileges=yes
ExecStart=$gate_exec
$gate_extra
Restart=no
KillMode=control-group
UNIT
    chmod 0644 "$gate_file"
    restorecon -F "$gate_file"
    systemctl daemon-reload
    systemctl start "$gate"
  else
    systemd-run --quiet --unit="$gate" --property=Type=exec --property=User=ai-gate \
      --property=Group=ai-gate --property=NoNewPrivileges=yes /usr/bin/sleep infinity
  fi
  systemd-run --quiet --unit="$other" --property=Type=exec --property=User=ai-studio \
    --property=Group=ai-studio --property=NoNewPrivileges=yes /usr/bin/sleep infinity
else
  systemd-run --quiet --unit="$gate" --property=Type=exec /usr/bin/sleep infinity
  systemd-run --quiet --unit="$other" --property=Type=exec /usr/bin/sleep infinity
fi
cat > "$records/fixture_http_server.py" <<'PYSERVER'
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import time
class H(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def do_GET(self):
        if self.path == '/slow':
            (Path(__file__).parent / 'slow-active').touch()
            deadline = time.monotonic() + 90
            while not (Path(__file__).parent / 'slow-release').exists():
                if time.monotonic() >= deadline: raise RuntimeError('시험 요청 대기 시간 초과')
                time.sleep(.1)
        body = b'[{"is_processing":false}]' if self.path == '/slots' else b'ok'
        self.send_response(200)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)
        self.wfile.flush()
    def log_message(self, *args): pass
ThreadingHTTPServer(('127.0.0.1', 18889), H).serve_forever()
PYSERVER
if [[ $mode == listener || $mode == coordinator || $mode == coordinator-allowed || $mode == coordinator-backup || $mode == coordinator-db-backup || $mode == coordinator-retire || $mode == real-gate || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup || $mode == real-gate-restore ]]; then
  systemd-run --quiet --unit="$server_unit" --property=Type=exec /usr/bin/nsenter \
    --net="/run/netns/$namespace" /usr/bin/python3 -u "$records/fixture_http_server.py"
else
  nsenter --net="/run/netns/$namespace" python3 -u "$records/fixture_http_server.py" >"$records/server.log" 2>&1 &
  server_pid=$!
fi
if [[ $mode == coordinator || $mode == coordinator-allowed || $mode == coordinator-backup || $mode == coordinator-db-backup || $mode == coordinator-retire || $mode == real-gate || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup || $mode == real-gate-restore ]]; then
  tools=$(mktemp -d /opt/bc250-direct-idle.XXXXXXXX)
  chmod 0755 "$tools"
  for name in initial-local-idle.py observe-direct-llm.py observe-llama-listener.py backup-archive.sh check-service-cgroup.py legacy-backup-adapter.py legacy-backup-sequence.py inspect-stopped-studio-db.py coordinated-migration.py service-stop-fence-sequence.py stage-protected-db.py migrate-legacy-gate.py; do
    install -o root -g root -m 0644 "$1/deploy/model-control/$name" "$tools/$name"
  done
  restorecon -RF "$tools"
else
  tools=/nonexistent
fi
if [[ $mode == coordinator-allowed || $mode == coordinator-backup || $mode == coordinator-db-backup || $mode == coordinator-retire || $mode == real-gate || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup || $mode == real-gate-restore ]]; then
  systemd-run --quiet --unit="$coordinator_unit" --property=Type=exec --property=User=root \
    --property=Group=root --property=NoNewPrivileges=yes /usr/bin/sleep infinity
fi
if [[ $mode == coordinator-db-backup || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup ]]; then
  cat > "$studio_file" <<UNIT
[Unit]
ConditionPathExists=!$studio_marker
[Service]
ExecStart=/usr/bin/sleep infinity
Restart=no
KillMode=control-group
UNIT
  chmod 0644 "$studio_file"
  restorecon -F "$studio_file"
  systemctl daemon-reload
  systemctl start "$studio_unit"
fi
nsenter --net="/run/netns/$namespace" python3 - "$1/deploy/model-control/direct-llm-nft-fence.py" "$gate" "$other" "$records" "$mode" "$1/backend/app/services/gate_process_identity.py" "$1/deploy/model-control/observe-llama-listener.py" "$server_unit" "$tools" "$coordinator_unit" "$studio_unit" "$studio_marker" "$gate_marker" "$rogue" <<'PY'
import importlib.util
import os
import pwd
import subprocess
import sys
import time
import urllib.error
from pathlib import Path

module_path, gate, other, records = Path(sys.argv[1]), sys.argv[2], sys.argv[3], Path(sys.argv[4])
mode, identity_path, listener_path, server_unit, tools, coordinator_unit = sys.argv[5], Path(sys.argv[6]), Path(sys.argv[7]), sys.argv[8], Path(sys.argv[9]), sys.argv[10]
studio_unit, studio_marker, gate_marker, rogue = sys.argv[11], Path(sys.argv[12]), Path(sys.argv[13]), sys.argv[14]
spec = importlib.util.spec_from_file_location('fixture_fence', module_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
identity = None
if mode in ('identity', 'existing', 'listener', 'coordinator', 'coordinator-allowed', 'coordinator-backup', 'coordinator-db-backup', 'coordinator-retire', 'real-gate', 'real-gate-db-backup', 'real-gate-exclusive-backup', 'real-gate-restore', 'exclusive'):
    identity_spec = importlib.util.spec_from_file_location('fixture_gate_identity', identity_path)
    identity = importlib.util.module_from_spec(identity_spec)
    identity_spec.loader.exec_module(identity)
def group(unit):
    value = subprocess.check_output(['/usr/bin/systemctl', 'show', unit, '-p', 'ControlGroup', '--value'], text=True).strip()
    if value != '/system.slice/' + unit: raise RuntimeError('시험 cgroup 경로 오류')
    return value
client = r'''printf '%s\n' "$$" > "/sys/fs/cgroup$1/cgroup.procs"
if [ "$2" != root ]; then
  exec /usr/bin/setpriv --reuid="$2" --regid="$3" --clear-groups python3 -c 'import urllib.request; r=urllib.request.build_opener(urllib.request.ProxyHandler({})).open("http://127.0.0.1:18889/",timeout=3); assert r.status==200 and r.read()==b"ok"'
fi
exec python3 -c 'import urllib.request; r=urllib.request.build_opener(urllib.request.ProxyHandler({})).open("http://127.0.0.1:18889/",timeout=3); assert r.status==200 and r.read()==b"ok"'
'''
def connect(unit):
    account = pwd.getpwnam('ai-gate' if unit == gate else 'ai-studio') if mode in ('identity', 'existing', 'listener', 'coordinator', 'coordinator-allowed', 'coordinator-backup', 'coordinator-db-backup', 'coordinator-retire', 'real-gate', 'real-gate-db-backup', 'real-gate-exclusive-backup', 'real-gate-restore', 'exclusive') else None
    uid, gid = (str(account.pw_uid), str(account.pw_gid)) if account else ('root', 'root')
    return subprocess.run(['/usr/bin/bash', '-c', client, 'fixture', group(unit), uid, gid],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10).returncode == 0
for _ in range(60):
    if connect(gate): break
    time.sleep(.5)
else: raise RuntimeError('시험 서버 준비 실패')
if not connect(other): raise RuntimeError('차단 전 시험 직접 연결 실패')
listener = None
expected_listener = None
if mode in ('listener', 'coordinator', 'coordinator-allowed', 'coordinator-backup', 'coordinator-db-backup', 'coordinator-retire', 'real-gate', 'real-gate-db-backup', 'real-gate-exclusive-backup', 'real-gate-restore'):
    listener_spec = importlib.util.spec_from_file_location('fixture_listener', listener_path)
    listener = importlib.util.module_from_spec(listener_spec)
    listener_spec.loader.exec_module(listener)
    expected_listener = listener.listener_identity(18889, server_unit, reference_pid=os.getpid())
    if expected_listener[2] == (os.stat('/proc/1/ns/net').st_dev, os.stat('/proc/1/ns/net').st_ino):
        raise RuntimeError('시험 수신 소켓이 격리 네임스페이스에 있지 않습니다.')
    print('시험 서비스의 단일 loopback 수신 주소·포트·주 프로세스 소유 확인', flush=True)
def verify_scope():
    if mode not in ('listener', 'coordinator', 'coordinator-allowed', 'coordinator-backup', 'coordinator-db-backup', 'coordinator-retire', 'real-gate', 'real-gate-db-backup', 'real-gate-exclusive-backup', 'real-gate-restore'): return True
    try:
        return listener.listener_identity(18889, server_unit, reference_pid=os.getpid()) == expected_listener
    except (OSError, ValueError, subprocess.SubprocessError):
        return False
def verify_gate(snapshot, unit=gate):
    if mode not in ('identity', 'existing', 'listener', 'coordinator', 'coordinator-allowed', 'coordinator-backup', 'coordinator-db-backup', 'coordinator-retire', 'real-gate', 'real-gate-db-backup', 'real-gate-exclusive-backup', 'real-gate-restore', 'exclusive'): return True
    try:
        observer = identity.observe_exclusive if mode in ('exclusive', 'real-gate-exclusive-backup') else identity.observe
        result = observer(unit=unit, client_user='vmtest')
    except (OSError, ValueError, KeyError, subprocess.SubprocessError):
        return False
    return (result[0], result[1]) == (snapshot[0], snapshot[1])
def verify_coordinator(snapshot):
    status = Path('/proc') / str(snapshot[0]) / 'status'
    values = {}
    for line in status.read_text().splitlines():
        key, sep, value = line.partition(':')
        if sep and key in ('Uid', 'NoNewPrivs'): values[key] = value.strip()
    cgroup = Path('/sys/fs/cgroup') / snapshot[2].lstrip('/')
    control = (cgroup / 'cgroup.procs').stat()
    return (values.get('Uid', '').split() == ['0', '0', '0', '0']
            and values.get('NoNewPrivs') == '1' and control.st_uid == 0
            and not control.st_mode & 0o022)
def create(unit=gate):
    # Namespace scope, other barriers and unmodified gate behavior are simulated.
    kwargs = {'coordinator_unit': coordinator_unit, 'verify_coordinator': verify_coordinator} if mode in ('coordinator-allowed', 'coordinator-backup', 'coordinator-db-backup', 'coordinator-retire', 'real-gate', 'real-gate-db-backup', 'real-gate-exclusive-backup', 'real-gate-restore') else {}
    return module.DirectLLMNftFence(unit, port=18889, verify_gate=lambda snap: verify_gate(snap, unit),
                                    check_scope=verify_scope, check_barriers=lambda: True, **kwargs)
if mode in ('identity', 'existing', 'listener', 'coordinator', 'coordinator-allowed', 'coordinator-backup', 'coordinator-db-backup', 'coordinator-retire', 'real-gate', 'real-gate-db-backup', 'real-gate-exclusive-backup', 'real-gate-restore', 'exclusive'):
    if not verify_gate(module.unit_snapshot(gate)): raise RuntimeError('실제 시험 gate 계정 검증 실패')
    bad = create(other)
    try: bad.acquire()
    except ValueError: pass
    else: raise RuntimeError('다른 시험 계정을 gate로 허용했습니다.')
    print('서로 다른 시험 UID와 gate 권한 확인 및 다른 계정의 gate 주장 거절 확인', flush=True)
persistent = []
if mode == 'existing':
    import atexit
    client_code = r'''
import http.client, sys
connection = http.client.HTTPConnection('127.0.0.1', 18889, timeout=3)
def request():
    connection.request('GET', '/')
    response = connection.getresponse()
    if response.status != 200 or response.read() != b'ok': raise RuntimeError('unexpected response')
request()
print('ready', flush=True)
for line in sys.stdin:
    if line.strip() == 'stop': break
    try:
        request()
    except (OSError, http.client.HTTPException):
        print('blocked', flush=True)
    else:
        print('allowed', flush=True)
connection.close()
'''
    launch = r'''printf '%s\n' "$$" > "/sys/fs/cgroup$1/cgroup.procs"
exec /usr/bin/setpriv --reuid="$2" --regid="$3" --clear-groups /usr/bin/python3 -u -c "$4"
'''
    def close_clients():
        for process in persistent:
            if process.poll() is None:
                process.terminate()
                try: process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)
    atexit.register(close_clients)
    for unit, username in ((gate, 'ai-gate'), (other, 'ai-studio')):
        account = pwd.getpwnam(username)
        process = subprocess.Popen(['/usr/bin/bash', '-c', launch, 'fixture', group(unit),
            str(account.pw_uid), str(account.pw_gid), client_code],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
        persistent.append(process)
        if process.stdout.readline().strip() != 'ready': raise RuntimeError('기존 시험 HTTP 연결 준비 실패')
    print('규칙 적용 전 시험 gate와 직접 호출자의 HTTP 연결 준비 확인', flush=True)
normal = create()
if not normal.acquire() or not normal.check(): raise RuntimeError('시험 차단 설치 실패')
if not connect(gate) or connect(other): raise RuntimeError('시험 gate 허용 또는 직접 연결 차단 실패')
print('후보가 시험 네임스페이스에 규칙을 설치하고 gate 허용·직접 연결 차단 확인', flush=True)
if mode == 'exclusive':
    subprocess.run(['/usr/bin/systemd-run', '--quiet', '--unit=' + rogue, '--property=Type=exec',
        '--property=User=ai-gate', '--property=Group=ai-gate', '--property=NoNewPrivileges=yes',
        '/usr/bin/sleep', 'infinity'], check=True, timeout=60)
    try:
        try: identity.observe_exclusive(unit=gate, client_user='vmtest')
        except ValueError as error:
            if '다른 프로세스' not in str(error): raise
        else: raise RuntimeError('gate와 같은 UID의 다른 시험 프로세스를 허용했습니다.')
        if normal.check() or normal.phase != 'lost': raise RuntimeError('gate UID 중복을 감지하지 못했습니다.')
        print('다른 시험 프로세스의 gate UID 사용 감지와 직접 호출 차단 상태 상실 확인', flush=True)
    finally:
        subprocess.run(['/usr/bin/systemctl', 'stop', rogue], check=True, timeout=60)
    if not verify_gate(module.unit_snapshot(gate)): raise RuntimeError('시험 UID 중복 제거 후 검사 실패')
    if normal.check(): raise RuntimeError('시험 UID 중복 해소만으로 차단이 자동 재승인됐습니다.')
    try: normal.release(can_release=lambda: True)
    except ValueError: pass
    else: raise RuntimeError('시험 UID 중복 감지 후 자동 해제가 허용됐습니다.')
    subprocess.run(['/usr/sbin/nft', 'delete', 'table', 'inet', normal.table], check=True)
    if not connect(other): raise RuntimeError('시험 규칙 정리 후 연결 복원 실패')
    print('UID 중복 해소만으로 자동 재승인·해제 거절 및 시험 규칙 명시적 정리 확인', flush=True)

if mode in ('coordinator', 'coordinator-allowed', 'coordinator-backup', 'coordinator-db-backup', 'coordinator-retire', 'real-gate', 'real-gate-db-backup', 'real-gate-exclusive-backup', 'real-gate-restore'):
    idle_spec = importlib.util.spec_from_file_location('fixture_idle', tools / 'initial-local-idle.py')
    idle_module = importlib.util.module_from_spec(idle_spec)
    idle_spec.loader.exec_module(idle_module)
    idle = idle_module.InitialLocalIdle(tools, check_wiki=lambda: True, check_other_callers=normal.check,
                                      check_gpu=lambda: True, llama_key=lambda: '')
    idle.observer.LLAMA = server_unit
    idle.observer.SLOTS_URL = 'http://127.0.0.1:18889/slots'
    idle.observer.wiki_stopped = lambda _: None
    actual_listener = idle.listener.listener_identity
    idle.listener.listener_identity = lambda: actual_listener(18889, server_unit, reference_pid=os.getpid())
    if mode == 'coordinator':
        try:
            idle()
        except urllib.error.URLError as error:
            if not isinstance(error.reason, (ConnectionRefusedError, PermissionError, OSError)):
                raise
        except (ConnectionError, TimeoutError):
            pass
        else:
            raise RuntimeError('직접 호출 차단 중 조율기 슬롯 조회가 예상과 달리 성공했습니다.')
        if not normal.check(): raise RuntimeError('슬롯 조회 실패 후 시험 차단 상태가 변경됐습니다.')
        print('직접 호출 차단 중 별도 조율기 프로세스의 실제 슬롯 조회가 차단됨을 확인', flush=True)
        print('현재 차단 규칙만으로는 기존 유휴 검사기를 연결할 수 없음 확인', flush=True)
    else:
        coordinator_group = group(coordinator_unit)
        child = os.fork()
        if child == 0:
            try:
                Path('/sys/fs/cgroup' + coordinator_group + '/cgroup.procs').write_text(str(os.getpid()) + '\n')
                if idle() is not True: raise RuntimeError('시험 조율기 유휴 검사 실패')
                if mode in ('coordinator-backup', 'coordinator-db-backup', 'real-gate-db-backup', 'real-gate-exclusive-backup'):
                    import sqlite3
                    from types import SimpleNamespace
                    def load_fixture(name, file):
                        loaded_spec = importlib.util.spec_from_file_location(name, tools / file)
                        loaded = importlib.util.module_from_spec(loaded_spec)
                        loaded_spec.loader.exec_module(loaded)
                        return loaded
                    backup_module = load_fixture('fixture_backup_adapter', 'legacy-backup-adapter.py')
                    sequence_module = load_fixture('fixture_backup_sequence', 'legacy-backup-sequence.py')
                    db_module = load_fixture('fixture_db_inspector', 'inspect-stopped-studio-db.py')
                    migration = load_fixture('fixture_migration', 'coordinated-migration.py')
                    root = records / 'backup-input'
                    for relative in ('opt/bc250-ai-studio', 'opt/ai-studio-data/database', 'opt/ai/config',
                                     'etc/systemd/system', 'var/lib/bc250-model-control'):
                        (root / relative).mkdir(parents=True, exist_ok=True)
                    for name in ('bc250-ai-studio', 'bc250-llm-gate', 'bc250-llm-client'):
                        (root / 'etc' / (name + '.env')).write_text('fixture\n')
                        (root / 'etc/systemd/system' / (name + '.service')).write_text('fixture\n')
                    (root / 'opt/ai/config/active-model.conf').write_text('fixture\n')
                    (root / 'var/lib/bc250-model-control/legacy-pause.json').write_text('{}\n')
                    db = root / 'opt/ai-studio-data/database/studio.sqlite3'
                    connection = sqlite3.connect(db)
                    connection.execute('CREATE TABLE jobs (status TEXT)')
                    connection.execute('CREATE TABLE system_state (key TEXT, value TEXT)')
                    connection.commit()
                    connection.close()
                    caddy = records / 'backup-fixture-caddy'
                    caddy.write_text('fixture\n')
                    output = records / 'backup-output'
                    backup_module.STUDIO_DATABASE = db
                    adapter = backup_module.LegacyBackupAdapter.__new__(backup_module.LegacyBackupAdapter)
                    adapter.sequence = sequence_module
                    adapter.check_local_idle = idle
                    adapter.check_database_fence = lambda: True  # Replaced with a real single-file fixture in db mode.
                    adapter.llama_connections = SimpleNamespace(check_host_llama=lambda: True)
                    adapter.studio_db = db_module
                    adapter.maintenance = lambda: True
                    state = {'paused': True, 'active_requests': 0, 'waiting_requests': 0}
                    adapter.capture_pause = lambda: state
                    adapter.gate_status = lambda: state
                    if mode in ('real-gate-db-backup', 'real-gate-exclusive-backup'):
                        gate_migration = load_fixture('fixture_gate_migration', 'migrate-legacy-gate.py')
                        gate_migration.URL = 'http://127.0.0.1:18888/control'
                        gate_key = 'vm-direct-gate-fixture-key-0123456789abcdef'
                        gate_snapshot = records / 'legacy-gate-pause.json'
                        def capture_real_gate():
                            result = gate_migration.capture(gate_key, gate_snapshot)
                            import shutil
                            shutil.copy2(gate_snapshot, root / 'var/lib/bc250-model-control/legacy-pause.json')
                            print('실제 시험 gate의 이전 pause 기록과 보류 확인', flush=True)
                            if mode == 'real-gate-exclusive-backup':
                                subprocess.run(['/usr/bin/systemd-run', '--quiet', '--unit=' + rogue,
                                    '--property=Type=exec', '--property=User=ai-gate',
                                    '--property=Group=ai-gate', '--property=NoNewPrivileges=yes',
                                    '/usr/bin/sleep', 'infinity'], check=True, timeout=60)
                                try:
                                    identity.observe_exclusive(unit=gate, client_user='vmtest')
                                except ValueError as error:
                                    if '다른 프로세스' not in str(error): raise
                                else: raise RuntimeError('시험 gate UID 중복이 관찰되지 않았습니다.')
                            return result
                        adapter.capture_pause = capture_real_gate
                        adapter.gate_status = lambda: gate_migration.request(gate_key, 'GET')
                    adapter.stop = lambda: None
                    adapter.require_stopped = lambda: None
                    held_fd = {'fd': None}
                    stage_root = records / 'protected-db-stage'
                    stage_db = stage_root / 'opt/ai-studio-data/database/studio.sqlite3'
                    if mode in ('coordinator-db-backup', 'real-gate-db-backup', 'real-gate-exclusive-backup'):
                        import fcntl
                        import signal
                        signal.signal(signal.SIGIO, lambda *_: None)
                        service_module = load_fixture('fixture_stop_fence', 'service-stop-fence-sequence.py')
                        stage_module = load_fixture('fixture_db_stage', 'stage-protected-db.py')
                        def show(prop):
                            return subprocess.check_output(['/usr/bin/systemctl', 'show', studio_unit,
                                '-p', prop, '--value'], text=True).strip()
                        initial_pid = show('MainPID')
                        if not initial_pid.isdecimal() or int(initial_pid) <= 1:
                            raise RuntimeError('시험 Studio 프로세스 확인 실패')
                        def generation(): return show('ActiveState') == 'active' and show('MainPID') == initial_pid
                        def disable_restart(): return show('Restart') == 'no'
                        def block(): studio_marker.touch(exist_ok=False); return True
                        def policy(): return studio_marker.is_file() and show('Restart') == 'no'
                        def stop_studio():
                            subprocess.run(['/usr/bin/systemctl', 'stop', studio_unit], check=True, timeout=60)
                            return True
                        def stopped():
                            subprocess.run(['/usr/bin/bash', '-c', 'source "$1"; shift; bc250_require_stopped "$@"',
                                'fixture', str(tools / 'backup-archive.sh'), studio_unit], check=True, timeout=60,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                            return True
                        service_fence = service_module.ServiceStopFence(record=lambda _: None,
                            generation_current=generation, disable_restart=disable_restart,
                            install_start_block=block, check_policy=policy,
                            stop_services=stop_studio, check_stopped=stopped)
                        def check_db_fence():
                            fd = held_fd['fd']
                            if fd is None or service_fence.check() is not True: return False
                            opened, current = os.fstat(fd), db.stat()
                            return (fcntl.fcntl(fd, fcntl.F_GETLEASE) == fcntl.F_WRLCK
                                    and (opened.st_dev, opened.st_ino) == (current.st_dev, current.st_ino))
                        def gate_stopped():
                            if not gate_marker.is_file(): return False
                            result = subprocess.run(['/usr/bin/bash', '-c',
                                'source "$1"; shift; bc250_require_stopped "$@"', 'fixture',
                                str(tools / 'backup-archive.sh'), gate], check=False, timeout=60,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                            return result.returncode == 0
                        def stop_and_stage():
                            if mode in ('real-gate-db-backup', 'real-gate-exclusive-backup'):
                                def check_drained():
                                    result = gate_migration.request(gate_key, 'GET')
                                    return (result['paused'] is True and result['active_requests'] == 0
                                            and result['waiting_requests'] == 0)
                                def stop_gate():
                                    gate_marker.touch(exist_ok=False)
                                    subprocess.run(['/usr/bin/systemctl', 'stop', gate], check=True, timeout=60)
                                    return True
                                if not normal.retire_gate(check_drained=check_drained, stop_gate=stop_gate,
                                                          check_stopped=gate_stopped):
                                    raise RuntimeError('실제 시험 gate 정지 인계 실패')
                                print('실제 시험 gate drain·정지 및 직접 호출 차단 유지 확인', flush=True)
                            if service_fence.prepare() is not True: raise RuntimeError('시험 서비스 차단 실패')
                            if any(Path(str(db) + suffix).exists() for suffix in ('-wal', '-shm', '-journal')):
                                raise RuntimeError('시험 DB 부수 파일이 남아 있습니다.')
                            held_fd['fd'] = os.open(db, os.O_RDWR | os.O_NOFOLLOW | os.O_CLOEXEC)
                            fcntl.fcntl(held_fd['fd'], fcntl.F_SETLEASE, fcntl.F_WRLCK)
                            stage_db.parent.mkdir(mode=0o700, parents=True)
                            stage_module.stage_file(held_fd['fd'], stage_db.parent, stage_db.name,
                                                    check_fence=check_db_fence)
                            return True
                        def require_stopped():
                            if service_fence.check() is not True: raise RuntimeError('시험 Studio 차단 상실')
                            if mode in ('real-gate-db-backup', 'real-gate-exclusive-backup') and not gate_stopped():
                                raise RuntimeError('시험 gate 정지 또는 시작 차단 상실')
                        adapter.check_database_fence = check_db_fence
                        adapter.stop = stop_and_stage
                        adapter.require_stopped = require_stopped
                        backup_module.STUDIO_DATABASE = stage_db
                    def make_backup():
                        if idle() is not True: raise RuntimeError('시험 백업 전 유휴 검사 실패')
                        output.mkdir(mode=0o700)
                        if mode in ('coordinator-db-backup', 'real-gate-db-backup', 'real-gate-exclusive-backup'):
                            command = r'''
fixture_fd=$5
fixture_db=$6
fixture_marker=$8
fixture_unit=$9
bc250_check_db_fence() {
  /usr/bin/python3 -c 'import fcntl,os,sys; fd=int(sys.argv[1]); a=os.fstat(fd); b=os.stat(sys.argv[2], follow_symlinks=False); sys.exit(0 if fcntl.fcntl(fd,fcntl.F_GETLEASE)==fcntl.F_WRLCK and (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino) else 1)' "$fixture_fd" "$fixture_db" || return 1
  [ -f "$fixture_marker" ] || return 1
  [ "$(/usr/bin/systemctl show "$fixture_unit" -p ActiveState --value)" = inactive ] || return 1
  [ "$(/usr/bin/systemctl show "$fixture_unit" -p MainPID --value)" = 0 ] || return 1
}
source "$1"
bc250_backup_archive "$2" "$3" "$4" "$7"
'''
                            subprocess.run(['/usr/bin/bash', '-c', command, 'fixture',
                                str(tools / 'backup-archive.sh'), str(root), str(output), str(caddy),
                                str(held_fd['fd']), str(db), str(stage_root), str(studio_marker), studio_unit],
                                pass_fds=(held_fd['fd'],), check=True, timeout=120)
                            if check_db_fence() is not True: raise RuntimeError('시험 DB 차단 상실')
                        else:
                            subprocess.run(['/usr/bin/bash', '-c',
                                'source "$1"; bc250_backup_archive "$2" "$3" "$4"', 'fixture',
                                str(tools / 'backup-archive.sh'), str(root), str(output), str(caddy)],
                                check=True, timeout=120)
                        if idle() is not True: raise RuntimeError('시험 백업 후 유휴 검사 실패')
                        return output
                    def verify_backup(path):
                        subprocess.run(['/usr/bin/sha256sum', '-c', 'SHA256SUMS'], cwd=path,
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True, timeout=30)
                        if mode in ('coordinator-db-backup', 'real-gate-db-backup', 'real-gate-exclusive-backup'):
                            import tarfile
                            with tarfile.open(path / 'legacy.tar', 'r') as archive:
                                member = archive.extractfile('opt/ai-studio-data/database/studio.sqlite3')
                                if member is None or member.read() != stage_db.read_bytes():
                                    raise RuntimeError('시험 아카이브 DB 복사본 불일치')
                                if mode in ('real-gate-db-backup', 'real-gate-exclusive-backup'):
                                    import json
                                    paused_record = archive.extractfile('var/lib/bc250-model-control/legacy-pause.json')
                                    if paused_record is None or json.load(paused_record) != gate_migration.read_snapshot(gate_snapshot):
                                        raise RuntimeError('시험 아카이브의 기존 gate 보류 기록 불일치')
                                    print('시험 아카이브에 실제 이전 gate pause 기록 포함 확인', flush=True)
                            if check_db_fence() is not True: raise RuntimeError('시험 DB 검증 중 차단 상실')
                    adapter.create_backup = make_backup
                    adapter.verify_backup = verify_backup
                    class Record:
                        def __init__(self): self.events = []
                        def __call__(self, event): self.events.append(event)
                        def backup(self, path): self.events.append('backup-path')
                    record = Record()
                    runner = migration.CoordinatedMigration(record=record, preflight=lambda: True,
                        transition=lambda **_: None, transition_args={}, backup_adapter=adapter,
                        install=lambda _: True, startup=SimpleNamespace(start=lambda: None, finish=lambda: None),
                        verify_new=lambda: True, verify_restored=lambda: True)
                    if mode == 'real-gate-exclusive-backup':
                        try:
                            try:
                                runner.prepare_and_start()
                            except Exception:
                                if normal.phase not in ('lost', 'failed'):
                                    raise RuntimeError('차단 상실 이외의 원인으로 시험이 중단됐습니다.')
                            else:
                                raise RuntimeError('gate UID 중복에도 시험 백업이 진행됐습니다.')
                        finally:
                            subprocess.run(['/usr/bin/systemctl', 'stop', rogue], check=True, timeout=60)
                        if gate_marker.exists() or studio_marker.exists() or output.exists() or held_fd['fd'] is not None or stage_root.exists():
                            raise RuntimeError('중복 감지 전에 정지 또는 백업 단계가 실행됐습니다.')
                        for unit in (gate, studio_unit):
                            state_now = subprocess.check_output(['/usr/bin/systemctl', 'is-active', unit], text=True).strip()
                            if state_now != 'active': raise RuntimeError('시험 서비스가 정지됐습니다: ' + unit)
                        if gate_migration.request(gate_key, 'GET')['paused'] is not True:
                            raise RuntimeError('시험 gate 보류가 해제됐습니다.')
                        if normal.check(): raise RuntimeError('UID 중복 제거 후 차단이 자동 재승인됐습니다.')
                        print('실제 시험 gate 보류 후 UID 중복 시 서비스 정지·DB 백업 전 중단 확인', flush=True)
                        print('UID 중복 해소 후에도 같은 차단 객체의 자동 재승인 거절 확인', flush=True)
                    else:
                        runner.prepare_and_start()
                        if runner.phase != 'await_client' or not (output / 'legacy.tar').is_file():
                            raise RuntimeError('직접 호출 차단과 시험 백업 조율 연결 실패')
                        if not normal.check(): raise RuntimeError('시험 백업 후 직접 호출 차단 상실')
                        if mode in ('coordinator-db-backup', 'real-gate-db-backup', 'real-gate-exclusive-backup'):
                            print('시험 직접 호출 차단·실제 서비스 정지·단일 DB 보호 복사본과 아카이브 조율 연결 확인', flush=True)
                        else:
                            print('실제 시험 직접 호출 차단·슬롯 확인과 시험 SQLite 검사·아카이브 조율 연결 확인', flush=True)
                        # Deliberate rule change inside the isolated namespace; retain archive and reject next inspection.
                        subprocess.run(['/usr/sbin/nft', 'add', 'rule', 'inet', normal.table, 'output', 'counter'], check=True)
                        try:
                            adapter.require_stopped_with_clear_database()
                        except Exception:
                            pass
                        else:
                            raise RuntimeError('규칙 변경 후 시험 DB 검사가 허용됐습니다.')
                        if normal.phase != 'lost': raise RuntimeError('직접 호출 차단 상실이 기록되지 않았습니다.')
                        print('시험 직접 호출 규칙 변경 시 다음 DB 검사 전 중단과 기존 아카이브 보존 확인', flush=True)
                        if held_fd['fd'] is not None:
                            os.close(held_fd['fd'])
                            held_fd['fd'] = None
            except Exception as error:
                print('시험 조율기 슬롯 조회 실패:', type(error).__name__, str(error), flush=True)
                os._exit(1)
            os._exit(0)
        _, status = os.waitpid(child, 0)
        if not os.WIFEXITED(status) or os.WEXITSTATUS(status) != 0:
            raise RuntimeError('시험 조율기 cgroup의 슬롯 유휴 검사 실패')
        if mode == 'real-gate-exclusive-backup':
            # The child has its own in-memory fence; cleanup is explicit, not a parent reapproval.
            subprocess.run(['/usr/sbin/nft', 'delete', 'table', 'inet', normal.table], check=True)
            if not connect(other): raise RuntimeError('시험 규칙 정리 후 직접 연결 복원 실패')
            print('보존된 시험 규칙을 명시적으로 정리하고 직접 연결 복원 확인', flush=True)
        elif mode in ('coordinator-backup', 'coordinator-db-backup', 'real-gate-db-backup'):
            if normal.check() or normal.phase != 'lost': raise RuntimeError('시험 규칙 변경 후 차단 상실 미감지')
            try: normal.release(can_release=lambda: True)
            except ValueError: pass
            else: raise RuntimeError('시험 차단 상실 후 자동 해제가 허용됐습니다.')
            subprocess.run(['/usr/sbin/nft', 'delete', 'table', 'inet', normal.table], check=True)
            if not connect(other): raise RuntimeError('시험 규칙 정리 후 직접 연결 복원 실패')
        else:
            if not normal.check() or connect(other): raise RuntimeError('조율기 허용 후 직접 호출 차단 실패')
            print('검증된 시험 조율기의 실제 슬롯 유휴 검사와 다른 직접 호출 차단 확인', flush=True)

if mode == 'existing':
    results = []
    for process in persistent:
        process.stdin.write('request\n')
        process.stdin.flush()
        result = process.stdout.readline().strip()
        if result not in ('allowed', 'blocked'): raise RuntimeError('기존 시험 연결 결과 확인 실패')
        results.append(result)
    if results[0] != 'allowed': raise RuntimeError('기존 시험 gate 연결이 차단됐습니다.')
    print('규칙 적용 전 gate 연결의 후속 요청: 허용', flush=True)
    print('규칙 적용 전 직접 호출 연결의 후속 요청:', '허용' if results[1] == 'allowed' else '차단', flush=True)
    (records / 'existing-connections-result').write_text('gate=' + results[0] + '\ndirect=' + results[1] + '\n')
    close_clients()

if mode not in ('coordinator-backup', 'coordinator-db-backup', 'real-gate-db-backup', 'real-gate-exclusive-backup', 'exclusive'):
    if not normal.release(can_release=lambda: True) or not connect(other):
        raise RuntimeError('시험 규칙 해제 또는 접근 복원 실패')
    print('정상 해제 후 시험 직접 연결 복원 확인', flush=True)
elif mode in ('coordinator-backup', 'coordinator-db-backup', 'real-gate-db-backup'):
    print('변경된 시험 규칙을 명시적으로 정리한 뒤 직접 연결 복원 확인', flush=True)
if mode not in ('real-gate-db-backup', 'real-gate-exclusive-backup'):
    tampered = create()
    if not tampered.acquire() or not tampered.check(): raise RuntimeError('두 번째 시험 차단 설치 실패')
    subprocess.run(['/usr/sbin/nft', 'add', 'rule', 'inet', tampered.table, 'output', 'counter'], check=True)
    if tampered.check() or tampered.phase != 'lost': raise RuntimeError('시험 규칙 변경을 감지하지 못했습니다.')
    try: tampered.release(can_release=lambda: True)
    except ValueError: pass
    else: raise RuntimeError('규칙 변경 후 자동 해제가 허용됐습니다.')
    print('시험 규칙 변경 감지 후 자동 재승인·해제 거절 확인', flush=True)
    (records / 'table-name').write_text(tampered.table + '\n')
    # Explicit fixture-only cleanup: never delete a production table.
    subprocess.run(['/usr/sbin/nft', 'delete', 'table', 'inet', tampered.table], check=True)
    if mode in ('coordinator-allowed', 'coordinator-backup', 'coordinator-db-backup', 'coordinator-retire', 'real-gate', 'real-gate-db-backup', 'real-gate-exclusive-backup', 'real-gate-restore'):
        coordinator_changed = create()
        if not coordinator_changed.acquire() or not coordinator_changed.check():
            raise RuntimeError('시험 조율기 세대 검사 준비 실패')
        subprocess.run(['/usr/bin/systemctl', 'restart', coordinator_unit], check=True, timeout=60)
        if coordinator_changed.check() or coordinator_changed.phase != 'lost':
            raise RuntimeError('시험 조율기 재시작을 감지하지 못했습니다.')
        print('시험 조율기 재시작 시 기존 차단 검사 실패 확인', flush=True)
        subprocess.run(['/usr/sbin/nft', 'delete', 'table', 'inet', coordinator_changed.table], check=True)
    if mode in ('coordinator-retire', 'real-gate', 'real-gate-db-backup', 'real-gate-exclusive-backup', 'real-gate-restore'):
        check_drained = lambda: True
        if mode in ('real-gate', 'real-gate-restore'):
            import json
            import urllib.request
            gate_base = 'http://127.0.0.1:18888'
            admin_key = 'vm-direct-gate-fixture-key-0123456789abcdef'
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            def gate_request(method, payload=None):
                headers = {'Authorization': 'Bearer ' + admin_key}
                body = None
                if payload is not None:
                    headers['Content-Type'] = 'application/json'
                    body = json.dumps(payload).encode()
                request = urllib.request.Request(gate_base + '/control', data=body, headers=headers, method=method)
                with opener.open(request, timeout=5) as response: return json.load(response)
            for _ in range(90):
                try:
                    current = gate_request('GET')
                    break
                except urllib.error.URLError:
                    time.sleep(.5)
            else: raise RuntimeError('실제 시험 gate 준비 시간 초과')
            if current['paused'] or current['active_requests'] or current['waiting_requests']:
                raise RuntimeError('시험 gate 초기 상태가 비어 있지 않습니다.')
            slow_code = "import urllib.request; r=urllib.request.build_opener(urllib.request.ProxyHandler({})).open('http://127.0.0.1:18888/slow',timeout=60); assert r.status==200 and r.read()==b'ok'"
            slow = subprocess.Popen(['/usr/bin/python3', '-c', slow_code], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            waiting = None
            try:
                for _ in range(120):
                    if (records / 'slow-active').exists(): break
                    if slow.poll() is not None: raise RuntimeError('시험 진행 중 요청이 조기 종료됐습니다.')
                    time.sleep(.25)
                else: raise RuntimeError('시험 진행 중 요청 준비 시간 초과')
                if mode == 'real-gate-restore':
                    migration_spec = importlib.util.spec_from_file_location('fixture_gate_migration', tools / 'migrate-legacy-gate.py')
                    gate_migration = importlib.util.module_from_spec(migration_spec)
                    migration_spec.loader.exec_module(gate_migration)
                    gate_migration.URL = gate_base + '/control'
                    saved_pause = records / 'restore-original-pause.json'
                    paused = gate_migration.capture(admin_key, saved_pause)
                    if gate_migration.read_snapshot(saved_pause)['paused_before_maintenance'] is not False:
                        raise RuntimeError('시험 gate의 이전 pause 기록 오류')
                else:
                    paused = gate_request('PUT', {'paused': True})
                if not paused['paused'] or paused['active_requests'] != 1:
                    raise RuntimeError('실제 시험 gate의 진행 요청·보류 상태 불일치')
                waiting_code = slow_code.replace('/slow', '/')
                waiting = subprocess.Popen(['/usr/bin/python3', '-c', waiting_code],
                                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                for _ in range(120):
                    state = gate_request('GET')
                    if state['waiting_requests'] == 1: break
                    if waiting.poll() is not None: raise RuntimeError('보류 중 시험 신규 요청이 대기하지 않았습니다.')
                    time.sleep(.25)
                else: raise RuntimeError('시험 신규 요청 대기 확인 시간 초과')
                print('실제 시험 gate 보류 중 신규 요청 대기 확인', flush=True)
                def check_drained():
                    state = gate_request('GET')
                    return (state.get('paused') is True and state.get('active_requests') == 0
                            and state.get('waiting_requests') == 0)
                busy = create()
                if not busy.acquire(): raise RuntimeError('진행 요청 중 시험 차단 준비 실패')
                stopped_calls = []
                try:
                    busy.retire_gate(check_drained=check_drained,
                                     stop_gate=lambda: stopped_calls.append(True), check_stopped=lambda: False)
                except ValueError:
                    pass
                else: raise RuntimeError('진행 중 요청이 있는데 gate 정지가 허용됐습니다.')
                if stopped_calls or busy.phase != 'failed' or gate_marker.exists():
                    raise RuntimeError('진행 중 요청 거절 후 시험 gate 상태 오류')
                print('실제 시험 gate의 진행 중 요청이 있으면 정지 인계 거절 확인', flush=True)
                subprocess.run(['/usr/sbin/nft', 'delete', 'table', 'inet', busy.table], check=True)
                (records / 'slow-release').touch()
                if slow.wait(timeout=30) != 0: raise RuntimeError('시험 진행 중 요청 완료 실패')
                state = gate_request('GET')
                if state['waiting_requests'] != 1 or check_drained():
                    raise RuntimeError('대기 요청이 남은 시험 gate를 drain 완료로 판단했습니다.')
                print('진행 요청 종료 후에도 대기 요청이 남으면 drain 거절 확인', flush=True)
                gate_request('PUT', {'paused': False})
                if waiting.wait(timeout=30) != 0: raise RuntimeError('시험 대기 요청 처리 실패')
                gate_request('PUT', {'paused': True})
                for _ in range(120):
                    if check_drained(): break
                    time.sleep(.25)
                else: raise RuntimeError('실제 시험 gate drain 대기 시간 초과')
                print('시험 대기 요청 처리와 재보류 후 진행·대기 요청 비움 확인', flush=True)
            finally:
                if slow.poll() is None:
                    slow.kill()
                    slow.wait(timeout=15)
                if waiting is not None and waiting.poll() is None:
                    waiting.kill()
                    waiting.wait(timeout=15)
        retiring = create()
        if not retiring.acquire() or not retiring.check(): raise RuntimeError('시험 gate 정지 인계 준비 실패')
        def stop_gate():
            gate_marker.touch(exist_ok=False)
            subprocess.run(['/usr/bin/systemctl', 'stop', gate], check=True, timeout=60)
            return True
        def gate_stopped():
            if not gate_marker.is_file(): return False
            result = subprocess.run(['/usr/bin/bash', '-c', 'source "$1"; shift; bc250_require_stopped "$@"',
                'fixture', str(tools / 'backup-archive.sh'), gate], check=False, timeout=60,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return result.returncode == 0
        if not retiring.retire_gate(check_drained=check_drained, stop_gate=stop_gate, check_stopped=gate_stopped):
            raise RuntimeError('시험 gate 정지 인계 실패')
        subprocess.run(['/usr/bin/systemctl', 'start', gate], check=False, timeout=60)
        if not gate_stopped() or not retiring.check() or connect(other):
            raise RuntimeError('시험 gate 재시작 차단 또는 직접 호출 차단 실패')
        idle.callers = retiring.check
        child = os.fork()
        if child == 0:
            try:
                Path('/sys/fs/cgroup' + group(coordinator_unit) + '/cgroup.procs').write_text(str(os.getpid()) + '\n')
                if idle() is not True: raise RuntimeError('gate 정지 후 시험 슬롯 확인 실패')
            except Exception as error:
                print('gate 정지 후 시험 슬롯 확인 실패:', type(error).__name__, str(error), flush=True)
                os._exit(1)
            os._exit(0)
        _, status = os.waitpid(child, 0)
        if not os.WIFEXITED(status) or os.WEXITSTATUS(status) != 0:
            raise RuntimeError('gate 정지 후 시험 조율기 슬롯 확인 실패')
        if mode == 'real-gate-restore':
            def start_gate_held():
                gate_marker.unlink()
                subprocess.run(['/usr/bin/systemctl', 'start', gate], check=True, timeout=60)
                for _ in range(90):
                    try:
                        gate_request('GET')
                        gate_request('PUT', {'paused': True})
                        return True
                    except urllib.error.URLError:
                        time.sleep(.5)
                return False
            def gate_held():
                value = gate_request('GET')
                return value['paused'] is True and value['active_requests'] == 0 and value['waiting_requests'] == 0
            if not retiring.restore_gate(start_gate=start_gate_held, check_held=gate_held):
                raise RuntimeError('실제 시험 gate 보류 상태 복원 인계 실패')
            if not gate_held() or not retiring.check() or connect(other):
                raise RuntimeError('시험 gate 복원 후 보류 또는 직접 호출 차단 오류')
            print('실제 시험 gate 재시작·보류 확인 후 새 gate 허용 및 직접 호출 차단 유지 확인', flush=True)
            if gate_migration.restore_pause(admin_key, saved_pause)['paused'] is not False:
                raise RuntimeError('시험 gate의 이전 pause 복원 실패')
            if not retiring.check() or connect(other):
                raise RuntimeError('시험 이전 pause 복원 중 직접 호출 차단 상실')
            print('직접 호출 차단 유지 중 시험 gate의 이전 pause 상태 복원 확인', flush=True)
        if not retiring.release(can_release=lambda: True): raise RuntimeError('시험 차단 해제 실패')
        print('시험 gate 정지·재시작 차단 중 직접 호출 차단과 조율기 슬롯 조회 유지 확인', flush=True)
        if mode == 'coordinator-retire':
            print('gate drain은 모의이며 시험 gate는 실제 HTTP gate가 아닙니다.', flush=True)
        else:
            print('실제 시험 HTTP gate의 drain 결과로 gate 정지 인계 확인', flush=True)
    if mode in ('listener', 'coordinator', 'coordinator-allowed', 'coordinator-backup', 'coordinator-db-backup'):
        linked = create()
        if not linked.acquire() or not linked.check(): raise RuntimeError('수신 소켓 연계 차단 설치 실패')
        subprocess.run(['/usr/bin/systemctl', 'stop', server_unit], check=True, timeout=60)
        if linked.check() or linked.phase != 'lost': raise RuntimeError('시험 수신 서비스 종료가 감지되지 않았습니다.')
        try: linked.release(can_release=lambda: True)
        except ValueError: pass
        else: raise RuntimeError('수신 소켓 상실 후 자동 해제가 허용됐습니다.')
        print('시험 수신 서비스 종료 시 차단 검사 실패 및 자동 해제 거절 확인', flush=True)
        subprocess.run(['/usr/sbin/nft', 'delete', 'table', 'inet', linked.table], check=True)
print('시험 gate·수신·단일 DB 차단은 해당 시험 모드에서만 확인했습니다. 다른 네임스페이스·GPU·전체 DB 접근 주체는 모의 또는 범위 밖입니다.', flush=True)
PY
if [[ -n $server_pid ]]; then
  kill "$server_pid"
  wait "$server_pid" 2>/dev/null || true
  server_pid=
fi
if [[ ( $mode == listener || $mode == coordinator || $mode == coordinator-allowed || $mode == coordinator-backup || $mode == coordinator-db-backup || $mode == coordinator-retire || $mode == real-gate || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup || $mode == real-gate-restore ) && $(systemctl show "$server_unit" -p LoadState --value) != not-found ]]; then
  systemctl stop "$server_unit"
fi
systemctl stop "$gate" "$other"
if [[ ( $mode == coordinator-allowed || $mode == coordinator-backup || $mode == coordinator-db-backup || $mode == coordinator-retire || $mode == real-gate || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup || $mode == real-gate-restore ) && $(systemctl show "$coordinator_unit" -p LoadState --value) != not-found ]]; then
  systemctl stop "$coordinator_unit"
fi
ip netns del "$namespace"
if [[ $mode == coordinator-retire || $mode == real-gate || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup || $mode == real-gate-restore ]]; then
  rm -- "$gate_file"
  systemctl daemon-reload
fi
if [[ $mode == coordinator-db-backup || $mode == real-gate-db-backup || $mode == real-gate-exclusive-backup ]]; then
  systemctl stop "$studio_unit"
  rm -- "$studio_file"
  systemctl daemon-reload
fi
trap - ERR
echo "시험 서비스와 네임스페이스 정리 완료; 기록 보관: $records"
