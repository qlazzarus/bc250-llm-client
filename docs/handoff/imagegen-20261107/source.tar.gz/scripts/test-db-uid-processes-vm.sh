#!/usr/bin/env bash
# Disposable VM: inspect a snapshot of processes belonging to one test UID.
set -Eeuo pipefail
umask 077
[[ $(id -u) == 0 && $(hostname) == bc250-fedora43-test && $(systemd-detect-virt) == qemu && $(getenforce) == Enforcing && $# == 1 ]] || exit 1
module=$1/deploy/model-control/observe-db-process-references.py
[[ -f $module ]] || exit 1
uid=61037
gid=61037
! getent passwd "$uid" >/dev/null
! getent group "$gid" >/dev/null
python3 - "$module" "$uid" <<'PY'
import importlib.util
import sys
spec = importlib.util.spec_from_file_location('references', sys.argv[1])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
if module.selected_uid_pids(int(sys.argv[2])):
    raise SystemExit('시험 UID를 사용하는 프로세스가 이미 있습니다.')
PY
records=$(mktemp -d /var/backups/bc250-db-uid.XXXXXXXX)
data=$(mktemp -d /var/lib/bc250-db-uid.XXXXXXXX)
control=$(mktemp -d /var/lib/bc250-db-uid-control.XXXXXXXX)
code=$(mktemp -d /opt/bc250-db-uid.XXXXXXXX)
suffix=${records##*.}
[[ $suffix =~ ^[A-Za-z0-9]{8}$ ]] || exit 1
holder=bc250-db-uid-holder-$suffix.service
other=bc250-db-uid-other-$suffix.service
third=bc250-db-uid-third-$suffix.service
for unit in "$holder" "$other" "$third"; do
  [[ $(systemctl show "$unit" -p LoadState --value) == not-found ]] || exit 1
done
failure() {
  systemctl stop "$holder" "$other" "$third" >/dev/null 2>&1 || true
  echo "시험 중단. 시험 자료 보관: $records $data $control $code" >&2
}
trap failure ERR
chmod 0755 "$code"
chown "$uid:$gid" "$data" "$control"
chmod 0700 "$data" "$control"
python3 - "$data/fixture.sqlite3" <<'PY'
import sqlite3
import sys
connection = sqlite3.connect(sys.argv[1])
connection.execute('CREATE TABLE fixture (value TEXT NOT NULL)')
connection.commit()
connection.close()
PY
chown "$uid:$gid" "$data/fixture.sqlite3"
chmod 0600 "$data/fixture.sqlite3"
cat > "$code/worker.py" <<'PY'
import os
import sys
import time
from pathlib import Path

data, control, role, uid, gid = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], int(sys.argv[4]), int(sys.argv[5])
os.setgroups([])
os.setgid(gid)
os.setuid(uid)
assert os.getuid() == uid and os.geteuid() == uid
fd = os.open(data, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC) if role == 'holder' else None
(control / (role + '-ready')).write_text('ready\n')
deadline = time.monotonic() + 300
while time.monotonic() < deadline:
    if fd is not None and (control / 'close').exists():
        os.close(fd)
        fd = None
        (control / 'closed').write_text('closed\n')
    time.sleep(.1)
raise SystemExit('시험 시간 초과')
PY
chmod 0644 "$code/worker.py"
restorecon -RF "$data" "$control" "$code" "$records"
for role in holder other; do
  unit=bc250-db-uid-$role-$suffix.service
  systemd-run --quiet --unit="$unit" --property=Type=exec --property=KillMode=control-group \
    /usr/bin/python3 -u "$code/worker.py" "$data" "$control" "$role" "$uid" "$gid"
done
python3 - "$module" "$data" "$control" "$code" "$uid" "$gid" "$holder" "$other" "$third" <<'PY'
import importlib.util
import subprocess
import sys
import time
from pathlib import Path

module_path, data, control, code = map(Path, sys.argv[1:5])
uid, gid = map(int, sys.argv[5:7])
holder, other, third = sys.argv[7:10]
spec = importlib.util.spec_from_file_location('references', module_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
def wait_file(path):
    for _ in range(120):
        if path.exists(): return
        time.sleep(.5)
    raise SystemExit('시험 프로세스 준비 시간 초과: ' + str(path))
def main_pid(unit):
    pid = int(subprocess.check_output(['systemctl', 'show', unit, '-p', 'MainPID', '--value'], text=True).strip())
    if pid <= 1: raise SystemExit('시험 프로세스 PID 확인 실패')
    return pid
for role in ('holder', 'other'): wait_file(control / (role + '-ready'))
hp, op = main_pid(holder), main_pid(other)
if hp == op: raise SystemExit('시험 프로세스가 구분되지 않습니다.')
result = module.observe_uid_processes(uid, data, data / 'fixture.sqlite3')
if set(result) != {hp, op} or 'fd' not in result[hp] or result[op]:
    raise SystemExit('시험 UID 프로세스 및 DB 참조 관찰 실패: ' + repr(result))
print('시험 UID의 두 프로세스 열거와 한 프로세스의 DB 디렉터리 FD 감지 확인', flush=True)
(control / 'close').touch()
wait_file(control / 'closed')
result = module.observe_uid_processes(uid, data, data / 'fixture.sqlite3')
if set(result) != {hp, op} or any(result.values()):
    raise SystemExit('시험 FD 종료 후 참조 확인 실패: ' + repr(result))
print('시험 FD 종료 후 동일 UID 프로세스의 참조 없음 확인', flush=True)
subprocess.run(['systemd-run', '--quiet', '--unit=' + third, '--property=Type=exec', '--property=KillMode=control-group', '/usr/bin/python3', '-u', str(code / 'worker.py'), str(data), str(control), 'third', str(uid), str(gid)], check=True)
wait_file(control / 'third-ready')
tp = main_pid(third)
result = module.observe_uid_processes(uid, data, data / 'fixture.sqlite3')
if set(result) != {hp, op, tp} or any(result.values()):
    raise SystemExit('새 시험 프로세스 재관찰 실패: ' + repr(result))
print('새 시험 프로세스는 다음 관찰에서 확인', flush=True)
PY
systemctl stop "$holder" "$other" "$third"
trap - ERR
echo "시험 서비스 정리 완료; 시험 자료 보관: $records $data $control $code"
echo '운영 DB·서비스는 변경하지 않았습니다. 단일 UID의 프로세스 대표에 대한 순간 관찰이며 다른 UID·스레드·새 참조 생성이나 지속 차단은 확인하지 않습니다.'
