#!/usr/bin/env bash
# Disposable VM: a single-UID snapshot cannot cover another UID.
set -Eeuo pipefail
umask 077
[[ $(id -u) == 0 && $(hostname) == bc250-fedora43-test && $(systemd-detect-virt) == qemu && $(getenforce) == Enforcing && ( $# == 1 || ( $# == 2 && ( $2 == both || $2 == adapter || $2 == adapter-reopen || $2 == snapshot-gap ) ) ) ]] || exit 1
mode=${2:-ordinary}
module=$1/deploy/model-control/observe-db-process-references.py
[[ -f $module ]] || exit 1
for uid in 61037 61038; do
  ! getent passwd "$uid" >/dev/null
  ! getent group "$uid" >/dev/null
done
python3 - "$module" <<'PY'
import importlib.util
import sys
spec = importlib.util.spec_from_file_location('references', sys.argv[1])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
for uid in (61037, 61038):
    if module.selected_uid_pids(uid): raise SystemExit('시험 UID의 기존 프로세스가 있습니다.')
PY
records=$(mktemp -d /var/backups/bc250-db-otheruid.XXXXXXXX)
data=$(mktemp -d /var/lib/bc250-db-otheruid.XXXXXXXX)
control=$(mktemp -d /var/lib/bc250-db-otheruid-control.XXXXXXXX)
code=$(mktemp -d /opt/bc250-db-otheruid.XXXXXXXX)
suffix=${records##*.}
[[ $suffix =~ ^[A-Za-z0-9]{8}$ ]] || exit 1
first=bc250-db-uid-a-$suffix.service
second=bc250-db-uid-b-$suffix.service
for unit in "$first" "$second"; do
  [[ $(systemctl show "$unit" -p LoadState --value) == not-found ]] || exit 1
done
failure() {
  systemctl stop "$first" "$second" >/dev/null 2>&1 || true
  echo "시험 중단. 시험 자료 보관: $records $data $control $code" >&2
}
trap failure ERR
chmod 0755 "$code" "$data"
chmod 0777 "$control"
python3 - "$data/fixture.sqlite3" <<'PY'
import sqlite3
import sys
with sqlite3.connect(sys.argv[1]) as connection:
    connection.execute('CREATE TABLE fixture (value TEXT)')
    connection.execute('CREATE TABLE jobs (status TEXT)')
    connection.execute('CREATE TABLE system_state (key TEXT, value TEXT)')
PY
chmod 0644 "$data/fixture.sqlite3"
if [[ $mode == snapshot-gap ]]; then chmod 0777 "$data"; chmod 0666 "$data/fixture.sqlite3"; fi
cat > "$code/worker.py" <<'PY'
import os
import sqlite3
import sys
import time
from pathlib import Path

data, control, role, uid = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], int(sys.argv[4])
os.setgroups([])
os.setgid(uid)
os.setuid(uid)
fd = os.open(data, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC) if role == 'b' else None
reopened = False
transient_done = False
(control / (role + '-ready')).write_text('ready')
deadline = time.monotonic() + 240
while time.monotonic() < deadline:
    if fd is not None and not reopened and (control / 'close').exists():
        os.close(fd)
        fd = None
        (control / 'closed').write_text('closed')
    if role == 'b' and fd is None and not reopened and (control / 'reopen').exists():
        fd = os.open(data, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
        reopened = True
        (control / 'reopened').write_text('reopened')
    if role == 'b' and not transient_done and (control / 'transient').exists():
        connection = sqlite3.connect(data / 'fixture.sqlite3')
        try:
            with connection:
                connection.execute("INSERT INTO fixture VALUES ('snapshot-gap')")
        finally:
            connection.close()
        transient_done = True
        (control / 'transient-done').write_text('done')
    time.sleep(.1)
raise SystemExit('시험 시간 초과')
PY
chmod 0644 "$code/worker.py"
restorecon -RF "$data" "$control" "$code" "$records"
systemd-run --quiet --unit="$first" --property=Type=exec --property=KillMode=control-group \
  /usr/bin/python3 -u "$code/worker.py" "$data" "$control" a 61037
systemd-run --quiet --unit="$second" --property=Type=exec --property=KillMode=control-group \
  /usr/bin/python3 -u "$code/worker.py" "$data" "$control" b 61038
python3 - "$module" "$data" "$control" "$first" "$second" "$mode" "$1/deploy/model-control" <<'PY'
import importlib.util
import subprocess
import sys
import time
from pathlib import Path
module_path, data, control = map(Path, sys.argv[1:4])
first, second, mode = sys.argv[4:7]
source = Path(sys.argv[7])
def wait(name):
    for _ in range(120):
        if (control / name).exists(): return
        time.sleep(.5)
    raise SystemExit('시험 준비 시간 초과: ' + name)
def pid(unit):
    value = int(subprocess.check_output(['systemctl', 'show', unit, '-p', 'MainPID', '--value'], text=True).strip())
    if value <= 1: raise SystemExit('시험 PID 확인 실패')
    return value
wait('a-ready')
wait('b-ready')
a, b = pid(first), pid(second)
if a == b: raise SystemExit('시험 프로세스가 구분되지 않습니다.')
spec = importlib.util.spec_from_file_location('references', module_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first_result = module.observe_uid_process_threads(61037, data, data / 'fixture.sqlite3')
if set(first_result) != {a} or any(first_result[a].values()):
    raise SystemExit('첫 시험 UID 관찰 결과 오류: ' + repr(first_result))
second_result = module.observe_uid_process_threads(61038, data, data / 'fixture.sqlite3')
if set(second_result) != {b} or 'fd' not in second_result[b][b]:
    raise SystemExit('다른 UID의 DB FD 감지 실패: ' + repr(second_result))
print('첫 UID 관찰에 나타나지 않는 다른 UID의 DB 디렉터리 FD 확인', flush=True)
if mode in ('both', 'adapter', 'adapter-reopen', 'snapshot-gap'):
    combined = module.observe_known_uids([61037, 61038], data, data / 'fixture.sqlite3')
    if (set(combined[61037]) != {a} or any(combined[61037][a].values())
            or set(combined[61038]) != {b} or 'fd' not in combined[61038][b][b]):
        raise SystemExit('두 UID 동시 관찰 실패: ' + repr(combined))
    print('지정된 두 시험 UID의 프로세스·스레드 관찰과 DB FD 감지 확인', flush=True)
if mode in ('adapter', 'adapter-reopen'):
    from types import SimpleNamespace
    def load(name, path):
        candidate = importlib.util.spec_from_file_location(name, path)
        loaded = importlib.util.module_from_spec(candidate)
        candidate.loader.exec_module(loaded)
        return loaded
    backup = load('fixture_backup', source / 'legacy-backup-adapter.py')
    db = load('fixture_db', source / 'inspect-stopped-studio-db.py')
    backup.STUDIO_DATABASE = data / 'fixture.sqlite3'
    adapter = backup.LegacyBackupAdapter.__new__(backup.LegacyBackupAdapter)
    adapter.check_local_idle = lambda: True
    adapter.llama_connections = SimpleNamespace(check_host_llama=lambda: True)
    adapter.require_stopped = lambda: True
    adapter.check_database_fence = lambda: not any(
        refs for per_uid in module.observe_known_uids([61037, 61038], data, backup.STUDIO_DATABASE).values()
        for per_process in per_uid.values() for refs in per_process.values())
    inspections = []
    def inspect(path, *, check_stopped):
        inspections.append('start')
        return db.inspect(path, check_stopped=check_stopped)
    adapter.studio_db = SimpleNamespace(inspect=inspect)
    try:
        adapter.require_stopped_with_clear_database()
    except RuntimeError as error:
        if 'DB 검사 전' not in str(error): raise
    else:
        raise SystemExit('다른 UID의 참조가 있는데 DB 검사가 허용됐습니다.')
    if inspections: raise SystemExit('참조 감지 전 DB 검사가 시작됐습니다.')
    print('다른 UID의 시험 DB 참조가 있으면 백업 어댑터의 DB 검사 전 중단 확인', flush=True)
(control / 'close').touch()
wait('closed')
second_result = module.observe_uid_process_threads(61038, data, data / 'fixture.sqlite3')
if set(second_result) != {b} or any(second_result[b].values()):
    raise SystemExit('다른 UID의 FD 종료 후 참조 확인 실패: ' + repr(second_result))
print('다른 UID의 DB FD 종료 후 참조 없음 확인', flush=True)
if mode in ('both', 'adapter', 'adapter-reopen', 'snapshot-gap'):
    combined = module.observe_known_uids([61037, 61038], data, data / 'fixture.sqlite3')
    if (set(combined[61037]) != {a} or set(combined[61038]) != {b}
            or any(combined[61037][a].values()) or any(combined[61038][b].values())):
        raise SystemExit('두 UID의 FD 종료 후 관찰 실패: ' + repr(combined))
    print('지정된 두 시험 UID의 FD 종료 후 참조 없음 확인', flush=True)
if mode == 'snapshot-gap':
    import sqlite3
    (control / 'transient').touch()
    wait('transient-done')
    combined = module.observe_known_uids([61037, 61038], data, data / 'fixture.sqlite3')
    if (set(combined[61037]) != {a} or set(combined[61038]) != {b}
            or any(combined[61037][a].values()) or any(combined[61038][b].values())):
        raise SystemExit('일시적 시험 쓰기 이후 참조 확인 실패: ' + repr(combined))
    with sqlite3.connect(data / 'fixture.sqlite3') as connection:
        count = connection.execute("SELECT count(*) FROM fixture WHERE value='snapshot-gap'").fetchone()[0]
    if count != 1: raise SystemExit('두 관찰 사이의 시험 DB 쓰기가 확인되지 않았습니다.')
    print('두 UID 관찰 사이의 SQLite 쓰기는 양쪽 참조 관찰에 나타나지 않음 확인', flush=True)
if mode in ('adapter', 'adapter-reopen'):
    adapter.require_stopped_with_clear_database()
    if inspections != ['start']: raise SystemExit('시험 DB 검사 횟수가 올바르지 않습니다.')
    print('참조 종료 후 실제 시험 SQLite 상태 검사 연결 확인', flush=True)
if mode == 'adapter-reopen':
    def inspect_with_reopen(path, *, check_stopped):
        (control / 'reopen').touch()
        wait('reopened')
        inspections.append('reopen')
        return db.inspect(path, check_stopped=check_stopped)
    adapter.studio_db = SimpleNamespace(inspect=inspect_with_reopen)
    try:
        adapter.require_stopped_with_clear_database()
    except RuntimeError as error:
        if 'DB 검사 중' not in str(error): raise
    else:
        raise SystemExit('DB 검사 중 다시 열린 참조를 거절하지 못했습니다.')
    if inspections != ['start', 'reopen']:
        raise SystemExit('재오픈 경합 시험의 검사 횟수가 올바르지 않습니다.')
    print('시험 DB 검사 시작 직후 다른 UID의 참조 재오픈 시 복사 전 중단 확인', flush=True)
PY
systemctl stop "$first" "$second"
trap - ERR
echo "시험 서비스 정리 완료; 시험 자료 보관: $records $data $control $code"
echo '운영 DB·서비스는 변경하지 않았습니다. 시험 UID 두 개의 순간 관찰이며 전체 UID 열거·새 참조 및 지속 차단은 확인하지 않습니다. 어댑터 시험의 서비스 정지·유휴·차단은 모의입니다.'
