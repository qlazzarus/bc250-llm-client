#!/usr/bin/env bash
# Boot a disposable child overlay and an empty, separately identifiable test disk.
set -Eeuo pipefail
umask 077
[[ $(id -u) != 0 && $# == 0 ]] || { echo '일반 사용자로 인수 없이 실행하세요.' >&2; exit 1; }
source_dir="$HOME/bc250-maintenance-vm.hn3AiGJe"
source_disk="$source_dir/test-disk.qcow2"
base="$HOME/bc250-fedora43-test-vm/Fedora-Cloud-Base-Generic-43-1.6.x86_64.qcow2"
for tool in qemu-img qemu-system-x86_64 sha256sum python3 ssh-keygen ss; do
  command -v "$tool" >/dev/null || { echo "도구 없음: $tool" >&2; exit 1; }
done
for name in test-disk.qcow2 seed.iso vm-key known_hosts; do
  [[ -f "$source_dir/$name" && ! -L "$source_dir/$name" && -O "$source_dir/$name" ]] || { echo "시험 원본 파일 오류: $name" >&2; exit 1; }
done
for dir in "$HOME/bc250-fedora43-test-vm" "$source_dir" "$HOME/bc250-rescue-probe.ghxTG1JM"; do
  if [[ -f "$dir/vm.pid" ]]; then
    pid=$(cat "$dir/vm.pid")
    [[ $pid =~ ^[0-9]+$ ]] || { echo '이전 PID 파일 오류' >&2; exit 1; }
    if kill -0 "$pid" 2>/dev/null; then echo "이전 PID가 실행 중입니다: $pid" >&2; exit 1; fi
  fi
done
[[ -z $(ss -H -ltn 'sport = :22224') ]] || { echo '시험 포트가 사용 중입니다.' >&2; exit 1; }
available=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)
[[ $available =~ ^[0-9]+$ && $available -ge 3000000 ]] || { echo '사용 가능한 메모리가 부족합니다.' >&2; exit 1; }
printf '%s  %s\n' 846574c8a97cd2d8dc1f231062d73107cc85cbbbda56335e264a46e3a6c8ab2f "$base" | sha256sum -c -
qemu-img info --output=json "$source_disk" | python3 -c 'import json,os,sys; d=json.load(sys.stdin); assert d.get("format")=="qcow2" and d.get("backing-filename-format")=="qcow2" and os.path.realpath(d.get("full-backing-filename", ""))==os.path.realpath(sys.argv[1]) and d.get("virtual-size")==12884901888, "기존 시험 디스크 정보 불일치"' "$base"
key_fingerprint=$(ssh-keygen -lf "$source_dir/known_hosts" -E sha256 | awk 'NR==1 {print $2}')
[[ $key_fingerprint == SHA256:CH7GidNlEdtx1Dzd3TQQ0bydFp6L8ikRxIC8mkPB9no ]] || { echo '기존 시험 SSH 호스트 키 불일치' >&2; exit 1; }
probe_dir=$(mktemp -d "$HOME/bc250-maintenance-fixture.XXXXXXXX")
trap 'echo "시험 중단. 시험 자료 보존: $probe_dir" >&2' ERR
qemu-img create -q -f qcow2 -F qcow2 -b "$source_disk" "$probe_dir/boot-overlay.qcow2"
qemu-img create -q -f qcow2 "$probe_dir/fixture.qcow2" 512M
qemu-img info --output=json "$probe_dir/boot-overlay.qcow2" | python3 -c 'import json,os,sys; d=json.load(sys.stdin); assert d.get("format")=="qcow2" and d.get("backing-filename-format")=="qcow2" and os.path.realpath(d.get("full-backing-filename", ""))==os.path.realpath(sys.argv[1]), "시험 overlay 연결 오류"' "$source_disk"
qemu-img info --output=json "$probe_dir/fixture.qcow2" | python3 -c 'import json,sys; d=json.load(sys.stdin); assert d.get("format")=="qcow2" and "backing-filename" not in d and d.get("virtual-size")==536870912, "빈 시험 디스크 오류"'
cd "$probe_dir"
nice -n 15 qemu-system-x86_64 \
  -accel tcg,thread=multi -m 1536 -smp 2 \
  -drive file=boot-overlay.qcow2,if=virtio,format=qcow2 \
  -drive "file=$source_dir/seed.iso,media=cdrom,readonly=on" \
  -drive file=fixture.qcow2,if=none,id=fixture,format=qcow2 \
  -device virtio-blk-pci,drive=fixture,serial=bc250-fixture-01 \
  -netdev user,id=net0,restrict=on,hostfwd=tcp:127.0.0.1:22224-:22 \
  -device virtio-net-pci,netdev=net0 -display none -monitor none \
  -serial file:serial.log -pidfile vm.pid -daemonize
pid=$(cat vm.pid)
[[ $pid =~ ^[0-9]+$ ]] && kill -0 "$pid" 2>/dev/null || { echo '시험 VM 시작 여부 미확인' >&2; exit 1; }
echo "별도 Enforcing 후보 VM 시작 요청: PID $pid"
echo "시험 자료: $probe_dir"
echo '512 MiB의 빈 시험 디스크만 추가했습니다. 실제 모드·디스크 식별은 아직 확인되지 않았습니다.'
