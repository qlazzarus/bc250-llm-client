#!/usr/bin/env bash
# Disposable VM: explore Linux file leases, not a database fence.
set -Eeuo pipefail
umask 077
[[ $(id -u) == 0 && $(hostname) == bc250-fedora43-test && $(systemd-detect-virt) == qemu && $(getenforce) == Enforcing \
  && ( $# == 1 || ( $# == 2 && ( $2 == holder-death || $2 == break-notice || $2 == replace || $2 == protected-directory ) ) ) ]] || exit 1
mode=${2:-ordinary}
! getent passwd 61038 >/dev/null
! getent group 61038 >/dev/null
fixture=$(mktemp -d /var/lib/bc250-db-file-lease.XXXXXXXX)
trap 'echo "시험 중단. 시험 자료 보관: $fixture" >&2' ERR
chmod 0755 "$fixture"
restorecon -RF "$fixture"
python3 - "$fixture" <<'PY'
import errno
import fcntl
import os
import signal
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
file = root / 'fixture.db'
file.write_bytes(b'fixture')
file.chmod(0o666)
child_code = r'''
import errno, os, sys
root = sys.argv[1]
os.setgroups([])
os.setgid(61038)
os.setuid(61038)
directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
fd = os.open('fixture.db', os.O_RDWR, dir_fd=directory)
print('ready', flush=True)
for command in sys.stdin:
    command = command.strip()
    if command == 'close':
        os.close(fd)
        print('closed', flush=True)
    elif command == 'open':
        try:
            fd = os.open('fixture.db', os.O_RDWR | os.O_NONBLOCK, dir_fd=directory)
        except OSError as error:
            print('errno=' + str(error.errno), flush=True)
        else:
            os.close(fd)
            print('opened', flush=True)
    elif command == 'stop':
        break
    else:
        raise SystemExit(2)
os.close(directory)
'''
child = subprocess.Popen(['/usr/bin/python3', '-u', '-c', child_code, str(root)],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
fd = None
old_handler = signal.signal(signal.SIGIO, lambda *_: None)
def command(value):
    child.stdin.write(value + '\n')
    child.stdin.flush()
    return child.stdout.readline().strip()
try:
    if child.stdout.readline().strip() != 'ready': raise RuntimeError('시험 프로세스 준비 실패')
    fd = os.open(file, os.O_RDWR | os.O_CLOEXEC)
    try:
        fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
    except OSError as error:
        if error.errno not in (errno.EAGAIN, errno.EACCES): raise
        print('다른 시험 UID의 기존 파일 FD가 열린 동안 쓰기 lease 획득 거절 확인', flush=True)
    else:
        fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
        raise RuntimeError('기존 시험 파일 FD가 있는데 lease가 허용됐습니다.')
    if command('close') != 'closed': raise RuntimeError('기존 시험 FD 종료 실패')
    fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
    print('기존 시험 파일 FD 종료 후 쓰기 lease 획득 확인', flush=True)
    outcome = command('open')
    if outcome != f'errno={errno.EAGAIN}':
        raise RuntimeError('시험 lease 보유 중 다른 UID의 새 열기 결과: ' + outcome)
    print('쓰기 lease 중 기존 디렉터리 FD를 통한 비차단 파일 열기 거절 확인', flush=True)
    fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
    if command('open') != 'opened': raise RuntimeError('시험 lease 해제 후 파일 열기 실패')
    print('시험 lease 해제 후 다른 UID의 파일 열기 성공 확인', flush=True)
    child.stdin.write('stop\n')
    child.stdin.flush()
    if child.wait(timeout=15): raise RuntimeError('시험 프로세스 종료 실패')
finally:
    if fd is not None:
        try: fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
        except OSError: pass
        os.close(fd)
    if child.poll() is None:
        child.kill()
        child.wait(timeout=15)
    signal.signal(signal.SIGIO, old_handler)
print('운영 DB·서비스는 변경하지 않았습니다. 단일 파일과 신규 열기만 시험했으며 SQLite WAL·매핑·lease 해제 경합·프로세스 종료·백업은 검증하지 않았습니다.', flush=True)
PY
if [[ $mode == holder-death ]]; then
python3 - "$fixture" <<'PYDEATH'
import errno
import signal
import subprocess
import sys
from pathlib import Path

file = Path(sys.argv[1]) / 'fixture.db'
holder_code = r"""
import fcntl, os, signal, sys
signal.signal(signal.SIGIO, lambda *_: None)
fd = os.open(sys.argv[1], os.O_RDWR | os.O_CLOEXEC)
fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
print('held', flush=True)
sys.stdin.readline()
"""
open_code = r"""
import os, sys
os.setgroups([])
os.setgid(61038)
os.setuid(61038)
try:
    fd = os.open(sys.argv[1], os.O_RDWR | os.O_NONBLOCK)
except OSError as error:
    print('errno=' + str(error.errno))
else:
    os.close(fd)
    print('opened')
"""
holder = subprocess.Popen(['/usr/bin/python3', '-u', '-c', holder_code, str(file)],
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
def attempt():
    return subprocess.check_output(['/usr/bin/python3', '-c', open_code, str(file)],
                                   text=True, timeout=20).strip()
try:
    if holder.stdout.readline().strip() != 'held': raise RuntimeError('시험 lease 보유 프로세스 준비 실패')
    if attempt() != f'errno={errno.EAGAIN}': raise RuntimeError('프로세스 생존 중 새 열기 차단 실패')
    print('별도 시험 프로세스의 lease 보유 중 새 파일 열기 거절 확인', flush=True)
    holder.kill()
    holder.wait(timeout=15)
    if attempt() != 'opened': raise RuntimeError('시험 lease 보유 프로세스 종료 후 열기 실패')
    print('시험 lease 보유 프로세스 종료 후 다른 UID의 새 파일 열기 성공 확인', flush=True)
finally:
    if holder.poll() is None:
        holder.kill()
        holder.wait(timeout=15)
print('프로세스 종료를 감지해 백업을 중단하는 기능은 시험하지 않았습니다.', flush=True)
PYDEATH
fi
if [[ $mode == break-notice ]]; then
python3 - "$fixture" <<'PYBREAK'
import errno
import json
import subprocess
import sys
import time
from pathlib import Path

file = Path(sys.argv[1]) / 'fixture.db'
holder_code = r"""
import fcntl, json, os, signal, sys
notices = 0
def on_break(*_):
    global notices
    notices += 1
signal.signal(signal.SIGIO, on_break)
fd = os.open(sys.argv[1], os.O_RDWR | os.O_CLOEXEC)
fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
print('held', flush=True)
for command in sys.stdin:
    if command.strip() == 'status':
        print(json.dumps({'notices': notices, 'lease': fcntl.fcntl(fd, fcntl.F_GETLEASE)}), flush=True)
    elif command.strip() == 'release':
        fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
        print('released', flush=True)
    elif command.strip() == 'stop':
        break
    else:
        raise SystemExit(2)
os.close(fd)
"""
open_code = r"""
import os, sys
os.setgroups([])
os.setgid(61038)
os.setuid(61038)
try:
    fd = os.open(sys.argv[1], os.O_RDWR | os.O_NONBLOCK)
except OSError as error:
    print('errno=' + str(error.errno))
else:
    os.close(fd)
    print('opened')
"""
holder = subprocess.Popen(['/usr/bin/python3', '-u', '-c', holder_code, str(file)],
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
def send(command):
    holder.stdin.write(command + '\n')
    holder.stdin.flush()
    return holder.stdout.readline().strip()
def attempt():
    return subprocess.check_output(['/usr/bin/python3', '-c', open_code, str(file)],
                                   text=True, timeout=20).strip()
try:
    if holder.stdout.readline().strip() != 'held': raise RuntimeError('시험 lease 준비 실패')
    initial = json.loads(send('status'))
    if initial['notices'] != 0: raise RuntimeError('시험 시작 전 예상하지 못한 lease 통지')
    if attempt() != f'errno={errno.EAGAIN}': raise RuntimeError('시험 lease 중 새 열기 거절 실패')
    for _ in range(50):
        status = json.loads(send('status'))
        if status['notices'] > 0: break
        time.sleep(.1)
    else:
        raise RuntimeError('파일 열기 요청의 lease 해제 통지를 감지하지 못했습니다.')
    print('다른 UID의 새 파일 열기 요청에 대한 lease 해제 통지 감지 확인', flush=True)
    print('통지 이후 F_GETLEASE 결과:', status['lease'], flush=True)
    if send('release') != 'released': raise RuntimeError('시험 lease 해제 실패')
    if attempt() != 'opened': raise RuntimeError('시험 lease 해제 후 파일 열기 실패')
    print('시험 lease 해제 후 파일 열기 성공 확인', flush=True)
    holder.stdin.write('stop\n')
    holder.stdin.flush()
    if holder.wait(timeout=15): raise RuntimeError('시험 프로세스 종료 실패')
finally:
    if holder.poll() is None:
        holder.kill()
        holder.wait(timeout=15)
print('단일 시험 파일의 통지만 관찰했으며 DB·WAL 보호와 백업 중단은 검증하지 않았습니다.', flush=True)
PYBREAK
fi
if [[ $mode == replace ]]; then
  chmod 0777 "$fixture"
  python3 - "$fixture" <<'PYREPLACE'
import fcntl
import os
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
file = root / 'fixture.db'
fd = os.open(file, os.O_RDWR | os.O_CLOEXEC)
child_code = r"""
import os, sys
root = sys.argv[1]
os.setgroups([])
os.setgid(61038)
os.setuid(61038)
directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
os.unlink('fixture.db', dir_fd=directory)
new = os.open('fixture.db', os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600, dir_fd=directory)
os.write(new, b'replacement')
os.close(new)
os.close(directory)
"""
try:
    original = os.fstat(fd)
    fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
    subprocess.run(['/usr/bin/python3', '-c', child_code, str(root)], check=True, timeout=20)
    replacement = file.stat()
    if (original.st_dev, original.st_ino) == (replacement.st_dev, replacement.st_ino):
        raise RuntimeError('시험 경로의 새 파일이 기존 inode와 동일합니다.')
    if file.read_bytes() != b'replacement': raise RuntimeError('시험 교체 파일의 내용 확인 실패')
    if fcntl.fcntl(fd, fcntl.F_GETLEASE) != fcntl.F_WRLCK:
        raise RuntimeError('기존 파일의 lease가 유지되지 않았습니다.')
    print('기존 파일의 lease 유지 중 다른 UID가 경로의 파일을 교체하고 새 파일에 쓰기 성공 확인', flush=True)
finally:
    try: fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
    except OSError: pass
    os.close(fd)
print('쓰기 가능한 시험 디렉터리의 단일 파일 결과이며 운영 경로 권한을 검증하지 않았습니다.', flush=True)
PYREPLACE
fi
if [[ $mode == protected-directory ]]; then
  chmod 0755 "$fixture"
  python3 - "$fixture" <<'PYPROTECT'
import errno
import fcntl
import json
import os
import signal
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
file = root / 'fixture.db'
fd = os.open(file, os.O_RDWR | os.O_CLOEXEC)
old_handler = signal.signal(signal.SIGIO, lambda *_: None)
child_code = r"""
import json, os, sys
root = sys.argv[1]
os.setgroups([])
os.setgid(61038)
os.setuid(61038)
directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
result = {}
try:
    os.unlink('fixture.db', dir_fd=directory)
except OSError as error:
    result['unlink'] = error.errno
else:
    result['unlink'] = 'success'
try:
    fd = os.open('fixture.db', os.O_RDWR | os.O_NONBLOCK, dir_fd=directory)
except OSError as error:
    result['open'] = error.errno
else:
    os.close(fd)
    result['open'] = 'success'
os.close(directory)
print(json.dumps(result))
"""
try:
    original = os.fstat(fd)
    fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_WRLCK)
    result = json.loads(subprocess.check_output(['/usr/bin/python3', '-c', child_code, str(root)], text=True, timeout=20))
    if result['unlink'] not in (errno.EACCES, errno.EPERM) or result['open'] != errno.EAGAIN:
        raise RuntimeError('시험 디렉터리 또는 파일 보호 결과 오류: ' + repr(result))
    after = file.stat()
    if (original.st_dev, original.st_ino) != (after.st_dev, after.st_ino):
        raise RuntimeError('시험 파일이 교체됐습니다.')
    print('root 소유 시험 디렉터리의 다른 UID 경로 삭제 거절과 lease 보유 파일 열기 거절 확인', flush=True)
finally:
    try: fcntl.fcntl(fd, fcntl.F_SETLEASE, fcntl.F_UNLCK)
    except OSError: pass
    os.close(fd)
    signal.signal(signal.SIGIO, old_handler)
print('시험 디렉터리와 단일 파일만 확인했으며 운영 권한·기존 FD·DB WAL·차단 유지·백업은 검증하지 않았습니다.', flush=True)
PYPROTECT
fi
trap - ERR
echo "시험 자료 보관: $fixture"
