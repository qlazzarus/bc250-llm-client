#!/usr/bin/env python3
"""Check archive failures propagate even when the caller disables errexit."""
import os
import subprocess
from pathlib import Path

import pytest

SCRIPT = Path(__file__).resolve().parents[1] / 'deploy/model-control/backup-archive.sh'


@pytest.mark.parametrize('failure', ['tar', 'metadata'])
def test_failure_does_not_create_success_checksum(tmp_path, failure):
    root = tmp_path / 'root'
    backup = tmp_path / 'backup'
    tools = tmp_path / 'tools'
    for name in ('opt/bc250-ai-studio', 'opt/ai-studio-data', 'opt/ai/config',
                 'etc/systemd/system', 'var/lib/bc250-model-control'):
        (root / name).mkdir(parents=True)
    for name in ('bc250-ai-studio', 'bc250-llm-gate', 'bc250-llm-client'):
        (root / 'etc' / f'{name}.env').write_text('fixture\n')
        (root / 'etc/systemd/system' / f'{name}.service').write_text('fixture\n')
    (root / 'opt/ai/config/active-model.conf').write_text('fixture\n')
    (root / 'var/lib/bc250-model-control/legacy-pause.json').write_text('{}\n')
    caddy = tmp_path / 'caddy'
    caddy.write_text('fixture\n')
    backup.mkdir()
    tools.mkdir()
    tar = tools / 'tar'
    tar.write_text('#!/bin/sh\ncase "$1" in --create) : > "${2#--file=}"; exit 2;; esac\nexit 0\n')
    tar.chmod(0o755)
    checksum = tools / 'sha256sum'
    checksum.write_text('#!/bin/sh\n[ "$1" = -c ] && exit 0\nprintf "fixture\\n"\n')
    checksum.chmod(0o755)
    sync = tools / 'sync'
    sync.write_text('#!/bin/sh\nexit 0\n')
    sync.chmod(0o755)
    python = tools / 'python3'
    python.write_text('#!/bin/sh\n[ "$FAIL_METADATA" = 1 ] && exit 1\nexit 0\n')
    python.chmod(0o755)
    env = dict(os.environ, PATH=str(tools) + os.pathsep + os.environ['PATH'],
               FAIL_METADATA='1' if failure == 'metadata' else '0')
    result = subprocess.run(['bash', '-c', 'source "$1"; bc250_backup_archive "$2" "$3" "$4"',
                             'fixture', str(SCRIPT), str(root), str(backup), str(caddy)],
                            env=env, capture_output=True, text=True, check=False)
    assert result.returncode != 0
    assert not (backup / 'SHA256SUMS').exists()


@pytest.mark.parametrize('checker', ['', 'bc250_check_db_fence() { return 1; }'])
def test_staged_backup_refuses_missing_or_failed_fence(tmp_path, checker):
    root, backup, staged = (tmp_path / name for name in ('root', 'backup', 'staged'))
    for name in ('opt/bc250-ai-studio', 'opt/ai-studio-data', 'opt/ai/config',
                 'etc/systemd/system', 'var/lib/bc250-model-control'):
        (root / name).mkdir(parents=True)
    for name in ('bc250-ai-studio', 'bc250-llm-gate', 'bc250-llm-client'):
        (root / 'etc' / f'{name}.env').write_text('fixture\n')
        (root / 'etc/systemd/system' / f'{name}.service').write_text('fixture\n')
    (root / 'opt/ai/config/active-model.conf').write_text('fixture\n')
    (root / 'var/lib/bc250-model-control/legacy-pause.json').write_text('{}\n')
    backup.mkdir()
    staged.mkdir()
    caddy = tmp_path / 'caddy'
    caddy.write_text('fixture\n')
    result = subprocess.run(['bash', '-c', checker + '\nsource "$1"; bc250_backup_archive "$2" "$3" "$4" "$5"',
                             'fixture', str(SCRIPT), str(root), str(backup), str(caddy), str(staged)],
                            capture_output=True, text=True, check=False)
    assert result.returncode != 0
    assert not (backup / 'legacy.tar').exists()
    assert not (backup / 'SHA256SUMS').exists()
