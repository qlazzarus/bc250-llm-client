#!/usr/bin/env bash
# Prepare an independent test VM; do not start it or change the existing VM.
set -Eeuo pipefail
umask 077
[[ $(id -u) != 0 && $# == 0 ]] || { echo '일반 사용자로 인수 없이 실행하세요.' >&2; exit 1; }
old_dir="$HOME/bc250-fedora43-test-vm"
base="$old_dir/Fedora-Cloud-Base-Generic-43-1.6.x86_64.qcow2"
expected=846574c8a97cd2d8dc1f231062d73107cc85cbbbda56335e264a46e3a6c8ab2f
for tool in qemu-img genisoimage ssh-keygen sha256sum python3 ss; do
  command -v "$tool" >/dev/null || { echo "도구 없음: $tool" >&2; exit 1; }
done
[[ -f $base && ! -L $base ]] || { echo '원본 이미지가 없거나 심볼릭 링크입니다.' >&2; exit 1; }
if [[ -f "$old_dir/vm.pid" ]]; then
  old_pid=$(cat "$old_dir/vm.pid")
  [[ $old_pid =~ ^[0-9]+$ ]] || { echo '기존 PID가 올바르지 않습니다.' >&2; exit 1; }
  if kill -0 "$old_pid" 2>/dev/null; then
    echo '기존 PID가 실행 중입니다. 충돌 여부를 확인하세요.' >&2; exit 1
  fi
fi
[[ -z $(ss -H -ltn 'sport = :22224') ]] || { echo '시험 포트 22224가 사용 중입니다.' >&2; exit 1; }
available=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)
[[ $available =~ ^[0-9]+$ && $available -ge 3000000 ]] || { echo '사용 가능한 메모리가 부족합니다.' >&2; exit 1; }
printf '%s  %s\n' "$expected" "$base" | sha256sum -c -
qemu-img info --output=json "$base" | python3 -c 'import json,sys; d=json.load(sys.stdin); assert d.get("format")=="qcow2" and "backing-filename" not in d and d.get("virtual-size")==5368709120, "원본 이미지 형식 오류"'
test_dir=$(mktemp -d "$HOME/bc250-maintenance-vm.XXXXXXXX")
trap 'echo "준비 중단. 시험 자료 보존: $test_dir" >&2' ERR
ssh-keygen -q -t ed25519 -N '' -f "$test_dir/vm-key"
instance_id="bc250-maintenance-$(basename "$test_dir")"
printf 'instance-id: %s\nlocal-hostname: bc250-maintenance-test\n' "$instance_id" > "$test_dir/meta-data"
{
  printf '%s\n' '#cloud-config' 'users:' '  - name: vmtest' '    groups: wheel' '    shell: /bin/bash' '    sudo: ALL=(ALL) NOPASSWD:ALL' '    ssh_authorized_keys:'
  printf '      - %s\n' "$(cat "$test_dir/vm-key.pub")"
  printf '%s\n' 'ssh_pwauth: false' 'disable_root: true'
} > "$test_dir/user-data"
genisoimage -quiet -output "$test_dir/seed.iso" -volid cidata -joliet -rock "$test_dir/user-data" "$test_dir/meta-data"
qemu-img create -q -f qcow2 -F qcow2 -b "$base" "$test_dir/test-disk.qcow2"
qemu-img resize -q "$test_dir/test-disk.qcow2" 12G
qemu-img info --output=json "$test_dir/test-disk.qcow2" | python3 -c 'import json,os,sys; d=json.load(sys.stdin); assert d.get("format")=="qcow2" and d.get("backing-filename-format")=="qcow2" and os.path.realpath(d.get("full-backing-filename", ""))==os.path.realpath(sys.argv[1]) and d.get("virtual-size")==12884901888, "시험 디스크 형식 오류"' "$base"
printf '%s  %s\n' "$expected" "$base" | sha256sum -c -
echo "별도 시험 VM 준비 완료: $test_dir"
echo '새 시험 디스크·전용 키·seed를 만들었습니다. VM은 시작하지 않았습니다.'
echo '기존 시험 VM 디스크와 seed는 변경하지 않았습니다.'
