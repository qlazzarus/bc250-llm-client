#!/usr/bin/env python3
"""Check startup/handoff ordering; callbacks are mock conditions, not GPU safety."""
import importlib.util
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

path = Path(__file__).resolve().parents[1] / 'deploy/model-control/locked-service-start.py'
spec = importlib.util.spec_from_file_location('locked_service_start', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class LockedStartupTest(unittest.TestCase):
    def fixture(self):
        events = []
        state = {'hold': True, 'lock': True, 'prepare': True}

        class Startup:
            def start(self):
                events.append('start')

            def prepare_confirmation(self):
                events.append('verify_client')
                if not state['prepare']:
                    raise ValueError('verification failed')

            def confirm_startup(self):
                events.append('confirm')
                return True

        startup = Startup()

        def begin():
            events.append('acquire')
            return True

        def check():
            events.append('check_lock')
            return state['lock']

        def confirm():
            events.append('release_for_confirmation')
            return startup.confirm_startup()

        sequence = SimpleNamespace(begin=begin, check_deployment_hold=lambda: state['hold'],
                                   handoff=SimpleNamespace(check=check), confirm=startup.confirm_startup,
                                   confirm_after_client_restart=confirm)
        return module.LockedServiceStart(startup, sequence), state, events, startup, sequence

    def test_normal_order(self):
        runner, _, events, _, _ = self.fixture()
        runner.start()
        runner.finish()
        self.assertEqual(events, ['start', 'acquire', 'check_lock', 'verify_client',
                                  'release_for_confirmation', 'confirm'])
        with self.assertRaises(module.LockedServiceStartError):
            runner.finish()

    def test_lost_hold_or_lock_never_releases(self):
        for key in ('hold', 'lock'):
            runner, state, events, _, _ = self.fixture()
            runner.start()
            state[key] = False
            with self.assertRaises(module.LockedServiceStartError):
                runner.finish()
            self.assertNotIn('release_for_confirmation', events)
            with self.assertRaises(module.LockedServiceStartError):
                runner.finish()

    def test_client_check_failure_retains_handoff(self):
        runner, state, events, _, _ = self.fixture()
        runner.start()
        state['prepare'] = False
        with self.assertRaises(module.LockedServiceStartError):
            runner.finish()
        self.assertNotIn('release_for_confirmation', events)

    def test_mismatched_confirmation_is_rejected(self):
        _, _, _, startup, sequence = self.fixture()
        sequence.confirm = lambda: True
        with self.assertRaises(ValueError):
            module.LockedServiceStart(startup, sequence)

    def test_actual_startup_and_sequence_share_confirmation(self):
        root = path.parent
        startup_spec = importlib.util.spec_from_file_location('new_service_start', root / 'start-new-services.py')
        startup_module = importlib.util.module_from_spec(startup_spec)
        startup_spec.loader.exec_module(startup_module)
        sequence_spec = importlib.util.spec_from_file_location('startup_lock_sequence', root / 'startup-lock-sequence.py')
        sequence_module = importlib.util.module_from_spec(sequence_spec)
        sequence_spec.loader.exec_module(sequence_module)
        events = []

        class Handoff:
            held = False

            def acquire(self):
                self.held = True
                events.append('acquire')
                return True

            def check(self):
                return self.held

            def release(self, *, can_release):
                if not can_release():
                    return False
                self.held = False
                events.append('release')
                return True

        handoff = Handoff()
        with patch.object(startup_module.os, 'geteuid', return_value=0):
            startup = startup_module.NewServiceStart('/fixture/backup-archive.sh',
                check_maintenance=lambda: True, check_release=lambda: True,
                check_local_idle=lambda: True, check_running=lambda: True,
                check_configuration=lambda: True, expected_client_user='fixture')
        sequence = sequence_module.StartupLockSequence(record=events.append,
            check_pre_handoff=lambda: True, prepare_tmpfiles=lambda: True, handoff=handoff,
            check_before_confirm=lambda: True, check_deployment_hold=lambda: True,
            confirm_startup=startup.confirm_startup)
        runner = module.LockedServiceStart(startup, sequence)

        def command(args, **_):
            if 'app.services.gate_admin' in args:
                self.assertFalse(handoff.held)
                events.append('confirm')

        with patch.object(startup_module, 'trusted_file'), patch.object(startup_module, 'command', side_effect=command), \
             patch.object(startup_module, 'socket_stopped'), patch.object(startup_module, 'api_ready'), \
             patch.object(startup_module, 'worker_disabled'), patch.object(startup_module, 'wait_for_coordination'), \
             patch.object(startup_module, 'ENABLE_LINKS', ()), patch('builtins.print'):
            runner.start()
            self.assertTrue(handoff.held)
            runner.finish()
        self.assertLess(events.index('acquire'), events.index('release'))
        self.assertLess(events.index('release'), events.index('confirm'))
        self.assertEqual(sequence.phase, 'complete')


if __name__ == '__main__':
    unittest.main()
